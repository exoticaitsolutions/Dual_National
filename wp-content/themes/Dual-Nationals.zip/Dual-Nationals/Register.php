<?php /* Template Name: Register Page */ 
get_header();
echo do_shortcode('[mepr-membership-registration-form]');
get_footer();
?>