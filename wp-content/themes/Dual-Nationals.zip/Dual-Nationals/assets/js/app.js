jQuery(document).ready(function () {
//  Sign Up Functionalty 


console.log('asdasdsadsa');

});