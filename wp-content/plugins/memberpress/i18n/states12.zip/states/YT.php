<?php
/**
 * Madagascar states
 */
$states['Mayotte'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
);

?>