<?php
/**
 * Iraq states
 */
$states['Iraq'] = array(
    'Al Anbar'          => _x('Al Anbar', 'ui', 'memberpress'),
    'Al Basrah'         => _x('Al Basrah', 'ui', 'memberpress'),
    'Al Muthanna'       => _x('Al Muthanna', 'ui', 'memberpress'),
    'Al Qadisiyah'      => _x('Al Qadisiyah', 'ui', 'memberpress'),
    'An Najaf'          => _x('An Najaf', 'ui', 'memberpress'),
    'Arbil'             => _x('Arbil', 'ui', 'memberpress'),
    'As Sulaymaniyah'   => _x('As Sulaymaniyah', 'ui', 'memberpress'),
    'At Ta mim'         => _x('At Ta mim', 'ui', 'memberpress'),
    'Babil'             => _x('Babil', 'ui', 'memberpress'),
    'Baghdad'           => _x('Baghdad', 'ui', 'memberpress'),
    'Dahuk'             => _x('Dahuk', 'ui', 'memberpress'),
    'Dhi Qar'           => _x('Dhi Qar', 'ui', 'memberpress'),
    'Diyala'            => _x('Diyala', 'ui', 'memberpress'),
    'Karbala'           => _x('Karbala', 'ui', 'memberpress'),
    'Maysan'            => _x('Maysan', 'ui', 'memberpress'),
    'Ninawa'            => _x('Ninawa', 'ui', 'memberpress'),
    'Salah ad Din'      => _x('Salah ad Din', 'ui', 'memberpress'),
    'Wasit'             => _x('Wasit', 'ui', 'memberpress')

);

?>