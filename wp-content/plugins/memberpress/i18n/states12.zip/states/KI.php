<?php
/**
 * Kiribati states
 */
$states['Kiribati'] = array(
    'Banaba'                       => _x('Banaba', 'ui', 'memberpress'),
    'Tarawa'                       => _x('Tarawa', 'ui', 'memberpress'),
    'Northern Gilbert Islands'     => _x('Northern Gilbert Islands', 'ui', 'memberpress'),
    'Central Gilbert Island'       => _x('Central Gilbert Island', 'ui', 'memberpress'),
    'Southern Gilbert Islands'     => _x('Southern Gilbert Islands', 'ui', 'memberpress'),
    'Line Islands'                 => _x('Line Islands', 'ui', 'memberpress')
);

?>