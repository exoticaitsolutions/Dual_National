<?php
/**
 * Germany Federal States
 */
$states['DE'] = array(
  'Baden-Wurttemberg' => __( 'Baden-Wurttemberg', 'memberpress' ),
  'Bavaria' => __( 'Bavaria', 'memberpress' ),
  'Berlin' => __( 'Berlin', 'memberpress' ),
  'Brandenburg' => __( 'Brandenburg', 'memberpress' ),
  'Bremen' => __( 'Bremen', 'memberpress' ),
  'Hamburg' => __( 'Hamburg', 'memberpress' ),
  'Hesse' => __( 'Hesse', 'memberpress' ),
  'Lower Saxony' => __( 'Lower Saxony', 'memberpress' ),
  'Mecklenburg-Vorpommern' => __( 'Mecklenburg-Vorpommern', 'memberpress' ),
  'North Rhine-Westphalia' => __( 'North Rhine-Westphalia', 'memberpress' ),
  'Rhineland-Palatinate' => __( 'Rhineland-Palatinate', 'memberpress' ),
  'Saarland' => __( 'Saarland', 'memberpress' ),
  'Saxony' => __( 'Saxony', 'memberpress' ),
  'Saxony-Anhalt' => __( 'Saxony-Anhalt', 'memberpress' ),
  'Schleswig-Holstein' => __( 'Schleswig-Holstein', 'memberpress' ),
  'Thuringia' => __( 'Thuringia', 'memberpress' ),
);
