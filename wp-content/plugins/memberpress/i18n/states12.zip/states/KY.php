<?php
/**
 * Cayman Islandse  States
 */
 $states['Cayman Islands'] = array(
    
    'Cayman Islands'       => _x('Cayman Islands', 'ui', 'memberpress'),
    
  );
 ?>