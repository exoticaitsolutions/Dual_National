<?php
/**
 * Qatar states
 */
$states['Qatar'] = array( 
  'Ad Dawhah' => _x('Ad Dawhah', 'ui', 'memberpress'),
  'Al Ghuwayriyah' => _x('Al Ghuwayriyah', 'ui', 'memberpress'),
  'Al Jumayliyah' => _x('Al Jumayliyah', 'ui', 'memberpress'),
  'Al Khawr' => _x('Al Khawr', 'ui', 'memberpress'),
  'Al Wakrah' => _x('Al Wakrah', 'ui', 'memberpress'),
  'Ar Rayyan' => _x('Ar Rayyan', 'ui', 'memberpress'),
  'Jarayan al Batinah' => _x('Jarayan al Batinah', 'ui', 'memberpress'),
  'Madinat ash Shamal' => _x('Madinat ash Shamal', 'ui', 'memberpress'),
  "Umm Sa'id" => _x("Umm Sa'id" , 'ui', 'memberpress'),
  'Umm Salal' => _x('Umm Salal', 'ui', 'memberpress')
);

?>