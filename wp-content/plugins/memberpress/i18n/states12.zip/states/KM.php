<?php
/**
 * Cameroon  States
 */
 $states['Cameroon'] = array(
    'Grande Comore (Njazidja)'       => _x('Grande Comore (Njazidja)', 'ui', 'memberpress'),
    'Anjouan (Nzwani)'       => _x('Anjouan (Nzwani)', 'ui', 'memberpress'),
    'Moheli (Mwali)'       => _x('Moheli (Mwali)', 'ui', 'memberpress')
  );
 ?>