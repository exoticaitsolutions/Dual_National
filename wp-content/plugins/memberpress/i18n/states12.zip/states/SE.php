<?php
/**
 * Sweden states
 */
$states['Sweden'] = array(
  'Blekinge' => _x('Blekinge', 'ui', 'memberpress'),
  'Dalarnas' => _x('Dalarnas', 'ui', 'memberpress'),
  'Gavleborgs' => _x('Gavleborgs', 'ui', 'memberpress'),
  'Gotlands' => _x('Gotlands', 'ui', 'memberpress'),
  'Hallands' => _x('Hallands', 'ui', 'memberpress'),
  'Jamtlands' => _x('Jamtlands', 'ui', 'memberpress'),
  'Jonkopings' => _x('Jonkopings', 'ui', 'memberpress'),
  'Kalmar' => _x('Kalmar', 'ui', 'memberpress'),
  'Kronobergs' => _x('Kronobergs', 'ui', 'memberpress'),
  'Norrbottens' => _x('Norrbottens', 'ui', 'memberpress'),
  'Orebro' => _x('Orebro', 'ui', 'memberpress'),
  'Ostergotlands' => _x('Ostergotlands', 'ui', 'memberpress'),
  'Skane' => _x('Skane', 'ui', 'memberpress'),
  'Sodermanlands' => _x('Sodermanlands', 'ui', 'memberpress'),
  'Stockholms' => _x('Stockholms', 'ui', 'memberpress'),
  'Uppsala' => _x('Uppsala', 'ui', 'memberpress'),
  'Varmlands' => _x('Varmlands', 'ui', 'memberpress'),
  'Vasterbottens' => _x('Vasterbottens', 'ui', 'memberpress'),
  'Vasternorrlands' => _x('Vasternorrlands', 'ui', 'memberpress'),
  'Vastmanlands' => _x('Vastmanlands', 'ui', 'memberpress'),
  'Vastra Gotalands' => _x('Vastra Gotalands', 'ui', 'memberpress'),
);
