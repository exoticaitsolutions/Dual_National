<?php
/**
 * Trinidad and Tobago states
 */
$states['Trinidad and Tobago'] = array(
  'Couva'  => _x('Couva', 'ui', 'memberpress'),
  'Diego Martin'  => _x('Diego Martin', 'ui', 'memberpress'),
  'Mayaro'  => _x('Mayaro', 'ui', 'memberpress'),
  'Penal' => _x('Penal', 'ui', 'memberpress'),
  'Princes Town'  => _x('Princes Town', 'ui', 'memberpress'),
  'Sangre Grande'  => _x('Sangre Grande', 'ui', 'memberpress'),
  'San Juan'  => _x('San Juan', 'ui', 'memberpress'),
  'Siparia'  => _x('Siparia', 'ui', 'memberpress'),
  'Tunapuna'  => _x('Tunapuna', 'ui', 'memberpress'),
  'Port-of-Spain'  => _x('Port-of-Spain', 'ui', 'memberpress'),
  'San Fernando'  => _x('San Fernando', 'ui', 'memberpress'),
  'Arima'  => _x('Arima', 'ui', 'memberpress'),
  'Point Fortin'  => _x('Point Fortin', 'ui', 'memberpress'),
  'Chaguanas'  => _x('Chaguanas', 'ui', 'memberpress'),
  'Tobago'  => _x('Tobago', 'ui', 'memberpress')
);

