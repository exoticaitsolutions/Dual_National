<?php
/**
 * Kyrgyzstan states
 */
$states['Kyrgyzstan'] = array(
    'Batken Oblasty'               => _x('Batken Oblasty', 'ui', 'memberpress'),
    'Bishkek Shaary'               => _x('Bishkek Shaary', 'ui', 'memberpress'),
    'Chuy Oblasty'                 => _x('Chuy Oblasty', 'ui', 'memberpress'),
    'Jalal-Abad Oblasty'           => _x('Jalal-Abad Oblasty', 'ui', 'memberpress'),
    'Naryn Oblasty'                => _x('Naryn Oblasty', 'ui', 'memberpress'),
    'Osh Oblasty'                  => _x('Osh Oblasty', 'ui', 'memberpress'),
    'Talas Oblasty'                => _x('Talas Oblasty', 'ui', 'memberpress'),
    'Ysyk-Kol Oblasty'             => _x('Ysyk-Kol Oblasty', 'ui', 'memberpress')
);

?>