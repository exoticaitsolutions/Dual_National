<?php
/**
 * French Guiana states
 */
$states['French Guiana'] = array(
  'Awala-Yalimapo' => _x('Awala-Yalimapo', 'ui', 'memberpress'),
  'Mana' => _x('Mana', 'ui', 'memberpress'),
  'Saint-Laurent-du-Maroni' => _x('Saint-Laurent-du-Maroni', 'ui', 'memberpress'),
  'Apatou' => _x('Apatou', 'ui', 'memberpress'),
  'Grand-Santi' => _x('Grand-Santi', 'ui', 'memberpress'),
  'Papaichton' => _x('Papaichton', 'ui', 'memberpress'),
  'Saul' => _x('Saul', 'ui', 'memberpress'),
  'Maripasoula' => _x('Maripasoula', 'ui', 'memberpress'),
  'Camopi' => _x('Camopi', 'ui', 'memberpress'),
  'Saint-Georges' => _x('Saint-Georges', 'ui', 'memberpress'),
  'Regina' => _x('Regina', 'ui', 'memberpress'),
  'Roura' => _x('Roura', 'ui', 'memberpress'),
  'Saint-Elie' => _x('Saint-Elie', 'ui', 'memberpress'),
  'Iracoubo' => _x('Iracoubo', 'ui', 'memberpress'),
  'Sinnamary' => _x('Sinnamary', 'ui', 'memberpress'),
  'Kourou' => _x('Kourou', 'ui', 'memberpress'),
  'Montsinery-Tonnegrande' => _x('Montsinery-Tonnegrande', 'ui', 'memberpress'),
   'Matoury' => _x('Matoury', 'ui', 'memberpress'),
   'Cayenne' => _x('Cayenne', 'ui', 'memberpress'),
    'Remire-Montjoly' => _x('Remire-Montjoly', 'ui', 'memberpress')
  
);

    