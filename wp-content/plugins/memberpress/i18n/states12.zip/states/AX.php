<?php
/**
 * Aland Islands states
 */
$states['Aland Islands'] = array(
  'Eckero'       => _x('Eckero', 'ui', 'memberpress'),
  'Foglo'       => _x('Foglo', 'ui', 'memberpress'),
  'Finstrom'       => _x('Finstrom', 'ui', 'memberpress'),
  'Geta'       => _x('Geta', 'ui', 'memberpress'),
  'Hammarland'       => _x('Hammarland', 'ui', 'memberpress'),
  'Jomala'       => _x('Jomala', 'ui', 'memberpress'),
  'Kokar'       => _x('Kokar', 'ui', 'memberpress'),
  'Kumlinge'       => _x('Kumlinge', 'ui', 'memberpress'),
  'Lemland'       => _x('Lemland', 'ui', 'memberpress'),
  'Lumparland'       => _x('Lumparland', 'ui', 'memberpress'),
  'Mariehamn'       => _x('Mariehamn', 'ui', 'memberpress'),
  'Saltvik'       => _x('Saltvik', 'ui', 'memberpress'),
  'Sottunga'       => _x('Sottunga', 'ui', 'memberpress'),
  'Sund'       => _x('Sund', 'ui', 'memberpress'),
  'VArdo'       => _x('VArdo', 'ui', 'memberpress')
);

