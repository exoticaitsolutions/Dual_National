<?php
/**
 * Niue states
 */
$states['Niue'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
);

?>