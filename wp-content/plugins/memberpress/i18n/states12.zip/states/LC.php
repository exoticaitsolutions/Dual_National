<?php
/**
 * Saint Lucia states
 */
$states['Saint Lucia'] = array(
  'Saint Lucia'  => _x('Saint Lucia', 'ui', 'memberpress'),

);

