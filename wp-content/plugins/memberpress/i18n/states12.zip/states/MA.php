<?php
/**
 * Morocco states
 */
$states['Morocco'] = array(
  'Agadir' => _x('Agadir', 'ui', 'memberpress'),
  'Al Hoceima' => _x('Al Hoceima', 'ui', 'memberpress'),
  'Azilal' => _x('Azilal', 'ui', 'memberpress'),
  'Beni Mellal' => _x('Beni Mellal', 'ui', 'memberpress'),
  'Ben Slimane' => _x('Ben Slimane', 'ui', 'memberpress'),
  'Boulemane' => _x('Boulemane', 'ui', 'memberpress'),
  'Casablanca' => _x('Casablanca', 'ui', 'memberpress'),
  'Chaouen' => _x('Chaouen', 'ui', 'memberpress'),
  'El Jadida' => _x('El Jadida', 'ui', 'memberpress'),
  'El Kelaa des Sraghna' => _x('El Kelaa des Sraghna', 'ui', 'memberpress'),
  'Er Rachidia' => _x('Er Rachidia', 'ui', 'memberpress'),
  'Essaouira' => _x('Essaouira', 'ui', 'memberpress'),
  'Fes' => _x('Fes', 'ui', 'memberpress'),
  'Figuig' => _x('Figuig', 'ui', 'memberpress'),
  'Guelmim' => _x('Guelmim', 'ui', 'memberpress'),
  'Ifrane' => _x('Ifrane', 'ui', 'memberpress'),
  'Kenitra' => _x('Kenitra', 'ui', 'memberpress'),
  'Khemisset' => _x('Khemisset', 'ui', 'memberpress'),
  'Khenifra' => _x('Khenifra', 'ui', 'memberpress'),
  'Khouribga' => _x('Khouribga', 'ui', 'memberpress'),
  'Laayoune' => _x('Laayoune', 'ui', 'memberpress'),
  'Larache' => _x('Larache', 'ui', 'memberpress'),
  'Marrakech' => _x('Marrakech', 'ui', 'memberpress'),
  'Meknes' => _x('Meknes', 'ui', 'memberpress'),
  'Nador' => _x('Nador', 'ui', 'memberpress'),
  'Ouarzazate' => _x('Ouarzazate', 'ui', 'memberpress'),
  'Oujda' => _x('Oujda', 'ui', 'memberpress'),
  'Rabat-Sale' => _x('Antananarivo', 'ui', 'memberpress'),
  'Safi' => _x('Safi', 'ui', 'memberpress'),
  'Settat' => _x('Settat', 'ui', 'memberpress'),
  'Sidi Kacem' => _x('Sidi Kacem', 'ui', 'memberpress'),
  'Tangier' => _x('Tangier', 'ui', 'memberpress'),
  'Tan-Tan' => _x('Tan-Tan', 'ui', 'memberpress'),
  'Taounate' => _x('Taounate', 'ui', 'memberpress'),
  'Taroudannt' => _x('Taroudannt', 'ui', 'memberpress'),
  'Tata' => _x('Tata', 'ui', 'memberpress'),
  'Taza' => _x('Taza', 'ui', 'memberpress'),
  'Tetouan' => _x('Tetouan', 'ui', 'memberpress'),
  'Tiznit' => _x('Tiznit', 'ui', 'memberpress')
);

?>