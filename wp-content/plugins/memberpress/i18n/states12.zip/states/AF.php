<?php
/**
 * Afganistan  States
 */

 $states['Afganistan'] = array(
    'Badakhshan'       => _x('Badakhshn', 'ui', 'memberpress'),
    'Baghlan'       => _x('Baghlan', 'ui', 'memberpress'),
    'Balkh'       => _x('Balkh', 'ui', 'memberpress'),
    'Badghīs'       => _x('Badghīs', 'ui', 'memberpress'),
    'Bamyan'       => _x('Bamyan', 'ui', 'memberpress'),
    'Daykundī'       => _x('Daykundī', 'ui', 'memberpress'),
    'Farah'       => _x('Farah', 'ui', 'memberpress'),
    'Faryab'       => _x('Faryab', 'ui', 'memberpress'),
    'Ghaznī'       => _x('Ghaznī', 'ui', 'memberpress'),
    'Ghor'       => _x('Ghor', 'ui', 'memberpress'),
    'Helmand'       => _x('Helmand', 'ui', 'memberpress'),
    'Herat'       => _x('Herat', 'ui', 'memberpress'),
    'Jowzjan'       => _x('Jowzjan', 'ui', 'memberpress'),
    'Khost'       => _x('Khost', 'ui', 'memberpress'),
    'Kunar'       => _x('Kunar', 'ui', 'memberpress'),
    'Kunduz'       => _x('Kunduz', 'ui', 'memberpress'),
    'Kabul'       => _x('Kabul', 'ui', 'memberpress'),
    'Kapīsa'       => _x('Kapīsa', 'ui', 'memberpress'),
    'Laghman'       => _x('Laghman', 'ui', 'memberpress'),
    'Logar'       => _x('Logar', 'ui', 'memberpress'),
    'Nangarhar'       => _x('Nangarhar', 'ui', 'memberpress'),
    'Nīmroz'       => _x('Nīmroz', 'ui', 'memberpress'),
    'Nūristan'       => _x('Nūristan', 'ui', 'memberpress'),
    'Paktiya'       => _x('Paktiya', 'ui', 'memberpress'),
    'Panjshayr'       => _x('Panjshayr', 'ui', 'memberpress'),
    'Parwan'       => _x('Parwan', 'ui', 'memberpress'),
    'Samangan'       => _x('Samangan', 'ui', 'memberpress'),
    'Sar-e Pul'       => _x('Sar-e Pul', 'ui', 'memberpress'),
    'Takhar'       => _x('Takhar', 'ui', 'memberpress'),
    'Uruzgan'       => _x('Uruzgan', 'ui', 'memberpress'),
    'Wardak'       => _x('Wardak', 'ui', 'memberpress'),
    'Zabul'       => _x('Zabul', 'ui', 'memberpress')
  );
 ?>