<?php
/**
 * Svalbard and Jan Mayen states
 */
$states['Svalbard and Jan Mayen'] = array(
  'Svalbard and Jan Mayen' => _x('Svalbard and Jan Mayen', 'ui', 'memberpress'),
  // No states of this Country

);

?>