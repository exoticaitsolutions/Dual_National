<?php
/**
 * Gabon states
 */
$states['Gabon'] = array(
  'Estuaire' => _x('Estuaire', 'ui', 'memberpress'),
  'Haut-Ogooue' => _x('Haut-Ogooue', 'ui', 'memberpress'),
  'Moyen-Ogooue' => _x('Moyen-Ogooue', 'ui', 'memberpress'),
  'Ngounie' => _x('Ngounie', 'ui', 'memberpress'),
  'Nyanga' => _x('Nyanga', 'ui', 'memberpress'),
  'Ogooue-Ivindo' => _x('Ogooue-Ivindo', 'ui', 'memberpress'),
  'Ogooue-Lolo' => _x('Ogooue-Lolo', 'ui', 'memberpress'),
  'Ogooue-Maritime' => _x('Ogooue-Maritime', 'ui', 'memberpress'),
  'Woleu-Ntem' => _x('Woleu-Ntem', 'ui', 'memberpress')
  
);
