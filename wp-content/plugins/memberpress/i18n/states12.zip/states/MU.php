<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  'Agalega Islands' => _x('Agalega Islands', 'ui', 'memberpress'),
  'Black River' => _x('Black River', 'ui', 'memberpress'),
  'Cargados Carajos Shoals' => _x('Cargados Carajos Shoals', 'ui', 'memberpress'),
  'Flacq' => _x('Flacq', 'ui', 'memberpress'),
  'Grand Port' => _x('Grand Port', 'ui', 'memberpress'),
  'Moka' => _x('Moka', 'ui', 'memberpress'),
  'Pamplemousses' => _x('Pamplemousses', 'ui', 'memberpress'),
  'Plaines Wilhems' => _x('Plaines Wilhems', 'ui', 'memberpress'),
  'Port Louis' => _x('Port Louis', 'ui', 'memberpress'),
  'Riviere du Rempart' => _x('Riviere du Rempart', 'ui', 'memberpress'),
  'Rodrigues' => _x('Rodrigues', 'ui', 'memberpress'),
  'Savanne' => _x('Savanne', 'ui', 'memberpress')
);

?>