<?php
/**
 * Guyana states
 */
$states['Guyana'] = array(
  'Barima-Waini' => _x('Barima-Waini', 'ui', 'memberpress'),
  'Cuyuni-Mazaruni' => _x('Cuyuni-Mazaruni', 'ui', 'memberpress'),
  'Demerara-Mahaica' => _x('Demerara-Mahaica', 'ui', 'memberpress'), 
  'East Berbice-Corentyne' => _x('East Berbice-Corentyne', 'ui', 'memberpress'), 
  'Essequibo Islands-West Demerara' => _x('Essequibo Islands-West Demerara', 'ui', 'memberpress'), 
  'Mahaica-Berbice' => _x('Mahaica-Berbice', 'ui', 'memberpress'), 
  'Pomeroon-Supenaam' => _x('Pomeroon-Supenaam', 'ui', 'memberpress'), 
  'Potaro-Siparuni' => _x('Potaro-Siparuni', 'ui', 'memberpress'), 
  'Upper Demerara-Berbice' => _x('Upper Demerara-Berbice', 'ui', 'memberpress'), 
  'Potaro-Siparuni' => _x('Potaro-Siparuni', 'ui', 'memberpress'), 
  'Upper Takutu-Upper Essequibo' => _x('Upper Takutu-Upper Essequibo', 'ui', 'memberpress'), 
);


