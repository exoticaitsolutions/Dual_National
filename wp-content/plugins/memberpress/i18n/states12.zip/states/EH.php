<?php
/**
 * Western Sahara states
 */
$states['Western Sahara'] = array(
  'No State of this country' => _x('No State of this country', 'ui', 'memberpress'),
);

?>