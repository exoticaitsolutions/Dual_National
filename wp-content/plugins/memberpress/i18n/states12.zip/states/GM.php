

<?php
/**
 * Gambia states
 */
$states['Gambia'] = array(
  'Banjul' => _x('Banjul', 'ui', 'memberpress'),
  'Central River' => _x('Central River', 'ui', 'memberpress'),
  'Lower River' => _x('Lower River', 'ui', 'memberpress'),
  'North Bank' => _x('North Bank', 'ui', 'memberpress'),
  'Upper River' => _x('Upper River', 'ui', 'memberpress'),
  'Western' => _x('Western', 'ui', 'memberpress')

  
);

