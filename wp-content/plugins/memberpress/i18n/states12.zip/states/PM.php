<?php
/**
 * Saint Pierre and Miquelon states
 */
$states['Saint Pierre and Miquelon'] = array(
  'Miquelon-Langlade' => _x('Miquelon-Langlade', 'ui', 'memberpress'),
  'Saint Pierre' => _x('Saint Pierre', 'ui', 'memberpress')
);

?>