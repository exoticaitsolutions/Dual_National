<?php
/**
 * Djibouti  States
 */
 $states['Djibouti'] = array(
    'Ali Sabih'       => _x('Ali Sabih', 'ui', 'memberpress'),
    'Dikhil'       => _x('Dikhil', 'ui', 'memberpress'),
    'Djibouti'       => _x('Djibouti', 'ui', 'memberpress'),
    'Obock'       => _x('Obock', 'ui', 'memberpress'),
    'Tadjoura'       => _x('Tadjoura', 'ui', 'memberpress')
  );
 ?>