<?php
/**
 * Falkland Islands states
 */
$states['Falkland Islands'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
  
);

