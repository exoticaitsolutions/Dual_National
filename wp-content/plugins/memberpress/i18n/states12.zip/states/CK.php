
<?php
/**
 * Cook Islands  States
 */
 $states['Cook Islands'] = array(
    
    'Cook Islands'       => _x('Cook Islands', 'ui', 'memberpress')
    
  );
 ?>