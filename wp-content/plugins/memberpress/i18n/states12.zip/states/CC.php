<?php
/**
 * Cocos (Keeling) Islands  States
 */
 $states['Cocos (Keeling) Islands'] = array(
    
    'Cocos (Keeling) Islands'       => _x('Cocos (Keeling) Islands', 'ui', 'memberpress')
    
  );
 ?>