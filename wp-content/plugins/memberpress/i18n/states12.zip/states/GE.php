<?php
/**
 * Georgia states
 */
$states['Georgia'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
  
);

