<?php
/**
 * Vanuatu states
 */
$states['Vanuatu'] = array(
  'Malampa'  => _x('Malampa', 'ui', 'memberpress'),
  'Penama'  => _x('Penama', 'ui', 'memberpress'),
  'Sanma'  => _x('Sanma', 'ui', 'memberpress'),
  'Shefa' => _x('Shefa', 'ui', 'memberpress'),
  'Tafea'  => _x('Tafea', 'ui', 'memberpress'),
  'Torba'  => _x('Torba', 'ui', 'memberpress')
);

