<?php
/**
 * Bosnia and Herzegovina State
 */
$states['Bosnia and Herzegovina '] = array(
  'Una-Sana'         => _x('Una-Sana', 'ui', 'memberpress'),
  'Posavina '         => _x('Posavina ', 'ui', 'memberpress'),
  'Tuzla'         => _x('Tuzla', 'ui', 'memberpress'),
  'Zenica-Doboj'         => _x('Zenica-Doboj', 'ui', 'memberpress'),
  'Bosnian Podrinje'         => _x('Bosnian Podrinje', 'ui', 'memberpress'),
  'Central Bosnia '         => _x('Central Bosnia ', 'ui', 'memberpress'),
  'Herzegovina-Neretva'         => _x('Herzegovina-Neretva', 'ui', 'memberpress'),
  'West Herzegovina'         => _x('West Herzegovina', 'ui', 'memberpress'),
  'Sarajevo'         => _x('Sarajevo', 'ui', 'memberpress'),
  'West Bosnia'         => _x('West Bosnia', 'ui', 'memberpress'),
  'Banja Luka'         => _x('Banja Luka', 'ui', 'memberpress'),
  'Bijeljina '         => _x('Bijeljina ', 'ui', 'memberpress'),
  'Doboj '         => _x('Doboj ', 'ui', 'memberpress'),
  'Fo?a'         => _x('Fo?a', 'ui', 'memberpress'),
  'Sarajevo-Romanija'         => _x('Sarajevo-Romanija', 'ui', 'memberpress'),
  'Trebinje '         => _x('Trebinje ', 'ui', 'memberpress'),
  'Vlasenica'         => _x('Vlasenica', 'ui', 'memberpress')    
);


?>
