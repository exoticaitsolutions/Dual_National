<?php
/**
 * Pakistan states
 */
$states['Pakistan'] = array(
  'Balochistan' => _x('Balochistan', 'ui', 'memberpress'),
  'North-West Frontier Province' => _x('North-West Frontier Province', 'ui', 'memberpress'),
  'Punjab' => _x('Punjab', 'ui', 'memberpress'),
  'Sindh' => _x('Sindh', 'ui', 'memberpress'),
  'Islamabad Capital Territory' => _x('Islamabad Capital Territory', 'ui', 'memberpress'),
  'Federally Administered Tribal Areas' => _x('Federally Administered Tribal Areas', 'ui', 'memberpress'),
  'Gilgit-Baltistan' => _x('Gilgit-Baltistan', 'ui', 'memberpress'),
  'Azad Kashmir ' => _x('Azad Kashmir ', 'ui', 'memberpress')
);

?>