<?php
/**
 * El Salvador states
 */
$states['El Salvador'] = array(
  'Ahuachapan'       => _x('Ahuachapan', 'ui', 'memberpress'),
  'Cabanas'       => _x('Cabanas', 'ui', 'memberpress'),
  'Chalatenango'       => _x('Chalatenango', 'ui', 'memberpress'),
  'Cuscatlan'       => _x('Cuscatlan', 'ui', 'memberpress'),
  'La Libertad'       => _x('La Libertad', 'ui', 'memberpress'),
  'La Paz'       => _x('La Paz', 'ui', 'memberpress'),
  'La Union'       => _x('La Union', 'ui', 'memberpress'),
  'Morazan'       => _x('Morazan', 'ui', 'memberpress'),
  'San Miguel'       => _x('San Miguel', 'ui', 'memberpress'),
  'San Salvador'       => _x('San Salvador', 'ui', 'memberpress'),
  'Santa Ana'       => _x('Santa Ana', 'ui', 'memberpress'),
  'San Vicente'       => _x('San Vicente', 'ui', 'memberpress'),
  'Sonsonate'       => _x('Sonsonate', 'ui', 'memberpress'),
  'Usulutan'       => _x('Usulutan', 'ui', 'memberpress')
);

