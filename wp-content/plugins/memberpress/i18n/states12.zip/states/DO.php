<?php
/**
 * Dominican Republic  States
 */
 $states['Dominican Republic'] = array(
       'Azua'    => _x('Azua', 'ui', 'memberpress'),
       'Baoruco'  => _x('Baoruco', 'ui', 'memberpress'),
       'Barahona'       => _x('Barahona', 'ui', 'memberpress'),
       'Dajabon'       => _x('Dajabon', 'ui', 'memberpress'),
       'Distrito Nacional'       => _x('Distrito Nacional', 'ui', 'memberpress'),
       'Elias Pina'       => _x('Elias Pina', 'ui', 'memberpress'),
       'El Seibo'       => _x('El Seibo', 'ui', 'memberpress'),
       'Espaillat'       => _x('Espaillat', 'ui', 'memberpress'),
       'Hato Mayor'       => _x('Hato Mayor', 'ui', 'memberpress'),
       'Independencia'       => _x('Independencia', 'ui', 'memberpress'),
       'La Altagracia'       => _x('La Altagracia', 'ui', 'memberpress'),
       'La Romana'       => _x('La Romana', 'ui', 'memberpress'),
       'La Vega'       => _x('La Vega', 'ui', 'memberpress'),
       'Maria Trinidad Sanchez'       => _x('Maria Trinidad Sanchez', 'ui', 'memberpress'),
       'Monsenor Nouel'       => _x('Praha', 'ui', 'memberpress'),
       'Monte Cristi'       => _x('Monte Cristi', 'ui', 'memberpress'),
       'Monte Plata'       => _x('Monte Plata', 'ui', 'memberpress'),
       'Pedernales'       => _x('Pedernales', 'ui', 'memberpress'),
       'Peravia'       => _x('Peravia', 'ui', 'memberpress'),
       'Puerto Plata'       => _x('Puerto Plata', 'ui', 'memberpress'),
       'Salcedo'       => _x('Salcedo', 'ui', 'memberpress'),
       'Samana'       => _x('Samana', 'ui', 'memberpress'),
       'Sanchez Ramirez'       => _x('Sanchez Ramirez', 'ui', 'memberpress'),
       'San Cristobal'       => _x('San Cristobal', 'ui', 'memberpress'),
       'San Jose de Ocoa'       => _x('San Jose de Ocoa', 'ui', 'memberpress'),
       'San Juan'       => _x('San Juan', 'ui', 'memberpress'),
       'San Pedro de Macoris'       => _x('San Pedro de Macoris', 'ui', 'memberpress'),
       'Santiago'       => _x('Santiago', 'ui', 'memberpress'),
       'Santiago Rodriguez'       => _x('Santiago Rodriguez', 'ui', 'memberpress'),
       'Santo Domingo'       => _x('Santo Domingo', 'ui', 'memberpress'),
       'Valverde'       => _x('Valverde', 'ui', 'memberpress')
  );
 ?>