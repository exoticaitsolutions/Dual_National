<?php
/**
 * Ecuador  States
 */

 $states['Ecuador'] = array(
       'Azuay'    => _x('Azuay', 'ui', 'memberpress'),
       'Bolivar'    => _x('Bolivar', 'ui', 'memberpress'),
       'Canar'    => _x('Canar', 'ui', 'memberpress'),
       'Carchi'    => _x('Carchi', 'ui', 'memberpress'),
       'Chimborazo'    => _x('Chimborazo', 'ui', 'memberpress'),
       'Cotopaxi'    => _x('Cotopaxi', 'ui', 'memberpress'),
       'El Oro'    => _x('El Oro', 'ui', 'memberpress'),
       'Esmeraldas'    => _x('Esmeraldas', 'ui', 'memberpress'),
       'Galapagos'    => _x('Galapagos', 'ui', 'memberpress'),
       'Guayas'    => _x('Guayas', 'ui', 'memberpress'),
       'Imbabura'    => _x('Imbabura', 'ui', 'memberpress'),
       'Loja'    => _x('Loja', 'ui', 'memberpress'),
       'Los Rios'    => _x('Los Rios', 'ui', 'memberpress'),
       'Manabi'    => _x('Manabi', 'ui', 'memberpress'),
       'Morona-Santiago'    => _x('Morona-Santiago', 'ui', 'memberpress'),
       'Napo'    => _x('Napo', 'ui', 'memberpress'),
       'Orellana'    => _x('Orellana', 'ui', 'memberpress'),
       'Pastaza'    => _x('Pastaza', 'ui', 'memberpress'),
       'Pichincha'    => _x('Pichincha', 'ui', 'memberpress'),
       'Sucumbios'    => _x('Sucumbios', 'ui', 'memberpress'),
       'Sucumbios'    => _x('Sucumbios', 'ui', 'memberpress'),
       'Tungurahua'    => _x('Tungurahua', 'ui', 'memberpress'),
       'Tungurahua'    => _x('Tungurahua', 'ui', 'memberpress'),
       'Zamora-Chinchipe'    => _x('Zamora-Chinchipe', 'ui', 'memberpress')
  );
 ?>