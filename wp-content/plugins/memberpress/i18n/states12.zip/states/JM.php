<?php
/**
 * Jamaica states
 */
$states['Jamaica'] = array(
    'Clarendon'                  => _x('Clarendon', 'ui', 'memberpress'),
    'Hanover'                    => _x('Hanover', 'ui', 'memberpress'),
    'Kingston'                   => _x('Kingston', 'ui', 'memberpress'),
    'Manchester'                 => _x('Manchester', 'ui', 'memberpress'),
    'Portland'                   => _x('Portland', 'ui', 'memberpress'),
    'Saint Andrew'               => _x('Saint Andrew', 'ui', 'memberpress'),
    'Saint Ann'                  => _x('Saint Ann', 'ui', 'memberpress'),
    'Saint Catherine'            => _x('Saint Catherine', 'ui', 'memberpress'),
    'Saint Elizabeth'            => _x('Saint Elizabeth', 'ui', 'memberpress'),
    'Saint James'                => _x('Saint James', 'ui', 'memberpress'),
    'Saint Mary'                 => _x('Saint Mary', 'ui', 'memberpress'),
    'Saint Thomas'               => _x('Saint Thomas', 'ui', 'memberpress'),
    'Trelawny'                   => _x('Trelawny', 'ui', 'memberpress'),
    'Westmoreland'               => _x('Westmoreland', 'ui', 'memberpress')
 
);

?>