<?php
/**
 * Congo, Democratic Republic  States
 */
 $states['Congo, Democratic Republic'] = array(
    'Bandundu'       => _x('Bandundu', 'ui', 'memberpress'),
    'Bas-Congo'       => _x('Bas-Congo', 'ui', 'memberpress'),
    'Equateur'       => _x('Equateur', 'ui', 'memberpress'),
    'Kasai-Occidental'       => _x('Kasai-Occidental', 'ui', 'memberpress'),
    'Kasai-Oriental'       => _x('Kasai-Oriental', 'ui', 'memberpress'),
    'Katanga'       => _x('Katanga', 'ui', 'memberpress'),
    'Kinshasa'       => _x('Kinshasa', 'ui', 'memberpress'),
    'Maniema'       => _x('Maniema', 'ui', 'memberpress'),
    'Nord-Kivu'       => _x('Nord-Kivu', 'ui', 'memberpress'),
    'Orientale'       => _x('Orientale', 'ui', 'memberpress'),
    'Sud-Kivu'       => _x('Sud-Kivu', 'ui', 'memberpress')
  );
 ?>