<?php
/**
 * Burkina Faso states
 */
$states['Burkina Faso'] = array(
    'Bale' => _x('Bale', 'ui', 'memberpress'),
    'Bam' => _x('Bam', 'ui', 'memberpress'),
    'Banwa' => _x('Banwa', 'ui', 'memberpress'),
    'Bazega' => _x('Bazega', 'ui', 'memberpress'),
    'Bougouriba' => _x('Bougouriba', 'ui', 'memberpress'),
    'Boulkiemde' => _x('Boulkiemde', 'ui', 'memberpress'),
    'Comoe' => _x('Comoe', 'ui', 'memberpress'),
    'Ganzourgou' => _x('Ganzourgou', 'ui', 'memberpress'),
    'Gnagna' => _x('Gnagna', 'ui', 'memberpress'),
    'Gourma' => _x('Gourma', 'ui', 'memberpress'),
    'Houet' => _x('Houet', 'ui', 'memberpress'),
    'Ioba' => _x('Ioba', 'ui', 'memberpress'),
    'Kadiogo' => _x('Kadiogo', 'ui', 'memberpress'),
    'Kenedougou' => _x('Kenedougou', 'ui', 'memberpress'),
    'Komondjari' => _x('Komondjari', 'ui', 'memberpress'),
    'Kompienga' => _x('Kompienga', 'ui', 'memberpress'),
    'Kossi' => _x('Kossi', 'ui', 'memberpress'),
    'Koulpelogo' => _x('Koulpelogo', 'ui', 'memberpress'),
    'Kouritenga' => _x('Kouritenga', 'ui', 'memberpress'),
    'Kourweogo' => _x('Kourweogo', 'ui', 'memberpress'),
    'Leraba' => _x('Leraba', 'ui', 'memberpress'),
    'Loroum' => _x('Loroum', 'ui', 'memberpress'),
    'Mouhoun' => _x('Mouhoun', 'ui', 'memberpress'),
    'Namentenga' => _x('Namentenga', 'ui', 'memberpress'),
    'Nahouri' => _x('Nahouri', 'ui', 'memberpress'),
    'Nayala' => _x('Nayala', 'ui', 'memberpress'),
    'Noumbiel' => _x('Noumbiel', 'ui', 'memberpress'),
    'Oubritenga' => _x('Oubritenga', 'ui', 'memberpress'),
    'Oudalan' => _x('Oudalan', 'ui', 'memberpress'),
    'Passore' => _x('Passore', 'ui', 'memberpress'),
    'Poni' => _x('Poni', 'ui', 'memberpress'),
    'Sanguie' => _x('Sanguie', 'ui', 'memberpress'),
    'Sanmatenga' => _x('Sanmatenga', 'ui', 'memberpress'),
    'Seno' => _x('Seno', 'ui', 'memberpress'),
    'Sissili' => _x('Sissili', 'ui', 'memberpress'),
    'Soum' => _x('Soum', 'ui', 'memberpress'),
    'Sourou' => _x('Sourou', 'ui', 'memberpress'),
    'Tapoa' => _x('Tapoa', 'ui', 'memberpress'),
    'Tuy' => _x('Tuy', 'ui', 'memberpress'),
    'Yagha' => _x('Yagha', 'ui', 'memberpress'),
    'Yatenga' => _x('Yatenga', 'ui', 'memberpress'),
    'Ziro' => _x('Ziro', 'ui', 'memberpress'),
    'Zondoma' => _x('Zondoma', 'ui', 'memberpress'),
    'Zoundweogo' => _x('Zoundweogo', 'ui', 'memberpress')


);


?>
