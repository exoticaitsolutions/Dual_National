<?php
/**
 * Republic of Ireland states
 */
$states['Republic of Ireland'] = array(
    'Carlow'              => _x('Carlow', 'ui', 'memberpress'),
    'Cavan'               => _x('Cavan', 'ui', 'memberpress'),
    'Clare'               => _x('Clare', 'ui', 'memberpress'),
    'Cork'                => _x('Cork', 'ui', 'memberpress'),
    'Donegal'             => _x('Donegal', 'ui', 'memberpress'),
    'Dublin'              => _x('Dublin', 'ui', 'memberpress'),
    'Galway'              => _x('Galway', 'ui', 'memberpress'),
    'Kerry'               => _x('Kerry', 'ui', 'memberpress'),
    'Kildare'             => _x('Kildare', 'ui', 'memberpress'),
    'Kilkenny'            => _x('Kilkenny', 'ui', 'memberpress'),
    'Laois'               => _x('Laois', 'ui', 'memberpress'),
    'Leitrim'             => _x('Leitrim', 'ui', 'memberpress'),
    'Limerick'            => _x('Limerick', 'ui', 'memberpress'),
    'Longford'            => _x('Longford', 'ui', 'memberpress'),
    'Louth'               => _x('Louth', 'ui', 'memberpress'),
    'Mayo'                => _x('Mayo', 'ui', 'memberpress'),
    'Meath'               => _x('Meath', 'ui', 'memberpress'),
    'Monaghan'            => _x('Monaghan', 'ui', 'memberpress'),
    'Offaly'              => _x('Offaly', 'ui', 'memberpress'),
    'Roscommon'           => _x('Roscommon', 'ui', 'memberpress'),
    'Sligo'               => _x('Sligo', 'ui', 'memberpress'),
    'Tipperary'           => _x('Tipperary', 'ui', 'memberpress'),
    'Waterford'           => _x('Waterford', 'ui', 'memberpress'),
    'Westmeath'           => _x('Westmeath', 'ui', 'memberpress'),
    'Wexford'             => _x('Wexford', 'ui', 'memberpress'),
    'Wicklow'             => _x('Wicklow', 'ui', 'memberpress')
       
);

?>