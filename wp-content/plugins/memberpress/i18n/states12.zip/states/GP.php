<?php
/**
 * Falkland Islands states
 */
$states['Guadeloupe'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
  
);

