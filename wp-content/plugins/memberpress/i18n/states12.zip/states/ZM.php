<?php
/**
 * Zambia states
 */
$states['Zambia'] = array(
  'Central'       => _x('Central', 'ui', 'memberpress'),
  'Copperbelt'       => _x('Copperbelt', 'ui', 'memberpress'),
  'Eastern'       => _x('Eastern', 'ui', 'memberpress'),
  'Lusaka'       => _x('Lusaka', 'ui', 'memberpress'),
  'Northern'       => _x('Northern', 'ui', 'memberpress'),
  'North-Western'       => _x('North-Western', 'ui', 'memberpress'),
  'Southern'       => _x('Southern', 'ui', 'memberpress'),
  'Western'       => _x('Western', 'ui', 'memberpress')
);
?>
