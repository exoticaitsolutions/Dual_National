<?php
/**
 *  Macao S.A.R., China
 */
$states['Macao S.A.R., China'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
  
);

