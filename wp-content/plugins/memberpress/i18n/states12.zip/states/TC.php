<?php
/**
 * Turks and Caicos Islands states
 */
$states['Turks and Caicos Islands'] = array(
  'Turks and Caicos Islands' => _x('Turks and Caicos Islands', 'ui', 'memberpress'),
  // No states of this Country

);

?>