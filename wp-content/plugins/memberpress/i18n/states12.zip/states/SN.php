<?php
/**
 * Senegal states
 */
$states['Senegal'] = array(
  'Dakar' => _x('Dakar', 'ui', 'memberpress'),
  'Diourbel' => _x('Diourbel', 'ui', 'memberpress'),
  'Fatick' => _x('Fatick', 'ui', 'memberpress'),
  'Kaolack' => _x('Kaolack', 'ui', 'memberpress'),
  'Kolda' => _x('Kolda', 'ui', 'memberpress'),
  'Louga' => _x('Louga', 'ui', 'memberpress'),
  'Matam' => _x('Matam', 'ui', 'memberpress'),
  'Saint-Louis' => _x('Saint-Louis', 'ui', 'memberpress'),
  'Tambacounda' => _x('Tambacounda', 'ui', 'memberpress'),
  'Thies' => _x('Thies', 'ui', 'memberpress'),
  'Ziguinchor' => _x('Ziguinchor', 'ui', 'memberpress')
);

?>