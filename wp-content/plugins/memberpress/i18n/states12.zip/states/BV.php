<?php
/**
 * Bouvet Island states
 */
$states['Bouvet Island'] = array(
  'Bouvet Island'         => _x('Bouvet Island', 'ui', 'memberpress'),
);


?>
