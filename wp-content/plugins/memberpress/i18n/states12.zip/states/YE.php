<?php
/**
 * Yemen states
 */
$states['Yemen'] = array(
  'Abyan'       => _x('Abyan', 'ui', 'memberpress'),
  'Adan'       => _x('Adan', 'ui', 'memberpress'),
  'Ad Dali'       => _x('Ad Dali', 'ui', 'memberpress'),
  'Al Bayda'       => _x('Al Bayda', 'ui', 'memberpress'),
  'Al Hudaydah'       => _x('Al Hudaydah', 'ui', 'memberpress'),
  'Al Jawf'       => _x('Al Jawf', 'ui', 'memberpress'),
  'Al Mahrah'       => _x('Al Mahrah', 'ui', 'memberpress'),
  'Al Mahwit'       => _x('Al Mahwit', 'ui', 'memberpress'),
  'Amran'       => _x('Amran', 'ui', 'memberpress'),
  'Dhamar'       => _x('Dhamar', 'ui', 'memberpress'),
  'Hadramawt'       => _x('Hadramawt', 'ui', 'memberpress'),
  'Hajjah'       => _x('Hajjah', 'ui', 'memberpress'),
  'Ibb'       => _x('Ibb', 'ui', 'memberpress'),
  'Lahij'       => _x('Lahij', 'ui', 'memberpress'),
  'Marib'       => _x('Marib', 'ui', 'memberpress'),
  'Sadah'       => _x('Sadah', 'ui', 'memberpress'),
  'Sana'       => _x('Sana', 'ui', 'memberpress'),
  'Shabwah'       => _x('Shabwah', 'ui', 'memberpress'),
  'Taizz'       => _x('Taizz', 'ui', 'memberpress'),
);

