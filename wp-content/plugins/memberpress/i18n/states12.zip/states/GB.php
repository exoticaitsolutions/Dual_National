<?php
/**
 * United Kingdom (UK) states
 */
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
$states['United Kingdom (UK)'] = array(
   'No State of this country' => _x('No State of this country', 'ui', 'memberpress')

);

