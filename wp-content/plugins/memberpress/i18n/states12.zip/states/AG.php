<?php
/**
 * Antigua and Barbuda states
 */
$states['Antigua and Barbuda states'] = array(
    'Barbuda'         => _x('Barbuda', 'ui', 'memberpress'),
    'Redonda'         => _x('Redonda', 'ui', 'memberpress'),
    'Saint George'         => _x('Saint George', 'ui', 'memberpress'),
    'Saint John'         => _x('Saint John', 'ui', 'memberpress'),
    'Saint Mary'         => _x('Saint Mary', 'ui', 'memberpress'),
    'Saint Paul'         => _x('Saint Paul', 'ui', 'memberpress'),
    'Saint Peter'         => _x('Saint Peter', 'ui', 'memberpress'),
    'Saint Philip'         => _x('Saint Philip', 'ui', 'memberpress')
);

?>