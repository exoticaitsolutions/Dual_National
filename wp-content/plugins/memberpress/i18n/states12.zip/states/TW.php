<?php
/**
 * Taiwan states
 */
$states['Taiwan'] = array(
  'Chang-hua' => _x('Chang-hua', 'ui', 'memberpress'),
  'Chia-i' => _x('Chia-i', 'ui', 'memberpress'),
  'Hsin-chu' => _x('Hsin-chu', 'ui', 'memberpress'),
  'Hua-lien' => _x('Hua-lien', 'ui', 'memberpress'),
  'I-lan' => _x('I-lan', 'ui', 'memberpress'),
  'Kao-hsiung' => _x('Kao-hsiung', 'ui', 'memberpress'),
  'Kin-men' => _x('Kin-men', 'ui', 'memberpress'),
  'Lien-chiang' => _x('Lien-chiang', 'ui', 'memberpress'),
  'Miao-li' => _x('Miao-li', 'ui', 'memberpress'),
  'Nan-t ou' => _x('Nan-t ou', 'ui', 'memberpress'),
  'P eng-hu' => _x('P eng-hu', 'ui', 'memberpress'),
  'P ing-tung' => _x('P ing-tung', 'ui', 'memberpress'),
  'T ai-chung' => _x('T ai-chung', 'ui', 'memberpress'),
  'T ai-nan' => _x('T ai-nan', 'ui', 'memberpress'),
  'T ai-pei' => _x('T ai-pei', 'ui', 'memberpress'),
  'T ai-tung' => _x('T ai-tung', 'ui', 'memberpress'),
  'T ao-yuan' => _x('T ao-yuan', 'ui', 'memberpress'),
  'Yun-lin' => _x('Yun-lin', 'ui', 'memberpress'),
  'Chia-i' => _x('Chia-i', 'ui', 'memberpress'),
  'Chi-lung' => _x('Chi-lung', 'ui', 'memberpress'),
  'Hsin-chu' => _x('Hsin-chu', 'ui', 'memberpress'),
  'T ai-chung' => _x('T ai-chung', 'ui', 'memberpress'),
  'T ai-nan' => _x('T ai-nan', 'ui', 'memberpress'),
  'Kao-hsiung city' => _x('Kao-hsiung city', 'ui', 'memberpress'),
  'T ai-pei city' => _x('T ai-pei city', 'ui', 'memberpress'),

);
