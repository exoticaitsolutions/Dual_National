<?php
/**
 * Tuvalu states
 */
$states['Tuvalu '] = array(
  'Tuvalu' => _x('Tuvalu', 'ui', 'memberpress')
);

