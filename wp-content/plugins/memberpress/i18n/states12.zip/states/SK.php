<?php
/**
 * Slovakia states
 */
$states['Slovakia'] = array(
  'Banskobystricky' => _x('Banskobystricky', 'ui', 'memberpress'),
  'Bratislavsky' => _x('Bratislavsky', 'ui', 'memberpress'),
  'Kosicky' => _x('Kosicky', 'ui', 'memberpress'),
  'Nitriansky' => _x('Nitriansky', 'ui', 'memberpress'),
  'Presovsky' => _x('Presovsky', 'ui', 'memberpress'),
  'Trenciansky' => _x('Trenciansky', 'ui', 'memberpress'),
  'Trnavsky' => _x('Trnavsky', 'ui', 'memberpress'),
  'Zilinsky' => _x('Zilinsky', 'ui', 'memberpress')
);

?>