<?php
/**
 * Papua New Guinea states
 */
$states['Papua New Guinea'] = array(
  'Bougainville' => _x('Bougainville', 'ui', 'memberpress'),
  'Central' => _x('Central', 'ui', 'memberpress'),
  'Chimbu' => _x('Chimbu', 'ui', 'memberpress'),
  'Eastern Highlands' => _x('Eastern Highlands', 'ui', 'memberpress'),
  'East New Britain' => _x('East New Britain', 'ui', 'memberpress'),
  'East Sepik' => _x('East Sepik', 'ui', 'memberpress'),
  'Enga' => _x('Enga', 'ui', 'memberpress'),
  'Gulf' => _x('Gulf', 'ui', 'memberpress'),
  'Madang' => _x('Madang', 'ui', 'memberpress'),
  'Manus' => _x('Manus', 'ui', 'memberpress'),
  'Milne Bay' => _x('Milne Bay', 'ui', 'memberpress'),
  'Morobe' => _x('Morobe', 'ui', 'memberpress'),
  'National Capital' => _x('National Capital', 'ui', 'memberpress'),
  'New Ireland' => _x('New Ireland', 'ui', 'memberpress'),
  'Northern' => _x('Northern', 'ui', 'memberpress'),
  'Sandaun' => _x('Sandaun', 'ui', 'memberpress'),
  'Southern Highlands' => _x('Southern Highlands', 'ui', 'memberpress'),
  'Western' => _x('Western', 'ui', 'memberpress'),
  'Western Highlands' => _x('Western Highlands', 'ui', 'memberpress'),
  'West New Britain' => _x('West New Britain', 'ui', 'memberpress')

);

?>