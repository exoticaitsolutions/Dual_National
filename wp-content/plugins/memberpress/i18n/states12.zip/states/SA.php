<?php
/**
 * Saudi Arabia states
 */
$states['Saudi Arabia'] = array(
  'Al Bahah' => _x('Al Bahah', 'ui', 'memberpress'),
  'Al Hudud ash Shamaliyah' => _x('Al Hudud ash Shamaliyah', 'ui', 'memberpress'),
  'Al Jawf' => _x('Al Jawf', 'ui', 'memberpress'),
  'Al Madinah' => _x('Al Madinah', 'ui', 'memberpress'),
  'Al Qasim' => _x('Al Qasim', 'ui', 'memberpress'),
  'Ar Riyad' => _x('Ar Riyad', 'ui', 'memberpress'),
  'Ash Sharqiyah' => _x('Ash Sharqiyah', 'ui', 'memberpress'),
  'Asir' => _x('Asir', 'ui', 'memberpress'),
  'Hail' => _x('Hail', 'ui', 'memberpress'),
  'Jizan' => _x('Jizan', 'ui', 'memberpress'),
  'Makkah' => _x('Makkah', 'ui', 'memberpress'),
  'Tabuk' => _x('Tabuk', 'ui', 'memberpress'),
  'Najran' => _x('Najran', 'ui', 'memberpress'),
);

?>