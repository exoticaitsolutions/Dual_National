<?php
/**
 * Somalia states
 */
$states['Somalia'] = array(
  'Awdal' => _x('Awdal', 'ui', 'memberpress'),
  'Bakool' => _x('Bakool', 'ui', 'memberpress'),
  'Banaadir' => _x('Banaadir', 'ui', 'memberpress'),
  'Bari' => _x('Bari', 'ui', 'memberpress'),
  'Bay' => _x('Bay', 'ui', 'memberpress'),
  'Galguduud' => _x('Galguduud', 'ui', 'memberpress'),
  'Gedo' => _x('Gedo', 'ui', 'memberpress'),
  'Hiiraan' => _x('Hiiraan', 'ui', 'memberpress'),
  'Jubbada Dhexe' => _x('Jubbada Dhexe', 'ui', 'memberpress'),
  'Jubbada Hoose' => _x('Jubbada Hoose', 'ui', 'memberpress'),
  'Mudug' => _x('Mudug', 'ui', 'memberpress'),
  'Nugaal' => _x('Nugaal', 'ui', 'memberpress'),
  'Sanaag' => _x('Sanaag', 'ui', 'memberpress'),
  'Shabeellaha Dhexe' => _x('Shabeellaha Dhexe', 'ui', 'memberpress'),
  'Shabeellaha Hoose' => _x('Shabeellaha Hoose', 'ui', 'memberpress'),
  'Sool' => _x('Sool', 'ui', 'memberpress'),
  'Togdheer' => _x('Togdheer', 'ui', 'memberpress'),
  'Woqooyi Galbeed' => _x('Woqooyi Galbeed', 'ui', 'memberpress')
);

?>