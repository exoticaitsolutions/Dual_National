<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  'Brokopondo' => _x('Brokopondo', 'ui', 'memberpress'),
  'Commewijne' => _x('Commewijne', 'ui', 'memberpress'),
  'Coronie' => _x('Coronie', 'ui', 'memberpress'),
  'Marowijne' => _x('Marowijne', 'ui', 'memberpress'),
  'Nickerie' => _x('Nickerie', 'ui', 'memberpress'),
  'Para' => _x('Para', 'ui', 'memberpress'),
  'Paramaribo' => _x('Paramaribo', 'ui', 'memberpress'),
  'Saramacca' => _x('Saramacca', 'ui', 'memberpress'),
  'Sipaliwini' => _x('Sipaliwini', 'ui', 'memberpress'),
  'Wanica' => _x('Wanica', 'ui', 'memberpress')
);

?>