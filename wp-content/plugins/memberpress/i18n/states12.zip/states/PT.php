<?php
/**
 * Portugal Regions
 */
$states['Portugal'] = array(
  'Norte' => _x('Norte', 'ui', 'memberpress'),
  'Centro' => _x('Centro', 'ui', 'memberpress'),
  'Lisboa e Vale do Tejo' => _x('Lisboa e Vale do Tejo', 'ui', 'memberpress'),
  'Algarve' => _x('Algarve', 'ui', 'memberpress'),
  'Alentejo' => _x('Alentejo', 'ui', 'memberpress'),
  'Madeira' => _x('Madeira', 'ui', 'memberpress'),
  'Açores' => _x('Açores', 'ui', 'memberpress')
);

