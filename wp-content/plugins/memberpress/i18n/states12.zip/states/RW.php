<?php
/**
 * Rwanda states
 */
$states['Rwanda'] = array(
  'Butare' => _x('Butare', 'ui', 'memberpress'),
  'Byumba' => _x('Byumba', 'ui', 'memberpress'),
  'Cyangugu' => _x('Cyangugu', 'ui', 'memberpress'),
  'Gikongoro' => _x('Gikongoro', 'ui', 'memberpress'),
  'Gisenyi' => _x('Gisenyi', 'ui', 'memberpress'),
  'Gitarama' => _x('Gitarama', 'ui', 'memberpress'),
  'Kibungo' => _x('Kibungo', 'ui', 'memberpress'),
  'Kibuye' => _x('Kibuye', 'ui', 'memberpress'),
  'Kigali Rurale' => _x('Kigali Rurale', 'ui', 'memberpress'),
  'Kigali-ville' => _x('Kigali-ville', 'ui', 'memberpress'),
  'Umutara' => _x('Umutara', 'ui', 'memberpress'),
  'Ruhengeri' => _x('Ruhengeri', 'ui', 'memberpress')
);

?>