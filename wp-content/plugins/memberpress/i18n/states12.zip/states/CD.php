<?php
/**
 * Congo (Kinshasa)  States
 */
 $states['Congo (Kinshasa)'] = array(
    'Bouenza'       => _x('Bouenza', 'ui', 'memberpress'),
    'Brazzaville'       => _x('Brazzaville', 'ui', 'memberpress'),
    'Cuvette'       => _x('Cuvette', 'ui', 'memberpress'),
    'Cuvette-Ouest'       => _x('Cuvette-Ouest', 'ui', 'memberpress'),
    'Kouilou'       => _x('Kouilou', 'ui', 'memberpress'),
    'Lekoumou'       => _x('Lekoumou', 'ui', 'memberpress'),
    'Likouala'       => _x('Likouala', 'ui', 'memberpress'),
    'Niari'       => _x('Niari', 'ui', 'memberpress'),
    'Plateaux'       => _x('Plateaux', 'ui', 'memberpress'),
    'Pool'       => _x('Pool', 'ui', 'memberpress'),
    'Sangha'       => _x('Sangha', 'ui', 'memberpress')
  );
 ?>