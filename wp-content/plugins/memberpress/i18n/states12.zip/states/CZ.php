<?php
/**
 * Czech Republic  States
 */
 $states['Czech Republic'] = array(
    'Jihocesky Kraj'       => _x('Jihocesky Kraj', 'ui', 'memberpress'),
    'Jihomoravsky Kraj'       => _x('Jihomoravsky Kraj', 'ui', 'memberpress'),
    'Karlovarsky Kraj'       => _x('Karlovarsky Kraj', 'ui', 'memberpress'),
    'Kralovehradecky Kraj'       => _x('Kralovehradecky Kraj', 'ui', 'memberpress'),
    'Liberecky Kra'       => _x('Liberecky Kra', 'ui', 'memberpress'),
    'Moravskoslezsky Kraj'       => _x('Moravskoslezsky Kraj', 'ui', 'memberpress'),
    'Kraj'       => _x('Kraj', 'ui', 'memberpress'),
    'Pardubicky Kraj'       => _x('Batdambang', 'ui', 'memberpress'),
    'Plzensky Kraj'       => _x('Plzensky Kraj', 'ui', 'memberpress'),
    'Praha'       => _x('Praha', 'ui', 'memberpress'),
    'Stredocesky Kraj'       => _x('Stredocesky Kraj', 'ui', 'memberpress'),
    'Ustecky Kraj'       => _x('Ustecky Kraj', 'ui', 'memberpress'),
    'Vysocina'       => _x('Vysocina', 'ui', 'memberpress'),
    'Zlinsky Kraj'       => _x('Zlinsky Kraj', 'ui', 'memberpress')
  );
 ?>