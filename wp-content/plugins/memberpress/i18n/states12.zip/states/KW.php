<?php
/**
 * Kuwait states
 */
$states['Kuwait'] = array(
    'Al Ahmadi'                       => _x('Al Ahmadi', 'ui', 'memberpress'),
    'Al Farwaniyah'                   => _x('Al Farwaniyah', 'ui', 'memberpress'),
    'Al Asimah'                       => _x('Al Asimah', 'ui', 'memberpress'),
    'Al Jahra'                        => _x('Al Jahra', 'ui', 'memberpress'),
    'Hawalli'                         => _x('Hawalli', 'ui', 'memberpress'),
    'Mubarak Al-Kabeer'               => _x('Mubarak Al-Kabeer', 'ui', 'memberpress')
);

?>