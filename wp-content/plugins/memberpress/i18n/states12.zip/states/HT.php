<?php
/**
 * Haiti states
 */
$states['Haiti'] = array(
  'Artibonite' => _x('Artibonite', 'ui', 'memberpress'),
  'Centre' => _x('Centre', 'ui', 'memberpress'),
  'Grand' => _x('Grand', 'ui', 'memberpress'),
  'Anse' => _x('Anse', 'ui', 'memberpress'),
  'Nord' => _x('Nord', 'ui', 'memberpress'),
  'Nord-Est' => _x('Nord-Est', 'ui', 'memberpress'),
  'Nord-Ouest' => _x('Nord-Ouest', 'ui', 'memberpress'),
  'Ouest' => _x('Ouest', 'ui', 'memberpress'),
  'Sud' => _x('Sud', 'ui', 'memberpress'),
  'Sud-Est' => _x('Sud-Est', 'ui', 'memberpress')
  
);

