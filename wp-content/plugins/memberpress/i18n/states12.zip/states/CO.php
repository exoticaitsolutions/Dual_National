<?php
/**
 * Colombia  States
 */
 $states['Colombia'] = array(
    'Amazonas'       => _x('Amazonas', 'ui', 'memberpress'),
    'Antioquia'       => _x('Antioquia', 'ui', 'memberpress'),
    'Arauca'       => _x('Arauca', 'ui', 'memberpress'),
    'Bogota District Capital'       => _x('Bogota District Capital', 'ui', 'memberpress'),
    'Bolivar'       => _x('Bolivar', 'ui', 'memberpress'),
    'Guainia'       => _x('Guainia', 'ui', 'memberpress'),
    'Guaviare'       => _x('Guaviare', 'ui', 'memberpress'),
    'Huila'       => _x('Huila', 'ui', 'memberpress'),
    'La Guajira'       => _x('La Guajira', 'ui', 'memberpress'),
    'Meta'       => _x('Meta', 'ui', 'memberpress'),
    'Narino'       => _x('Narino', 'ui', 'memberpress'),
    'Norte de Santander'       => _x('Norte de Santander', 'ui', 'memberpress'),
    'Risaralda'       => _x('Risaralda', 'ui', 'memberpress'),
    'San Andres & Providencia'       => _x('San Andres & Providencia', 'ui', 'memberpress'),
    'Santander'       => _x('Santander', 'ui', 'memberpress'),
    'Sucre'       => _x('Sucre', 'ui', 'memberpress'),
    'Tolima'       => _x('Tolima', 'ui', 'memberpress'),
    'Valle del Cauca'       => _x('Valle del Cauca', 'ui', 'memberpress'),
    'Vaupes'       => _x('Vaupes', 'ui', 'memberpress')
  );
 ?>