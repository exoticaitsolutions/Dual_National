<?php
/**
 * Norfolk Island states
 */
$states['Norfolk Island'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
  // No states of this Country

);

?>