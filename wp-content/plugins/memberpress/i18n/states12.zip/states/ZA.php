<?php
/**
 * South African states
 */
$states['South Africa'] = array(
  'Eastern Cape'  => _x('Eastern Cape', 'ui', 'memberpress'),
  'Free State'  => _x('Free State', 'ui', 'memberpress'),
  'Gauteng'  => _x('Gauteng', 'ui', 'memberpress'),
  'KwaZulu-Natal' => _x('KwaZulu-Natal', 'ui', 'memberpress'),
  'Limpopo'  => _x('Limpopo', 'ui', 'memberpress'),
  'Mpumalanga'  => _x('Mpumalanga', 'ui', 'memberpress'),
  'Northern Cape'  => _x('Northern Cape', 'ui', 'memberpress'),
  'North West'  => _x('North West', 'ui', 'memberpress'),
  'Western Cape'  => _x('Western Cape', 'ui', 'memberpress')
);

