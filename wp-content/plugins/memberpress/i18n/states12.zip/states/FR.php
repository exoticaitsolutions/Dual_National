<?php
/**
 * Faroe Islands states
 */
$states['France'] = array(
  'Alsace' => _x('Alsace', 'ui', 'memberpress'),
  'Aquitaine' => _x('Aquitaine', 'ui', 'memberpress'),
  'Auvergne' => _x('Auvergne', 'ui', 'memberpress'),
  'Basse-Normandie' => _x('Basse-Normandie', 'ui', 'memberpress'),
  'Bourgogne' => _x('Bourgogne', 'ui', 'memberpress'),
  'Bretagne' => _x('Bretagne', 'ui', 'memberpress'),
  'Centre' => _x('Centre', 'ui', 'memberpress'),
  'Champagne-Ardenne' => _x('Champagne-Ardenne', 'ui', 'memberpress'),
  'Corse' => _x('Corse', 'ui', 'memberpress'),
  'Franche-Comte' => _x('Franche-Comte', 'ui', 'memberpress'),
  'Haute-Normandie' => _x('Haute-Normandie', 'ui', 'memberpress'),
  'Ile-de-France' => _x('Ile-de-France', 'ui', 'memberpress'),
  'Languedoc-Roussillon' => _x('Languedoc-Roussillon', 'ui', 'memberpress'),
  'Limousin' => _x('Limousin', 'ui', 'memberpress'),
  'Lorraine' => _x('Lorraine', 'ui', 'memberpress'),
  'Midi-Pyrenees' => _x('Midi-Pyrenees', 'ui', 'memberpress'),
  'Nord-Pas-de-Calais' => _x('Nord-Pas-de-Calais', 'ui', 'memberpress'),
  'Picardie' => _x('Picardie', 'ui', 'memberpress'),
  'Poitou-Charentes' => _x('Poitou-Charentes', 'ui', 'memberpress'),
  'Provence-Alpes-Cote dAzur' => _x('Provence-Alpes-Cote dAzur', 'ui', 'memberpress'),
  'Rhone-Alpes' => _x('Rhone-Alpes', 'ui', 'memberpress')
  
);
