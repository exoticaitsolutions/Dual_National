<?php
/**
 * Switzerland states
 */
$states['Switzerland'] = array(
  'Aargau' => _x('Aargau', 'ui', 'memberpress'),
  'Appenzell Ausser-Rhoden' => _x('Appenzell Ausser-Rhoden', 'ui', 'memberpress'),
  'Appenzell Inner-Rhoden' => _x('Appenzell Inner-Rhoden', 'ui', 'memberpress'),
  'Basel-Landschaft' => _x('Basel-Landschaft', 'ui', 'memberpress'),
  'Basel-Stadt' => _x('Basel-Stadt', 'ui', 'memberpress'),
  'Bern' => _x('Bern', 'ui', 'memberpress'),
  'Fribourg' => _x('Fribourg', 'ui', 'memberpress'),
  'Geneve' => _x('Geneve', 'ui', 'memberpress'),
  'Glarus' => _x('Glarus', 'ui', 'memberpress'),
  'Graubunden' => _x('Graubunden', 'ui', 'memberpress'),
  'Jura' => _x('Jura', 'ui', 'memberpress'),
  'Luzern' => _x('Luzern', 'ui', 'memberpress'),
  'Neuchatel' => _x('Neuchatel', 'ui', 'memberpress'),
  'Obwalden' => _x('Obwalden', 'ui', 'memberpress'),
  'Sankt Gallen' => _x('Sankt Gallen', 'ui', 'memberpress'),
  'Schaffhausen' => _x('Schaffhausen', 'ui', 'memberpress'),
  'Schwyz' => _x('Schwyz', 'ui', 'memberpress'),
  'Solothurn' => _x('Solothurn', 'ui', 'memberpress'),
  'Thurgau' => _x('Thurgau', 'ui', 'memberpress'),
  'Ticino' => _x('Ticino', 'ui', 'memberpress'),
  'Uri' => _x('Uri', 'ui', 'memberpress'),
  'Valais' => _x('Valais', 'ui', 'memberpress'),
  'Vaud' => _x('Vaud', 'ui', 'memberpress'),
  'Zug' => _x('Zug', 'ui', 'memberpress'),
  'Zurich' => _x('Zurich', 'ui', 'memberpress'),

);
