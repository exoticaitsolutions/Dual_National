<?php
/**
 * Tokelau states
 */
$states['Tokelau'] = array(
  'Tokelau' => _x('Tokelau', 'ui', 'memberpress'),
  // No states of this Country

);

?>