<?php
/**
 * Egypt  States
 */

 $states['Egypt'] = array(
    //       "states": ["Ad Daqahliyah", "Al Bahr al Ahmar", "Al Buhayrah", "Al Fayyum", "Al Gharbiyah", "Al Iskandariyah", "Al Isma'iliyah", "Al Jizah", "Al Minufiyah", "Al Minya", "Al Qahirah", "Al Qalyubiyah", "Al Wadi al Jadid", "Ash Sharqiyah", "As Suways", "Aswan", "Asyut", "Bani Suwayf", "Bur Sa'id", "Dumyat", "Janub Sina'", "Kafr ash Shaykh", "Matruh", "Qina", "Shamal Sina'", "Suhaj"]

       'Ad Daqahliyah'    => _x('Ad Daqahliyah', 'ui', 'memberpress'),
       'Al Bahr al Ahmar'    => _x('Al Bahr al Ahmar', 'ui', 'memberpress'),
       'Al Buhayrah'    => _x('Al Buhayrah', 'ui', 'memberpress'),
       'Al Fayyum'    => _x('Al Fayyum', 'ui', 'memberpress'),
       'Al Gharbiyah'    => _x('Al Gharbiyah', 'ui', 'memberpress'),
       'Al Iskandariyah'    => _x('Al Iskandariyah', 'ui', 'memberpress'),
       "Al Isma'iliyah"    => _x("Al Isma'iliyah", 'ui', 'memberpress'),
       'Al Jizah'    => _x('Al Jizah', 'ui', 'memberpress'),
       'Al Minufiyah'    => _x('Al Minufiyah', 'ui', 'memberpress'),
       'Al Minya'    => _x('Al Minya', 'ui', 'memberpress'),
       'Al Qahirah'    => _x('Al Qahirah', 'ui', 'memberpress'),
       'Al Qalyubiyah'    => _x('Al Qalyubiyah', 'ui', 'memberpress'),
       'Al Wadi al Jadid'    => _x('Al Wadi al Jadid', 'ui', 'memberpress'),
       'Ash Sharqiyah'    => _x('Ash Sharqiyah', 'ui', 'memberpress'),
       'As Suways'    => _x('As Suways', 'ui', 'memberpress'),
       'Bani Suwayf'    => _x('Bani Suwayf', 'ui', 'memberpress'),
       "Bur Sa'id"    => _x("Bur Sa'id", 'ui', 'memberpress'),
       'Dumyat'    => _x('Dumyat', 'ui', 'memberpress'),
       'Janub Sina'    => _x('Janub Sina', 'ui', 'memberpress'),
       'Kafr ash Shaykh'    => _x('Kafr ash Shaykh', 'ui', 'memberpress'),
       'Matruh'    => _x('Matruh', 'ui', 'memberpress'),
       'Qina'    => _x('Qina', 'ui', 'memberpress'),
       'Shamal Sina'    => _x('Azuay', 'ui', 'memberpress'),
       'Suhaj'    => _x('Azuay', 'ui', 'memberpress')
  );
 ?>