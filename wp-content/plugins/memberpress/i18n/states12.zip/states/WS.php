<?php
/**
 * Western Samoa states
 */
$states['ZimbWestern Samoa'] = array(
  'A ana' => _x('A ana', 'ui', 'memberpress'),
  'Aiga-i-le-Tai' => _x('Aiga-i-le-Tai', 'ui', 'memberpress'),
  'Atua' => _x('Atua', 'ui', 'memberpress'),
  'Fa asaleleaga' => _x('Fa asaleleaga', 'ui', 'memberpress'),
  'Gaga emauga' => _x('Gaga emauga', 'ui', 'memberpress'),
  'Gagaifomauga' => _x('Gagaifomauga', 'ui', 'memberpress'),
  'Palauli' => _x('Palauli', 'ui', 'memberpress'),
  'Satupa itea' => _x('Satupa itea', 'ui', 'memberpress'),
  'Tuamasaga' => _x('Tuamasaga', 'ui', 'memberpress'),
  'Va a-o-Fonoti' => _x('Va a-o-Fonoti', 'ui', 'memberpress'),
  'Vaisigano' => _x('Vaisigano', 'ui', 'memberpress'),
 
);
