<?php
/**
 * Lesotho states
 */
$states['Lesotho'] = array(
    'Berea'                       => _x('Berea', 'ui', 'memberpress'),
    'Butha-Buthe'                 => _x('Butha-Buthe', 'ui', 'memberpress'),
    'Leribe'                      => _x('Leribe', 'ui', 'memberpress'),
    'Mafeteng'                    => _x('Mafeteng', 'ui', 'memberpress'),
    'Maseru'                      => _x('Maseru', 'ui', 'memberpress'),
    'Mohale s Hoek'               => _x('Mohale s Hoek', 'ui', 'memberpress'),
    'Mokhotlong'                  => _x('Mokhotlong', 'ui', 'memberpress'),
    'Qachas Nek'                  => _x('Qachas Nek', 'ui', 'memberpress'),
    'Quthing'                     => _x('Quthing', 'ui', 'memberpress'),
    'Thaba-Tseka'                 => _x('Thaba-Tseka', 'ui', 'memberpress')
);

?>