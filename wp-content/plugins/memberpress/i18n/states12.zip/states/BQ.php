<?php
/**
 * Bonaire, Saint Eustatius and Saba states
 */
$states['Bonaire, Saint Eustatius and Saba'] = array(
    'Bonaire, Saint Eustatius and Saba'         => _x('Bonaire, Saint Eustatius and Saba', 'ui', 'memberpress'),

);


?>
