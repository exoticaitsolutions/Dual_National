<?php
/**
 * Guernsey states
 */
$states['Guinea'] = array(
  'Beyla' => _x('Beyla', 'ui', 'memberpress'),
  'Boffa' => _x('Boffa', 'ui', 'memberpress'),
  'Boke' => _x('Boke', 'ui', 'memberpress'),
  'Conakry' => _x('Conakry', 'ui', 'memberpress'),
  'Coyah' => _x('Coyah', 'ui', 'memberpress'),
  'Dabola' => _x('Dabola', 'ui', 'memberpress'),
  'Dalaba' => _x('Dalaba', 'ui', 'memberpress'),
  'Dinguiraye' => _x('Dinguiraye', 'ui', 'memberpress'),
  'Dubreka' => _x('Dubreka', 'ui', 'memberpress'),
  'Faranah' => _x('Faranah', 'ui', 'memberpress'),
  'Forecariah' => _x('Forecariah', 'ui', 'memberpress'),
  'Fria' => _x('Fria', 'ui', 'memberpress'),
  'Gaoual' => _x('Gaoual', 'ui', 'memberpress'),
  'Kankan' => _x('Kankan', 'ui', 'memberpress'),
  'Gueckedou' => _x('Gueckedou', 'ui', 'memberpress'),
  'Kerouane' => _x('Kerouane', 'ui', 'memberpress'),
  'Kindia' => _x('Kindia', 'ui', 'memberpress'),
  'Koubia' => _x('Koubia', 'ui', 'memberpress'),
  'Koundara' => _x('Koundara', 'ui', 'memberpress'),
  'Kouroussa' => _x('Kouroussa', 'ui', 'memberpress'),
  'Labe' => _x('Labe', 'ui', 'memberpress'),
  'Lelouma' => _x('Lelouma', 'ui', 'memberpress'),
  'Lola' => _x('Lola', 'ui', 'memberpress'),
  'Macenta' => _x('Macenta', 'ui', 'memberpress'),
  'Mali' => _x('Mali', 'ui', 'memberpress'),
  'Mamou' => _x('Mamou', 'ui', 'memberpress'),
  'Mandiana' => _x('Mandiana', 'ui', 'memberpress'),
  'Nzerekore' => _x('Nzerekore', 'ui', 'memberpress'),
  'Pita' => _x('Pita', 'ui', 'memberpress'),
  'Kissidougou' => _x('Kissidougou', 'ui', 'memberpress'),
  'Siguiri' => _x('Siguiri', 'ui', 'memberpress'),
  'Telimele' => _x('Telimele', 'ui', 'memberpress'),
  'Tougue' => _x('Tougue', 'ui', 'memberpress'),
  'Yomou' => _x('Yomou', 'ui', 'memberpress')
  
);
