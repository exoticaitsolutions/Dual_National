<?php
/**
 * Tajikistan states
 */
$states['Tajikistan'] = array(
  'Sughd Region' => _x('Sughd Region', 'ui', 'memberpress'),
  'Districts of Republican Subordination' => _x('Districts of Republican Subordination', 'ui', 'memberpress'),
  'Khatlon Region' => _x('Khatlon Region', 'ui', 'memberpress'),
  'Gorno-Badakhshan Autonomous Region' => _x('Gorno-Badakhshan Autonomous Region', 'ui', 'memberpress'),
  'Dushanbe' => _x('Dushanbe', 'ui', 'memberpress'),
);
