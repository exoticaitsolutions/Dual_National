<?php
/**
 * Cambodia  States
 */
 $states['Cambodia'] = array(
    'Banteay Mean Che'       => _x('Banteay Mean Che', 'ui', 'memberpress'),
    'Batdambang'       => _x('Batdambang', 'ui', 'memberpress'),
    'Kampong Cham'       => _x('Kampong Cham', 'ui', 'memberpress'),
    'Kampong Chhnang'       => _x('Kampong Chhnang', 'ui', 'memberpress'),
    'Kampong Spoe'       => _x('Kampong Spoe', 'ui', 'memberpress'),
    'Kampong Thum'       => _x('Kampong Thum', 'ui', 'memberpress'),
    'Kandal'       => _x('Kandal', 'ui', 'memberpress'),
    'Koh Kong'       => _x('Koh Kong', 'ui', 'memberpress'),
    'Kracheh'       => _x('Kracheh', 'ui', 'memberpress'),
    'Mondol Kiri'       => _x('Mondol Kiri', 'ui', 'memberpress'),
    'Otdar Mean Chey'       => _x('Otdar Mean Chey', 'ui', 'memberpress'),
    'Pouthisat'       => _x('Pouthisat', 'ui', 'memberpress'),
    'Preah Vihear'       => _x('Preah Vihear', 'ui', 'memberpress'),
    'Prey Veng'       => _x('Bubanza', 'ui', 'memberpress'),
    'Rotanakir'       => _x('Rotanakir', 'ui', 'memberpress'),
    'Siem Reab'       => _x('Siem Reab', 'ui', 'memberpress'),
    'Stoeng Treng'       => _x('Stoeng Treng', 'ui', 'memberpress'),
    'Svay Rieng'       => _x('Svay Rieng', 'ui', 'memberpress'),
    'Takao'       => _x('Takao', 'ui', 'memberpress'),
    'Keb'       => _x('Keb', 'ui', 'memberpress'),
    'Pailin'       => _x('Bubanza', 'ui', 'memberpress'),
    'Phnom Penh'       => _x('Phnom Penh', 'ui', 'memberpress'),
    'Preah Seihanu'       => _x('Preah Seihanu', 'ui', 'memberpress')
  );
 ?>