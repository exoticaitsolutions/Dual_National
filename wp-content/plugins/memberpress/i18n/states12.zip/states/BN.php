<?php
/**
 * Brunei states
 */
$states['Brunei'] = array(
  'Belait'         => _x('Belait', 'ui', 'memberpress'),
  'Brunei and Muara'         => _x('Brunei and Muara', 'ui', 'memberpress'),
  'Temburong'         => _x('Temburong', 'ui', 'memberpress'),
  'Tutong'         => _x('Tutong', 'ui', 'memberpress')
);


?>
