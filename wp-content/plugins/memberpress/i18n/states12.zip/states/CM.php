<?php
/**
 * Cameroon  States
 */

 $states['Cameroon'] = array(
    'Adamaoua'       => _x('Adamaoua', 'ui', 'memberpress'),
    'Centre'       => _x('Centre', 'ui', 'memberpress'),
    'Est'       => _x('Batdambang', 'ui', 'memberpress'),
    'Extreme-Nord'       => _x('Extreme-Nord', 'ui', 'memberpress'),
    'Littoral'       => _x('Littoral', 'ui', 'memberpress'),
    'Nord'       => _x('Nord', 'ui', 'memberpress'),
    'Nord-Ouest'       => _x('Nord-Ouest', 'ui', 'memberpress'),
    'Ouest'       => _x('Ouest', 'ui', 'memberpress'),
    'Sud'       => _x('Sud', 'ui', 'memberpress'),
    'Sud-Ouest'       => _x('Sud-Ouest', 'ui', 'memberpress')
  );
 ?>