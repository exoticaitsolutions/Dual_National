<?php
/**
 * Croatia  States
 */
 $states['Croatia'] = array(
    'Bjelovarsko-Bilogorska'       => _x('Bjelovarsko-Bilogorska', 'ui', 'memberpress'),
    'Brodsko-Posavska'       => _x('Brodsko-Posavska', 'ui', 'memberpress'),
    'Istarska'       => _x('Istarska', 'ui', 'memberpress'),
    'Koprivnicko-Krizevacka'       => _x('Koprivnicko-Krizevacka', 'ui', 'memberpress'),
    'Krapinsko-Zagorska'       => _x('Krapinsko-Zagorska', 'ui', 'memberpress'),
    'Licko-Senjska'       => _x('Licko-Senjska', 'ui', 'memberpress'),
    'Osjecko-Baranjska'       => _x('Osjecko-Baranjska', 'ui', 'memberpress'),
    'Pozesko-Slavonska'       => _x('Pozesko-Slavonska', 'ui', 'memberpress'),
    'Primorsko-Goranska'       => _x('Primorsko-Goranska', 'ui', 'memberpress'),
    'Sibensko-Kninska'       => _x('Sibensko-Kninska', 'ui', 'memberpress'),
    'Sisacko-Moslavacka'       => _x('Sisacko-Moslavacka', 'ui', 'memberpress'),
    'Splitsko-Dalmatinska'       => _x('Splitsko-Dalmatinska', 'ui', 'memberpress'),
    'Varazdinska'       => _x('Varazdinska', 'ui', 'memberpress'),
    'Viroviticko-Podravska'       => _x('Viroviticko-Podravska', 'ui', 'memberpress'),
    'Vukovarsko-Srijemska'       => _x('Vukovarsko-Srijemska', 'ui', 'memberpress'),
    'Zadarska'       => _x('Zadarska', 'ui', 'memberpress'),
    'Zagreb'       => _x('Zagreb', 'ui', 'memberpress'),
    'Zagrebacka'       => _x('Zagrebacka', 'ui', 'memberpress')
  );
 ?>