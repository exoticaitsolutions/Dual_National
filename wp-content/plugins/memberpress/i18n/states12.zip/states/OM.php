<?php
/**
 * Oman states
 */
$states['Oman'] = array(
  'Ad Dakhiliyah' => _x('Ad Dakhiliyah', 'ui', 'memberpress'),
  'Al Batinah' => _x('Al Batinah', 'ui', 'memberpress'),
  'Al Wusta' => _x('Al Wusta', 'ui', 'memberpress'),
  'Ash Sharqiyah' => _x('Ash Sharqiyah', 'ui', 'memberpress'),
  'Az Zahirah' => _x('Az Zahirah', 'ui', 'memberpress'),
  'Masqat' => _x('Masqat', 'ui', 'memberpress'),
  'Musandam' => _x('Musandam', 'ui', 'memberpress'),
  'Dhofar' => _x('Dhofar', 'ui', 'memberpress')
);

?>