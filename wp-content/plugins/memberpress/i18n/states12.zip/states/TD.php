<?php
/**
 * Chad  States
 */
 $states['Chad'] = array(
    'Batha'       => _x('Batha', 'ui', 'memberpress'),
    'Biltine'       => _x('Biltine', 'ui', 'memberpress'),
    'Borkou-Ennedi-Tibesti'       => _x('Borkou-Ennedi-Tibesti', 'ui', 'memberpress'),
    'Chari-Baguirmi'       => _x('Chari-Baguirmi', 'ui', 'memberpress'),
    'Guéra'       => _x('Guéra', 'ui', 'memberpress'),
    'Kanem'       => _x('Kanem', 'ui', 'memberpress'),
    'Lac'       => _x('Lac', 'ui', 'memberpress'),
    'Logone Occidental'       => _x('Logone Occidental', 'ui', 'memberpress'),
    'Logone Oriental'       => _x('Logone Oriental', 'ui', 'memberpress'),
    'Mayo-Kebbi'       => _x('Mayo-Kebbi', 'ui', 'memberpress'),
    'Moyen-Chari'       => _x('Moyen-Chari', 'ui', 'memberpress'),
    'Ouaddaï'       => _x('Ouaddaï', 'ui', 'memberpress'),
    'Salamat'       => _x('Salamat', 'ui', 'memberpress'),
    'Tandjile'       => _x('Tandjile', 'ui', 'memberpress')
  );
 ?>