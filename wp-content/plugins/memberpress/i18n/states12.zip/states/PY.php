<?php
/**
 * Paraguay states
 */
$states['Paraguay'] = array(
  'Alto Paraguay' => _x('Alto Paraguay', 'ui', 'memberpress'),
  'Alto Parana' => _x('Alto Parana', 'ui', 'memberpress'),
  'Amambay' => _x('Amambay', 'ui', 'memberpress'),
  'Asuncion' => _x('Asuncion', 'ui', 'memberpress'),
  'Boqueron' => _x('Boqueron', 'ui', 'memberpress'),
  'Caaguazu' => _x('Caaguazu', 'ui', 'memberpress'),
  'Caazapa' => _x('Caazapa', 'ui', 'memberpress'),
  'Canindeyu' => _x('Canindeyu', 'ui', 'memberpress'),
  'Central' => _x('Central', 'ui', 'memberpress'),
  'Concepcion' => _x('Concepcion', 'ui', 'memberpress'),
  'Cordillera' => _x('Cordillera', 'ui', 'memberpress'),
  'Guaira' => _x('Guaira', 'ui', 'memberpress'),
  'Itapua' => _x('Itapua', 'ui', 'memberpress'),
  'Misiones' => _x('Misiones', 'ui', 'memberpress'),
  'Neembucu' => _x('Neembucu', 'ui', 'memberpress'),
  'Paraguari' => _x('Paraguari', 'ui', 'memberpress'),
  'Presidente Hayes' => _x('Presidente Hayes', 'ui', 'memberpress'),
);

?>