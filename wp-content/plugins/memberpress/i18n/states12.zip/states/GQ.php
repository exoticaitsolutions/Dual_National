<?php
/**
 * Equatorial Guinea states
 */
$states['Equatorial Guinea'] = array(
  'Anseba'       => _x('Anseba', 'ui', 'memberpress'), 
  'Debub'       => _x('Debub', 'ui', 'memberpress'), 
  'Debubawi Keyih Bahri'       => _x('Debubawi Keyih Bahri', 'ui', 'memberpress'), 
  'Gash Barka'       => _x('Gash Barka', 'ui', 'memberpress'), 
  'Maakel'       => _x('Maakel', 'ui', 'memberpress'), 
  'Semenawi Keyih Bahri'       => _x('Semenawi Keyih Bahri', 'ui', 'memberpress')

);

