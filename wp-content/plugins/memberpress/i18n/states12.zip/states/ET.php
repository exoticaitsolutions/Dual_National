<?php
/**
 * Ethiopia states
 */
$states['Ethiopia'] = array(
  'Addis Ababa' => _x('Addis Ababa', 'ui', 'memberpress'),
  'Afar' => _x('Afar', 'ui', 'memberpress'),
  'Amhara' => _x('Amhara', 'ui', 'memberpress'),
  'Binshangul Gumuz' => _x('Binshangul Gumuz', 'ui', 'memberpress'),
  'Dire Dawa' => _x('Dire Dawa', 'ui', 'memberpress'),
  'Gambela Hizboch' => _x('Gambela Hizboch', 'ui', 'memberpress'),
  'Harari' => _x('Harari', 'ui', 'memberpress'),
  'Oromia' => _x('Oromia', 'ui', 'memberpress'),
  'Somali' => _x('Somali', 'ui', 'memberpress'),
  'Tigray' => _x('Tigray', 'ui', 'memberpress'),
  'Southern Nations' => _x('Southern Nations', 'ui', 'memberpress'),
  'Nationalities' => _x('Nationalities', 'ui', 'memberpress')
  
);

