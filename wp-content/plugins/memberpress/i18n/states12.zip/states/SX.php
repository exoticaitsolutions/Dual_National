<?php
/**
 * Saint Martin (Dutch part) states
 */
$states['Saint Martin (Dutch part)'] = array(
  'Saint Martin (Dutch part)' => _x('Saint Martin (Dutch part)', 'ui', 'memberpress'),
  // No states of this Country

);

?>