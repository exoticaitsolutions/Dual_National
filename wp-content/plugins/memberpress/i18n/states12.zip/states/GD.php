<?php
/**
 * Greenland states
 */
$states['Grenada'] = array(
  'Carriacou and Petit Martinique' => _x('Carriacou and Petit Martinique', 'ui', 'memberpress'),
  'Saint Andrew' => _x('Saint Andrew', 'ui', 'memberpress'),
  'Saint David' => _x('Saint David', 'ui', 'memberpress'),
  'Saint George' => _x('Saint George', 'ui', 'memberpress'),
  'Saint John' => _x('Saint John', 'ui', 'memberpress'),
  'Saint Mark' => _x('Saint Mark', 'ui', 'memberpress'),
  'Saint Patrick' => _x('Saint Patrick', 'ui', 'memberpress')
   
);
