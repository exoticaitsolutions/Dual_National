<?php
/**
 * Algeria states
 */
$states['Algeria'] = array(
  'Adrar'       => _x('Adrar', 'ui', 'memberpress'),
  'Aïn Defla'       => _x('Aïn Defla', 'ui', 'memberpress'),
  'Aïn Témouchent'       => _x('Aïn Témouchent', 'ui', 'memberpress'),
  'Algiers'       => _x('Algiers', 'ui', 'memberpress'),
  'Annaba'       => _x('Annaba', 'ui', 'memberpress'),
  'Batna'       => _x('Batna', 'ui', 'memberpress'),
  'Béchar'       => _x('Béchar', 'ui', 'memberpress'),
  'Béjaïa'       => _x('Béjaïa', 'ui', 'memberpress'),
  'Biskra'       => _x('Biskra', 'ui', 'memberpress'),
  'Blida'       => _x('Blida', 'ui', 'memberpress'),
  'Bordj Bou Arréridj'       => _x('Bordj Bou Arréridj', 'ui', 'memberpress'),
  'Bouira'       => _x('Bouira', 'ui', 'memberpress'),
  'Boumerdès'       => _x('Boumerdès', 'ui', 'memberpress'),
  'Constantine'       => _x('Constantine', 'ui', 'memberpress'),
  'Djelfa'       => _x('Djelfa', 'ui', 'memberpress'),
  'El Oued'       => _x('El Oued', 'ui', 'memberpress'),
  'El Tarf'       => _x('El Tarf', 'ui', 'memberpress'),
  'Ghardaïa'       => _x('Ghardaïa', 'ui', 'memberpress'),
  'Guelma'       => _x('Guelma', 'ui', 'memberpress'),
  'Illizi'       => _x('Illizi', 'ui', 'memberpress'),
  'Jijel'       => _x('Jijel', 'ui', 'memberpress'),
  'Khenchela'       => _x('Khenchela', 'ui', 'memberpress'),
  'Laghouat'       => _x('Laghouat', 'ui', 'memberpress'),
  "M'Sila"       => _x("M'Sila", 'ui', 'memberpress'),
  'Mascara'       => _x("Mascara", 'ui', 'memberpress'),
  'Médéa'       => _x('Médéa', 'ui', 'memberpress'),
  'Mila'       => _x('Mila', 'ui', 'memberpress'),
  'Mostaganem'       => _x('Mostaganem', 'ui', 'memberpress'),
  'Naâma'       => _x('Naâma', 'ui', 'memberpress'),
  'Oran'       => _x('Oran', 'ui', 'memberpress'),
  'Ouargla'       => _x('Ouargla', 'ui', 'memberpress'),
  'Oum El Bouaghi'       => _x('Oum El Bouaghi', 'ui', 'memberpress'),
  'Relizane'       => _x('Relizane', 'ui', 'memberpress'),
  'Saïda'       => _x('Saïda', 'ui', 'memberpress')
);

