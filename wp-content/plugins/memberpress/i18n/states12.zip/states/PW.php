<?php
/**
 * Belau states
 */
$states['Belau'] = array(
  'Aimeliik'         => _x('Aimeliik', 'ui', 'memberpress'),
  'Airai'         => _x('Airai', 'ui', 'memberpress'),
  'Angaur'         => _x('Angaur', 'ui', 'memberpress'),
  'Hatohobei'         => _x('Hatohobei', 'ui', 'memberpress'),
  'Kayangel'         => _x('Kayangel', 'ui', 'memberpress'),
  'Koror'         => _x('Koror', 'ui', 'memberpress'),
  'Melekeok'         => _x('Melekeok', 'ui', 'memberpress'),
  'Ngaraard'         => _x('Ngaraard', 'ui', 'memberpress'),
  'Ngarchelong'         => _x('Ngarchelong', 'ui', 'memberpress'),
  'Ngardmau'         => _x('Ngardmau', 'ui', 'memberpress'),
  'Ngatpang'         => _x('Ngatpang', 'ui', 'memberpress'),
  'Ngchesar'         => _x('Ngchesar', 'ui', 'memberpress'),
  'Ngeremlengui'         => _x('Ngeremlengui', 'ui', 'memberpress'),
  'Ngiwal'         => _x('Ngiwal', 'ui', 'memberpress'),
  'Peleliu'         => _x('Peleliu', 'ui', 'memberpress'),
  'Sonsorol'         => _x('Sonsorol', 'ui', 'memberpress')
);


?>
