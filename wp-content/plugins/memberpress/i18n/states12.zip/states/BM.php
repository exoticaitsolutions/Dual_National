<?php
/**
 * Bermuda states
 */
$states['Bermuda'] = array(
  'Devonshire'         => _x('Devonshire', 'ui', 'memberpress'),
  'Hamilton'         => _x('Hamilton', 'ui', 'memberpress'),
  'Paget'         => _x('Paget', 'ui', 'memberpress'),
  'Hamilton'         => _x('Hamilton', 'ui', 'memberpress'),
  'Paget'         => _x('Paget', 'ui', 'memberpress'),
  'Pembroke'         => _x('Pembroke', 'ui', 'memberpress'),
  'Saint George'         => _x('Saint George', 'ui', 'memberpress'),
  "Saint George's"         => _x( "Saint George's", 'ui', 'memberpress'),
  'Sandys'         => _x('Sandys', 'ui', 'memberpress'),
  "Smith's"         => _x( "Smith's", 'ui', 'memberpress'),
  'Southampton'        => _x(  'Southampton', 'ui', 'memberpress'),
  'Warwick'         => _x('Warwick', 'ui', 'memberpress')
);


?>