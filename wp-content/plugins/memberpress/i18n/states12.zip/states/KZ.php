<?php
/**
 * Kazakhstan states
 */
$states['Kazakhstan'] = array(
    'Almaty Oblysy'                   => _x('Almaty Oblysy', 'ui', 'memberpress'),
    'Almaty Qalasy'                   => _x('Almaty Qalasy', 'ui', 'memberpress'),
    'Aqmola Oblysy'                   => _x('Aqmola Oblysy', 'ui', 'memberpress'),
    'Aqtobe Oblysy'                   => _x('Aqtobe Oblysy', 'ui', 'memberpress'),
    'Astana Qalasy'                   => _x('Astana Qalasy', 'ui', 'memberpress'),
    'Atyrau Oblysy'                   => _x('Atyrau Oblysy', 'ui', 'memberpress'),
    'Batys Qazaqstan Oblysy'          => _x('Batys Qazaqstan Oblysy', 'ui', 'memberpress'),
    'Bayqongyr Qalasy'                => _x('Bayqongyr Qalasy', 'ui', 'memberpress'),
    'Mangghystau Oblysy'              => _x('Mangghystau Oblysy', 'ui', 'memberpress'),
    'Ongtustik Qazaqstan Oblysy'      => _x('Ongtustik Qazaqstan Oblysy', 'ui', 'memberpress'),
    'Pavlodar Oblysy'                 => _x('Pavlodar Oblysy', 'ui', 'memberpress'),
    'Qaraghandy Oblysy'               => _x('Qaraghandy Oblysy', 'ui', 'memberpress'),
    'Qostanay Oblysy'                 => _x('Qostanay Oblysy', 'ui', 'memberpress'),
    'Qyzylorda Oblysy'                => _x('Qyzylorda Oblysy', 'ui', 'memberpress'),
    'Shyghys Qazaqstan Oblysy'        => _x('Shyghys Qazaqstan Oblysy', 'ui', 'memberpress'),
    'Soltustik Qazaqstan Oblysy'      => _x('Soltustik Qazaqstan Oblysy', 'ui', 'memberpress'),
    'Zhambyl Oblysy'                  => _x('Zhambyl Oblysy', 'ui', 'memberpress')
 
);

?>