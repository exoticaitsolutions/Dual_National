<?php
/**
 * Maldives states
 */
$states['Maldives'] = array(
  'Alifu' => _x('Alifu', 'ui', 'memberpress'),
  'Baa' => _x('Baa', 'ui', 'memberpress'),
  'Dhaalu' => _x('Dhaalu', 'ui', 'memberpress'),
  'Faafu' => _x('Faafu', 'ui', 'memberpress'),
  'Gaafu Alifu' => _x('Gaafu Alifu', 'ui', 'memberpress'),
  'Gaafu Dhaalu' => _x('Gaafu Dhaalu', 'ui', 'memberpress'),
  'Gnaviyani' => _x('Gnaviyani', 'ui', 'memberpress'),
  'Haa Alifu' => _x('Haa Alifu', 'ui', 'memberpress'),
  'Haa Dhaalu' => _x('Haa Dhaalu', 'ui', 'memberpress'),
  'Kaafu' => _x('Kaafu', 'ui', 'memberpress'),
  'Laamu' => _x('Laamu', 'ui', 'memberpress'),
  'Lhaviyani' => _x('Lhaviyani', 'ui', 'memberpress'),
  'Maale' => _x('Maale', 'ui', 'memberpress'),
  'Meemu' => _x('Meemu', 'ui', 'memberpress'),
  'Noonu' => _x('Noonu', 'ui', 'memberpress'),
  'Raa' => _x('Raa', 'ui', 'memberpress'),
  'Seenu' => _x('Seenu', 'ui', 'memberpress'),
  'Shaviyani' => _x('Shaviyani', 'ui', 'memberpress'),
  'Thaa' => _x('Thaa', 'ui', 'memberpress'),
  'Vaavu' => _x('Vaavu', 'ui', 'memberpress'),
);
