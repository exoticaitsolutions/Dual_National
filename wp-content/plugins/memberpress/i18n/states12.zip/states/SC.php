<?php
/**
 * Seychelles states
 */
$states['Seychelles'] = array(
  'Anse aux Pins' => _x('Anse aux Pins', 'ui', 'memberpress'),
  'Anse Boileau' => _x('Anse Boileau', 'ui', 'memberpress'),
  'Anse Etoile' => _x('Anse Etoile', 'ui', 'memberpress'),
  'Anse Louis' => _x('Anse Louis', 'ui', 'memberpress'),
  'Anse Royale' => _x('Anse Royale', 'ui', 'memberpress'),
  'Baie Lazare' => _x('Baie Lazare', 'ui', 'memberpress'),
  'Baie Sainte Anne' => _x('Baie Sainte Anne', 'ui', 'memberpress'),
  'Beau Vallon' => _x('Beau Vallon', 'ui', 'memberpress'),
  'Bel Air' => _x('Bel Air', 'ui', 'memberpress'),
  'Bel Ombre' => _x('Bel Ombre', 'ui', 'memberpress'),
  'Cascade' => _x('Cascade', 'ui', 'memberpress'),
  'Glacis' => _x('Glacis', 'ui', 'memberpress'),
  "Grand' Anse"=> _x("Grand' Anse", 'ui', 'memberpress'),
  'La Digue' => _x('La Digue', 'ui', 'memberpress'),
  'La Riviere Anglaise' => _x('La Riviere Anglaise', 'ui', 'memberpress'),
  'Mont Buxton' => _x('Mont Buxton', 'ui', 'memberpress'),
  'Mont Fleuri' => _x('Mont Fleuri', 'ui', 'memberpress'),
  'Plaisance' => _x('Plaisance', 'ui', 'memberpress'),
  'Pointe La Rue' => _x('Pointe La Rue', 'ui', 'memberpress'),
  'Port Glaud' => _x('Port Glaud', 'ui', 'memberpress'),
  'Saint Louis' => _x('Saint Louis', 'ui', 'memberpress'),
  'Takamaka' => _x('Takamaka', 'ui', 'memberpress')
);

?>