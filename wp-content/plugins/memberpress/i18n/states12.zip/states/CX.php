<?php
/**
 * Christmas Island  States
 */
 $states['Christmas Island'] = array(
    'Christmas Island'       => _x('Christmas Island', 'ui', 'memberpress')
  );
 ?>