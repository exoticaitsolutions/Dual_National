<?php
/**
 * Bhutan states
 */
$states['Bhutan'] = array(
  'Bumthang'         => _x('Bumthang', 'ui', 'memberpress'),
  'Chukha'         => _x('Chukha', 'ui', 'memberpress'),
  'Dagana'         => _x('Dagana', 'ui', 'memberpress'),
  'Gasa'         => _x('Gasa', 'ui', 'memberpress'),
  'Haa'         => _x('Kowloon', 'ui', 'memberpress'),
  'Lhuntse'         => _x('Lhuntse', 'ui', 'memberpress'),
  'Mongar'         => _x('Mongar', 'ui', 'memberpress'),
  'Paro'         => _x('Paro', 'ui', 'memberpress'),
  'Pemagatshel'         => _x('Pemagatshel', 'ui', 'memberpress'),
  'Punakha'         => _x('Punakha', 'ui', 'memberpress'),
  'Samdrup Jongkhar'         => _x('Samdrup Jongkhar', 'ui', 'memberpress'),
  'Samtse'         => _x('Samtse', 'ui', 'memberpress'),
  'Sarpang'         => _x('Sarpang', 'ui', 'memberpress'),
  'Thimphu'         => _x('Thimphu', 'ui', 'memberpress'),
  'Trashigang'         => _x('Trashigang    ', 'ui', 'memberpress'),
  'Trashiyangste'         => _x('Trashiyangste', 'ui', 'memberpress'),
  'Trongsa'         => _x('Trongsa', 'ui', 'memberpress'),
  'Tsirang'         => _x('Tsirang', 'ui', 'memberpress'),
  'Wangdue Phodrang'         => _x('Wangdue Phodrang', 'ui', 'memberpress'),
  'Zhemgang'         => _x('Zhemgang', 'ui', 'memberpress')
);


?>
