<?php
/**
 * San Marino states
 */
$states['San Marino'] = array(
  'Acquaviva' => _x('Acquaviva', 'ui', 'memberpress'),
  'Borgo Maggiore' => _x('Borgo Maggiore', 'ui', 'memberpress'),
  'Chiesanuova' => _x('Chiesanuova', 'ui', 'memberpress'),
  'Domagnano' => _x('Domagnano', 'ui', 'memberpress'),
  'Faetano' => _x('Faetano', 'ui', 'memberpress'),
  'Fiorentino' => _x('Fiorentino', 'ui', 'memberpress'),
  'Montegiardino' => _x('Montegiardino', 'ui', 'memberpress'),
  'San Marino Citta' => _x('San Marino Citta', 'ui', 'memberpress'),
  'Serravalle' => _x('Serravalle', 'ui', 'memberpress')

);

?>