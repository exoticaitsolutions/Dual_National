<?php
/**
 * Cura  States
 */
 $states['Cura'] = array(
    'Cura&Ccedil;ao'       => _x('Cura&Ccedil;ao', 'ui', 'memberpress'),
  );
 ?>