<?php
/**
 * Barbados states
 */
$states['Barbados'] = array(
  'Christ Church'         => _x('Christ Church', 'ui', 'memberpress'),
  'Saint Andrew'         => _x('Saint Andrew', 'ui', 'memberpress'),
  'Saint George'         => _x('Saint George', 'ui', 'memberpress'),
  'Saint James'         => _x('Saint James', 'ui', 'memberpress'),
  'Saint John'         => _x('Saint John', 'ui', 'memberpress'),
  'Saint Joseph'         => _x('Saint Joseph', 'ui', 'memberpress'),
  'Saint Lucy'         => _x('Saint Lucy', 'ui', 'memberpress'),
  'Saint Michael'         => _x('Saint Michael', 'ui', 'memberpress'),
  'Saint Peter'         => _x('Saint Peter', 'ui', 'memberpress'),
  'Saint Philip'         => _x('Saint Philip', 'ui', 'memberpress'),
  'Saint Thomas'         => _x('Saint Thomas', 'ui', 'memberpress')
);


?>
