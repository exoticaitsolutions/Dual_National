<?php
/**
 * North Korea states
 */
$states['North Korea'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
);

?>