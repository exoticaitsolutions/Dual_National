<?php
/**
 * Tanzania states
 */
$states['Tanzania'] = array(
  'Arusha' => _x('Arusha', 'ui', 'memberpress'),
  'Dar es Salaam' => _x('Dar es Salaam', 'ui', 'memberpress'),
  'Dodoma' => _x('Dodoma', 'ui', 'memberpress'),
  'Iringa' => _x('Iringa', 'ui', 'memberpress'),
  'Kagera' => _x('Kagera', 'ui', 'memberpress'),
  'Kigoma' => _x('Kigoma', 'ui', 'memberpress'),
  'Kilimanjaro' => _x('Kilimanjaro', 'ui', 'memberpress'),
  'Lindi' => _x('Lindi', 'ui', 'memberpress'),
  'Manyara' => _x('Manyara', 'ui', 'memberpress'),
  'Mara' => _x('Mara', 'ui', 'memberpress'),
  'Mbeya' => _x('Mbeya', 'ui', 'memberpress'),
  'Morogoro' => _x('Morogoro', 'ui', 'memberpress'),
  'Mtwara' => _x('Mtwara', 'ui', 'memberpress'),
  'Mwanza' => _x('Mwanza', 'ui', 'memberpress'),
  'Pemba North' => _x('Pemba North', 'ui', 'memberpress'),
  'Pemba South' => _x('Pemba South', 'ui', 'memberpress'),
  'Pwani' => _x('Pwani', 'ui', 'memberpress'),
  'Rukwa' => _x('Rukwa', 'ui', 'memberpress'),
  'Ruvuma' => _x('Ruvuma', 'ui', 'memberpress'),
  'Shinyanga' => _x('Shinyanga', 'ui', 'memberpress'),
  'Singida' => _x('Singida', 'ui', 'memberpress'),
  'Tabora' => _x('Tabora', 'ui', 'memberpress'),
  'Tanga' => _x('Tanga', 'ui', 'memberpress'),
  'Zanzibar Central/South' => _x('Zanzibar Central/South', 'ui', 'memberpress'),
  'Zanzibar North' => _x('Zanzibar North', 'ui', 'memberpress'),
  'Zanzibar Urban/West' => _x('Zanzibar Urban/West', 'ui', 'memberpress'),
);
