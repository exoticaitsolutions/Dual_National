<?php
/**
 * Malta states
 */
$states['Malta'] = array(
  'Southern Harbour' => _x('Southern Harbour', 'ui', 'memberpress'),
  'Northern Harbour' => _x('Northern Harbour', 'ui', 'memberpress'),
  'Western Distric' => _x('Western Distric', 'ui', 'memberpress'),
  'Northern District' => _x('Northern District', 'ui', 'memberpress'),
  '"Gozo and Comino' => _x('"Gozo and Comino', 'ui', 'memberpress')
);

?>