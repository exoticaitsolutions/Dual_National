<?php
/**
 * Madagascar states
 */
$states['Martinique'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),

);

?>