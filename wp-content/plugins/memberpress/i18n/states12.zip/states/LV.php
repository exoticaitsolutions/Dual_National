<?php
/**
 * Latvia states
 */
$states['Latvia'] = array(
    'Aizkraukles Rajons'                       => _x('Aizkraukles Rajons', 'ui', 'memberpress'),
    'Aluksnes Rajons'                          => _x('Aluksnes Rajons', 'ui', 'memberpress'),
    'Balvu Rajons'                             => _x('Balvu Rajons', 'ui', 'memberpress'),
    'Bauskas Rajons'                           => _x('Bauskas Rajons', 'ui', 'memberpress'),
    'Cesu Rajons'                              => _x('Cesu Rajons', 'ui', 'memberpress'),
    'Daugavpils'                               => _x('Daugavpils', 'ui', 'memberpress'),
    'Daugavpils Rajons'                        => _x('Daugavpils Rajons', 'ui', 'memberpress'),
    'Dobeles Rajons'                           => _x('Dobeles Rajons', 'ui', 'memberpress'),
    'Gulbenes Rajons'                          => _x('Gulbenes Rajons', 'ui', 'memberpress'),
    'Jekabpils Rajons'                         => _x('Jekabpils Rajons', 'ui', 'memberpress'),
    'Jelgava'                                  => _x('Jelgava', 'ui', 'memberpress'),
    'Jelgavas Rajons'                          => _x('Jelgavas Rajons', 'ui', 'memberpress'),
    'Jurmala'                                  => _x('Jurmala', 'ui', 'memberpress'),
    'Kraslavas Rajons'                         => _x('Kraslavas Rajons', 'ui', 'memberpress'),
    'Kuldigas Rajons'                          => _x('Kuldigas Rajons', 'ui', 'memberpress'),
    'Liepaja'                                  => _x('Liepaja', 'ui', 'memberpress'),
    'Liepajas Rajons'                          => _x('Liepajas Rajons', 'ui', 'memberpress'),
    'Limbazu Rajons'                           => _x('Limbazu Rajons', 'ui', 'memberpress'),
    'Ludzas Rajons'                            => _x('Ludzas Rajons', 'ui', 'memberpress'),
    'Madonas Rajons'                           => _x('Madonas Rajons', 'ui', 'memberpress'),
    'Ogres Rajons'                             => _x('Ogres Rajons', 'ui', 'memberpress'),
    'Preilu Rajons'                            => _x('Preilu Rajons', 'ui', 'memberpress'),
    'Rezekne'                                  => _x('Rezekne', 'ui', 'memberpress'),
    'Rezeknes Rajons'                          => _x('Rezeknes Rajons', 'ui', 'memberpress'),
    'Riga'                                     => _x('Riga', 'ui', 'memberpress'),
    'Rigas Rajons'                             => _x('Rigas Rajons', 'ui', 'memberpress'),
    'Saldus Rajons'                            => _x('Saldus Rajons', 'ui', 'memberpress'),
    'Talsu Rajons'                             => _x('Talsu Rajons', 'ui', 'memberpress'),
    'Tukuma Rajons'                            => _x('Tukuma Rajons', 'ui', 'memberpress'),
    'Valkas Rajons'                            => _x('Valkas Rajons', 'ui', 'memberpress'),
    'Valmieras Rajons'                         => _x('Valmieras Rajons', 'ui', 'memberpress'),
    'Ventspils'                                => _x('Ventspils', 'ui', 'memberpress'),
    'Ventspils Rajons'                         => _x('Ventspils Rajons', 'ui', 'memberpress')

);

?>