<?php
/**
 * British Indian Ocean Territory states
 */
$states['British Indian Ocean Territory'] = array(
    'British Indian Ocean Territory' => _x('British Indian Ocean Territory', 'ui', 'memberpress'),

);


?>
