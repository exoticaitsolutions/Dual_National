<?php
/**
 * Heard Island and McDonald Islands states
 */
$states['Heard Island and McDonald Islands'] = array(
'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress') 
);

