<?php
/**
 * Estonia states
 */
$states['Estonia'] = array(
  'Harjumaa (Tallinn)'       => _x('Harjumaa (Tallinn)', 'ui', 'memberpress'),
   'Hiiumaa (Kardla)'       => _x('Hiiumaa (Kardla)', 'ui', 'memberpress'),
   'Ida-Virumaa (Johvi)'       => _x('Ida-Virumaa (Johvi)', 'ui', 'memberpress'),
   'Jarvamaa (Paide)'       => _x('Jarvamaa (Paide)', 'ui', 'memberpress'),
   'Jogevamaa (Jogeva)'       => _x('Jogevamaa (Jogeva)', 'ui', 'memberpress'),
   'Laanemaa (Haapsalu)'       => _x('Laanemaa (Haapsalu)', 'ui', 'memberpress'),
   'Laane-Virumaa (Rakvere)'       => _x('Laane-Virumaa (Rakvere)', 'ui', 'memberpress'),
   'Parnumaa (Parnu)'       => _x('Parnumaa (Parnu)', 'ui', 'memberpress'),
   'Polvamaa (Polva)'       => _x('Polvamaa (Polva)', 'ui', 'memberpress'),
   'Raplamaa (Rapla)'       => _x('Raplamaa (Rapla)', 'ui', 'memberpress'),
   'Saaremaa (Kuressaare)'       => _x('Saaremaa (Kuressaare)', 'ui', 'memberpress'),
   'Tartumaa (Tartu)'       => _x('Tartumaa (Tartu)', 'ui', 'memberpress'),
   'HarValgamaa (Valga)'       => _x('Valgamaa (Valga)', 'ui', 'memberpress'),
   'Viljandimaa (Viljandi)'       => _x('Viljandimaa (Viljandi)', 'ui', 'memberpress')
);

