<?php
/**
 * Lebanon states
 */
$states['Lebanon'] = array(
    'Beyrouth'                    => _x('Beyrouth', 'ui', 'memberpress'),
    'Beqaa'                       => _x('Beqaa', 'ui', 'memberpress'),
    'Liban-Nord'                  => _x('Liban-Nord', 'ui', 'memberpress'),
    'Liban-Sud'                   => _x('Liban-Sud', 'ui', 'memberpress'),
    'Mont-Liban'                  => _x('Mont-Liban', 'ui', 'memberpress'),
    'Nabatiye'                    => _x('Nabatiye', 'ui', 'memberpress')

);

?>