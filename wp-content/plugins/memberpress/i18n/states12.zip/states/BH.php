<?php
/**
 * Bahrain states
 */
$states['Bahrain'] = array(
  'Al Hadd'         => _x('Al Hadd', 'ui', 'memberpress'),
  'Al Manamah'         => _x('Al Manamah', 'ui', 'memberpress'),
  'Al Mintaqah al Gharbiyah'         => _x('Al Mintaqah al Gharbiyah', 'ui', 'memberpress'),
  'Al Mintaqah al Wusta'         => _x('Al Mintaqah al Wusta', 'ui', 'memberpress'),
  'Al Mintaqah ash Shamaliyah'         => _x('Al Mintaqah ash Shamaliyah', 'ui', 'memberpress'),
  'Al Muharraq'         => _x('Al Muharraq', 'ui', 'memberpress'),
"Ar Rifa' wa al Mintaqah al Janubiyah"       => _x("Ar Rifa' wa al Mintaqah al Janubiyah" , 'ui', 'memberpress'),
  'Jidd Hafs'         => _x('Jidd Hafs', 'ui', 'memberpress'),
  'Madinat Hamad'         => _x('Madinat Hamad', 'ui', 'memberpress'),
  "Madinat 'Isa"        => _x( "Madinat 'Isa" , 'ui', 'memberpress'),
  'Juzur Hawa'         => _x('Juzur Hawa', 'ui', 'memberpress')
);


?>
