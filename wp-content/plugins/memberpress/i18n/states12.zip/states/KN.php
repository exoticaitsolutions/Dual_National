<?php
/**
 * Saint Kitts and Nevis states
 */
$states['Saint Kitts and Nevis'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
  // 

);

?>