<?php
/**
 * Burundi  States
 */


 $states['Burundi'] = array(
    'Bubanza'       => _x('Bubanza', 'ui', 'memberpress'),
    'Bujumbura Mairie'       => _x('Bujumbura Mairie', 'ui', 'memberpress'),
    'Bujumbura Rura'       => _x('Bujumbura Rura', 'ui', 'memberpress'),
    'Cibitoke'       => _x('Cibitoke', 'ui', 'memberpress'),
    'Gitega'       => _x('Bubanza', 'ui', 'memberpress'),
    'Karuzi'       => _x('Karuzi', 'ui', 'memberpress'),
    'Kirundo'       => _x('Kirundo', 'ui', 'memberpress'),
    'Makamba'       => _x('Makamba', 'ui', 'memberpress'),
    'Muramvya'       => _x('Muramvya', 'ui', 'memberpress'),
    'Muyinga'       => _x('Muyinga', 'ui', 'memberpress'),
    'Mwaro'       => _x('Mwaro', 'ui', 'memberpress'),
    'Ngozi'       => _x('Ngozi', 'ui', 'memberpress'),
    'Rutana'       => _x('Rutana', 'ui', 'memberpress'),
    'Ruyigi'       => _x('Ruyigi', 'ui', 'memberpress')
    
    
  );
 ?>