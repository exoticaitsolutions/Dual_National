<?php
/**
 * Dominica  States
 */
 $states['Dominica'] = array(
    'Saint Andrew'       => _x('Saint Andrew', 'ui', 'memberpress'),
    'Saint David'       => _x('Saint David', 'ui', 'memberpress'),
    'Saint George'       => _x('Saint George', 'ui', 'memberpress'),
    'Saint John'       => _x('Saint John', 'ui', 'memberpress'),
    'Saint Joseph'       => _x('Saint Joseph', 'ui', 'memberpress'),
    'Saint Luke'       => _x('Saint Luke', 'ui', 'memberpress'),
    'Saint Mark'       => _x('Saint Mark', 'ui', 'memberpress'),
    'Saint Patrick'       => _x('"Saint Patrick', 'ui', 'memberpress'),
    'Saint Paul'       => _x('Saint Paul', 'ui', 'memberpress'),
    'Saint Peter'       => _x('Saint Peter', 'ui', 'memberpress')
  );
 ?>