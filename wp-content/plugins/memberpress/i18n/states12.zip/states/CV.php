<?php
/**
 * Cape Verde  States
 */
 $states['Cape Verde'] = array(
    
    'Cape Verde'       => _x('Cape Verde', 'ui', 'memberpress'),
    
  );
 ?>