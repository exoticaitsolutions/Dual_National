<?php
/**
 * Cuba  States
 */
 $states['Cuba'] = array(
    'Camaguey'       => _x('Camaguey', 'ui', 'memberpress'),
    'Ciego de Avila'       => _x('Ciego de Avila', 'ui', 'memberpress'),
    'Cienfuegos'       => _x('Cienfuegos', 'ui', 'memberpress'),
    'Ciudad de La Habana'       => _x('Ciudad de La Habana', 'ui', 'memberpress'),
    'Granma'       => _x('Granma', 'ui', 'memberpress'),
    'Guantanamo'       => _x('Guantanamo', 'ui', 'memberpress'),
    'Holguin'       => _x('Holguin', 'ui', 'memberpress'),
    'Isla de la Juventud'       => _x('Isla de la Juventud', 'ui', 'memberpress'),
    'La Habana", "Las Tunas'       => _x('La Habana", "Las Tunas', 'ui', 'memberpress'),
    'La Habana'       => _x('La Habana', 'ui', 'memberpress'),
    'Matanzas'       => _x('Matanzas', 'ui', 'memberpress'),
    'Pinar del Rio'       => _x('Pinar del Rio', 'ui', 'memberpress'),
    'Sancti Spiritus'       => _x('Sancti Spiritus', 'ui', 'memberpress'),
    'Santiago de Cuba'       => _x('Santiago de Cuba', 'ui', 'memberpress'),
    'Villa Clara'       => _x('Villa Clara', 'ui', 'memberpress')
  );
 ?>