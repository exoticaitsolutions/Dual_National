<?php
/**
 * Ukraine states
 */
$states['Ukraine'] = array(
  'Cherkasy'  => _x('Cherkasy', 'ui', 'memberpress'),
  'Chernihiv'  => _x('Chernihiv', 'ui', 'memberpress'),
  'Chernivtsi'  => _x('Chernivtsi', 'ui', 'memberpress'),
  'Crimea' => _x('Crimea', 'ui', 'memberpress'),
  'Dnipropetrovsk'  => _x('Dnipropetrovsk', 'ui', 'memberpress'),
  'Donetsk'  => _x('Donetsk', 'ui', 'memberpress'),
  'Ivano-Frankivsk'  => _x('Ivano-Frankivsk', 'ui', 'memberpress'),
  'Kharkiv'  => _x('Kharkiv', 'ui', 'memberpress'),
  'Kherson'  => _x('Kherson', 'ui', 'memberpress'),
  'Khmelnytskyy'  => _x('Khmelnytskyy', 'ui', 'memberpress'),
  'Kirovohrad'  => _x('Kirovohrad', 'ui', 'memberpress'),
  'Kiev'  => _x('Kiev', 'ui', 'memberpress'),
  'Kyyiv'  => _x('Kyyiv', 'ui', 'memberpress'),
  'Luhansk'  => _x('Luhansk', 'ui', 'memberpress'),
  'Lviv'  => _x('Lviv', 'ui', 'memberpress'),
  'Mykolayiv'  => _x('Mykolayiv', 'ui', 'memberpress'),
  'Odesa'  => _x('Odesa', 'ui', 'memberpress'),
  'Poltava'  => _x('Poltava', 'ui', 'memberpress'),
  'Rivne'  => _x('Rivne', 'ui', 'memberpress'),
  'Sevastopol'  => _x('Sevastopol', 'ui', 'memberpress'),
  'Sumy'  => _x('Sumy', 'ui', 'memberpress'),
  'Ternopil'  => _x('Ternopil', 'ui', 'memberpress'),
  'Vinnytsya'  => _x('Vinnytsya', 'ui', 'memberpress'),
  'Volyn'  => _x('Volyn', 'ui', 'memberpress'),
  'Zakarpattya'  => _x('Zakarpattya', 'ui', 'memberpress'),
  'Zaporizhzhya'  => _x('Zaporizhzhya', 'ui', 'memberpress'),
  'Zhytomyr'  => _x('Zhytomyr', 'ui', 'memberpress')
);

