<?php
/**
 * Lithuania states
 */
$states['Lithuania'] = array(
    'Alytaus'                     => _x('Alytaus', 'ui', 'memberpress'),
    'Kauno'                       => _x('Kauno', 'ui', 'memberpress'),
    'Klaipedos'                   => _x('Klaipedos', 'ui', 'memberpress'),
    'Marijampoles'                => _x('Marijampoles', 'ui', 'memberpress'),
    'Panevezio'                   => _x('Panevezio', 'ui', 'memberpress'),
    'Siauliu'                     => _x('Siauliu', 'ui', 'memberpress'),
    'Taurages'                    => _x('Taurages', 'ui', 'memberpress'),
    'Telsiu'                      => _x('Telsiu', 'ui', 'memberpress'),
    'Utenos'                      => _x('Utenos', 'ui', 'memberpress'),
    'Vilniaus'                    => _x('Vilniaus', 'ui', 'memberpress')
);

?>