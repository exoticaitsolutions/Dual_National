<?php
/**
 * British Virgin Islands states
 */
$states['British Virgin Islands'] = array(
  'British Virgin Islands'         => _x('British Virgin Islands', 'ui', 'memberpress'),
);


?>
