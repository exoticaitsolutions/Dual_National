<?php
/**
 * Honduras states
 */
$states['Honduras'] = array(
  'Atlantida' => _x('Atlantida', 'ui', 'memberpress'),
  'Choluteca' => _x('Choluteca', 'ui', 'memberpress'),
  'Colon' => _x('Colon', 'ui', 'memberpress'),
  'Comayagua' => _x('Comayagua', 'ui', 'memberpress'),
  'Copan' => _x('Copan', 'ui', 'memberpress'),
  'Cortes' => _x('Cortes', 'ui', 'memberpress'),
  'El Paraiso' => _x('El Paraiso', 'ui', 'memberpress'),
  'Francisco Morazan' => _x('Francisco Morazan', 'ui', 'memberpress'),
  'Gracias a Dios' => _x('Gracias a Dios', 'ui', 'memberpress'),
  'Intibuca' => _x('Intibuca', 'ui', 'memberpress'),
  'Islas de la Bahia' => _x('Islas de la Bahia', 'ui', 'memberpress'),
  'La Paz' => _x('La Paz', 'ui', 'memberpress'),
  'Lempira' => _x('Lempira', 'ui', 'memberpress'),
  'Ocotepeque' => _x('Ocotepeque', 'ui', 'memberpress'),
  'Olancho' => _x('Olancho', 'ui', 'memberpress'),
  'Santa Barbara' => _x('Santa Barbara', 'ui', 'memberpress'),
  'Valle' => _x('Valle', 'ui', 'memberpress'),
  'Yoro' => _x('Yoro', 'ui', 'memberpress'),
  
);
