<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  'Caprivi' => _x('Caprivi', 'ui', 'memberpress'),
  'Erongo' => _x('Erongo', 'ui', 'memberpress'),
  'Hardap' => _x('Hardap', 'ui', 'memberpress'),
  'Karas' => _x('Karas', 'ui', 'memberpress'),
  'Khomas' => _x('Khomas', 'ui', 'memberpress'),
  'Kunene' => _x('Kunene', 'ui', 'memberpress'),
  'Ohangwena' => _x('Ohangwena', 'ui', 'memberpress'),
  'Okavango' => _x('Okavango', 'ui', 'memberpress'),
  'Omaheke' => _x('Omaheke', 'ui', 'memberpress'),
  'Omusati' => _x('Omusati', 'ui', 'memberpress'),
  'Oshana' => _x('Oshana', 'ui', 'memberpress'),
  'Oshikoto' => _x('Oshikoto', 'ui', 'memberpress'),
  'Otjozondjupa' => _x('Otjozondjupa', 'ui', 'memberpress')
);

?>