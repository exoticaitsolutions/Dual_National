<?php
/**
 * Liberia states
 */
$states['Liberia'] = array(
    'Bomi'                        => _x('Bomi', 'ui', 'memberpress'),
    'Bong'                        => _x('Bong', 'ui', 'memberpress'),
    'Gbarpolu'                    => _x('Gbarpolu', 'ui', 'memberpress'),
    'Grand Bassa'                 => _x('Grand Bassa', 'ui', 'memberpress'),
    'Grand Cape Mount'            => _x('Grand Cape Mount', 'ui', 'memberpress'),
    'Grand Gedeh'                 => _x('Grand Gedeh', 'ui', 'memberpress'),
    'Grand Kru'                   => _x('Grand Kru', 'ui', 'memberpress'),
    'Lofa'                        => _x('Lofa', 'ui', 'memberpress'),
    'Margibi'                     => _x('Margibi', 'ui', 'memberpress'),
    'Maryland'                    => _x('Maryland', 'ui', 'memberpress'),
    'Montserrado'                 => _x('Montserrado', 'ui', 'memberpress'),
    'Nimba'                       => _x('Nimba', 'ui', 'memberpress'),
    'River Cess'                  => _x('River Cess', 'ui', 'memberpress'),
    'River Gee'                   => _x('River Gee', 'ui', 'memberpress'),
    'Sinoe'                       => _x('Sinoe', 'ui', 'memberpress')

);

?>