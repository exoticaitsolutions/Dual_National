<?php
/**
 * Iceland states
 */
$states['Iceland'] = array(
  'Austurland' => _x('Austurland', 'ui', 'memberpress'),
  'Hofudhborgarsvaedhi' => _x('Hofudhborgarsvaedhi', 'ui', 'memberpress'),
  'Nordhurland' => _x('Nordhurland', 'ui', 'memberpress'),
  'Eystra' => _x('Eystra', 'ui', 'memberpress'),
  'Nordhurland Vestra' => _x('Nordhurland Vestra', 'ui', 'memberpress'),
  'Sudhurnes' => _x('Sudhurland', 'ui', 'memberpress'),
  'Vestfirdhir' => _x('Vestfirdhir', 'ui', 'memberpress'),
  'Vesturland' => _x('Vesturland', 'ui', 'memberpress')
  
);
