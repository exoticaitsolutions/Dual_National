<?php
/**
 * Tunisia states
 */
$states['Tunisia'] = array(
  'Ariana (Aryanah)'  => _x('Ariana (Aryanah)', 'ui', 'memberpress'),
  'Beja (Bajah)'  => _x('Beja (Bajah)', 'ui', 'memberpress'),
  'Ben Arous (Bin Arus)'  => _x('Ben Arous (Bin Arus)', 'ui', 'memberpress'),
  'Bizerte (Banzart)' => _x('Bizerte (Banzart)', 'ui', 'memberpress'),
  'Gabes (Qabis)'  => _x('Gabes (Qabis)', 'ui', 'memberpress'),
  'Gafsa (Qafsah)'  => _x('Gafsa (Qafsah)', 'ui', 'memberpress'),
  'Jendouba (Jundubah)'  => _x('Jendouba (Jundubah)', 'ui', 'memberpress'),
  'Kairouan (Al Qayrawan)'  => _x('Kairouan (Al Qayrawan)', 'ui', 'memberpress'),
  'Kasserine (Al Qasrayn)'  => _x('Kasserine (Al Qasrayn)', 'ui', 'memberpress'),
  'Kebili (Qibili)'  => _x('Kebili (Qibili)', 'ui', 'memberpress'),
  'Kef (Al Kaf)'  => _x('Kef (Al Kaf)', 'ui', 'memberpress'),
  'Mahdia (Al Mahdiyah)'  => _x('Mahdia (Al Mahdiyah)', 'ui', 'memberpress'),
  'Manouba (Manubah)'  => _x('Manouba (Manubah)', 'ui', 'memberpress'),
  'Medenine (Madanin)'  => _x('Medenine (Madanin)', 'ui', 'memberpress'),
  'Monastir (Al Munastir)'  => _x('Monastir (Al Munastir)', 'ui', 'memberpress'),
  'Nabeul (Nabul)'  => _x('Nabeul (Nabul)', 'ui', 'memberpress'),
  'Sfax (Safaqis)'  => _x('Sfax (Safaqis)', 'ui', 'memberpress'),
  'Sidi Bou Zid (Sidi Bu Zayd)'  => _x('Sidi Bou Zid (Sidi Bu Zayd)', 'ui', 'memberpress'),
  'Siliana (Silyanah)'  => _x('Siliana (Silyanah)', 'ui', 'memberpress'),
  'Sousse (Susah)'  => _x('Sousse (Susah)', 'ui', 'memberpress'),
  'Tataouine (Tatawin)'  => _x('Tataouine (Tatawin)', 'ui', 'memberpress'),
  'Tozeur (Tawzar)'  => _x('Tozeur (Tawzar)', 'ui', 'memberpress'),
  'Tunis'  => _x('Tunis', 'ui', 'memberpress'),
  'Zaghouan (Zaghwan)'  => _x('Zaghouan (Zaghwan)', 'ui', 'memberpress')
);

