<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  'Antananarivo' => _x('Antananarivo', 'ui', 'memberpress'),
  'Antsiranana' => _x('Antsiranana', 'ui', 'memberpress'),
  'Fianarantsoa' => _x('Fianarantsoa', 'ui', 'memberpress'),
  'Mahajanga' => _x('Mahajanga', 'ui', 'memberpress'),
  'Toamasina' => _x('Toamasina', 'ui', 'memberpress'),
  'Toliara' => _x('Toliara', 'ui', 'memberpress')
);

?>