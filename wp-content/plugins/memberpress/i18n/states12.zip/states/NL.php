<?php
/**
 * Netherlands states
 */
$states['Netherlands'] = array(
  'Drenthe' => _x('Drenthe', 'ui', 'memberpress'),
  'Flevoland' => _x('Flevoland', 'ui', 'memberpress'),
  'Gelderland' => _x('Gelderland', 'ui', 'memberpress'),
  'Groningen' => _x('Groningen', 'ui', 'memberpress'),
  'Limburg' => _x('Limburg', 'ui', 'memberpress'),
  'Noord-Brabant' => _x('Noord-Brabant', 'ui', 'memberpress'),
  'Noord-Holland' => _x('Noord-Holland', 'ui', 'memberpress'),
  'Overijssel' => _x('Overijssel', 'ui', 'memberpress'),
  'Utrecht' => _x('Utrecht', 'ui', 'memberpress'),
  'Zeeland' => _x('Zeeland', 'ui', 'memberpress'),
  'Zuid-Holland' => _x('Zuid-Holland', 'ui', 'memberpress')
);

?>