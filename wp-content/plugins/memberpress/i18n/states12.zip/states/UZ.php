<?php
/**
 * Uzbekistan states
 */
$states['Uzbekistan'] = array(
  'Andijon Viloyati'  => _x('Andijon Viloyati', 'ui', 'memberpress'),
  'Buxoro Viloyati'  => _x('Buxoro Viloyati', 'ui', 'memberpress'),
  'Farg ona Viloyati'  => _x('Farg ona Viloyati', 'ui', 'memberpress'),
  'Jizzax Viloyati' => _x('Jizzax Viloyati', 'ui', 'memberpress'),
  'Namangan Viloyati'  => _x('Namangan Viloyati', 'ui', 'memberpress'),
  'Navoiy Viloyati'  => _x('Navoiy Viloyati', 'ui', 'memberpress'),
  'Qashqadaryo Viloyati'  => _x('Qashqadaryo Viloyati', 'ui', 'memberpress'),
  'Qaraqalpogiston Respublikasi'  => _x('Qaraqalpogiston Respublikasi', 'ui', 'memberpress'),
  'Samarqand Viloyati'  => _x('Samarqand Viloyati', 'ui', 'memberpress'),
  'Sirdaryo Viloyati'  => _x('Sirdaryo Viloyati', 'ui', 'memberpress'),
  'Surxondaryo Viloyati'  => _x('Surxondaryo Viloyati', 'ui', 'memberpress'),
  'Toshkent Shahri'  => _x('Toshkent Shahri', 'ui', 'memberpress'),
  'Toshkent Viloyati'  => _x('Toshkent Viloyati', 'ui', 'memberpress'),
  'Xorazm Viloyati'  => _x('Xorazm Viloyati', 'ui', 'memberpress')
);

