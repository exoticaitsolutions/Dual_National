<?php /* Silence will fall */ 

?>
