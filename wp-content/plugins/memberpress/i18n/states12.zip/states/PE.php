<?php
/**
 * Peru states
 */
$states['Peru'] = array(
  'El Callao' => _x('El Callao', 'ui', 'memberpress'),
  'Municipalidad Metropolitana de Lima' => _x('Municipalidad Metropolitana de Lima', 'ui', 'memberpress'),
  'Amazonas' => _x('Amazonas', 'ui', 'memberpress'),
  'Ancash' => _x('Ancash', 'ui', 'memberpress'),
  'Apur' => _x('Apur&iacute;mac', 'ui', 'memberpress'),
  'Arequipa' => _x('Arequipa', 'ui', 'memberpress'),
  'Ayacucho' => _x('Ayacucho', 'ui', 'memberpress'),
  'Cajamarca' => _x('Cajamarca', 'ui', 'memberpress'),
  'Cusco' => _x('Cusco', 'ui', 'memberpress'),
  'Huancavelica' => _x('Huancavelica', 'ui', 'memberpress'),
  'Hu&aacute;nuco' => _x('Hu&aacute;nuco', 'ui', 'memberpress'),
  'Ica' => _x('Ica', 'ui', 'memberpress'),
  'Jun&iacute;n' => _x('Jun&iacute;n', 'ui', 'memberpress'),
  'La Libertad' => _x('La Libertad', 'ui', 'memberpress'),
  'Lambayeque' => _x('Lambayeque', 'ui', 'memberpress'),
  'Lima' => _x('Lima', 'ui', 'memberpress'),
  'Loreto' => _x('Loreto', 'ui', 'memberpress'),
  'Madre de Dios' => _x('Madre de Dios', 'ui', 'memberpress'),
  'Moquegua' => _x('Moquegua', 'ui', 'memberpress'),
  'Pasco' => _x('Pasco', 'ui', 'memberpress'),
  'Piura' => _x('Piura', 'ui', 'memberpress'),
  'Puno' => _x('Puno', 'ui', 'memberpress'),
  'San Mart&iacute;n' => _x('San Mart&iacute;n', 'ui', 'memberpress'),
  'Tacna' => _x('Tacna', 'ui', 'memberpress'),
  'Tumbes' => _x('Tumbes', 'ui', 'memberpress'),
  'Ucayali' => _x('Ucayali', 'ui', 'memberpress')
);

