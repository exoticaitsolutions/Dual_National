<?php
/**
 * Liechtenstein states
 */
$states['Liechtenstein'] = array(
    'Balzers'                       => _x('Balzers', 'ui', 'memberpress'),
    'Eschen'                        => _x('Eschen', 'ui', 'memberpress'),
    'Gamprin'                       => _x('Gamprin', 'ui', 'memberpress'),
    'Mauren'                        => _x('Mauren', 'ui', 'memberpress'),
    'Planken'                       => _x('Planken', 'ui', 'memberpress'),
    'Ruggell'                       => _x('Ruggell', 'ui', 'memberpress'),
    'Schaan'                        => _x('Schaan', 'ui', 'memberpress'),
    'Schellenberg'                  => _x('Schellenberg', 'ui', 'memberpress'),
    'Triesen'                       => _x('Triesen', 'ui', 'memberpress'),
    'Triesenberg'                   => _x('Triesenberg', 'ui', 'memberpress'),
    'Vaduz'                         => _x('Vaduz', 'ui', 'memberpress')
);

?>