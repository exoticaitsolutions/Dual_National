<?php
/**
 * Saint-Barthélemy states
 */
$states['Saint-Barthélemy'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),

);

?>