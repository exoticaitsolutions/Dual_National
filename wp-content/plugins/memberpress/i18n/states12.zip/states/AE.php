<?php
/**
 * United Arab Emirates states
 */

$states['United Arab Emirates'] = array(
  'Abu Dhabi'  => _x('Abu Dhabi', 'ui', 'memberpress'),
  'Ajman'  => _x('Ajman', 'ui', 'memberpress'),
  'Al Fujayrah'  => _x('Al Fujayrah', 'ui', 'memberpress'),
  'Sharjah' => _x('Sharjah', 'ui', 'memberpress'),
  'Dubai'  => _x('Dubai', 'ui', 'memberpress'),
  'Ras al Khaymah'  => _x('Ras al Khaymah', 'ui', 'memberpress'),
  'Umm al Qaywayn'  => _x('Umm al Qaywayn', 'ui', 'memberpress')
);