<?php
/**
 * Sudan states
 */
$states['Sudan'] = array(
  "A'ali an Nil"=> _x("A'ali an Nil", 'ui', 'memberpress'),
  'Al Bahr al Ahmar' => _x('Al Bahr al Ahmar', 'ui', 'memberpress'),
  'Al Buhayrat' => _x('Al Buhayrat', 'ui', 'memberpress'),
  'Al Jazirah' => _x('Al Jazirah', 'ui', 'memberpress'),
  'Al Khartum' => _x('Al Khartum', 'ui', 'memberpress'),
  'Al Qadarif' => _x('Al Qadarif', 'ui', 'memberpress'),
  'Al Wahdah' => _x('Al Wahdah', 'ui', 'memberpress'),
  'An Nil al Abyad' => _x('An Nil al Abyad', 'ui', 'memberpress'),
  'An Nil al Azraq' => _x('An Nil al Azraq', 'ui', 'memberpress'),
  'Ash Shamaliyah' => _x('Ash Shamaliyah', 'ui', 'memberpress'),
  'Bahr al Jabal' => _x('Bahr al Jabal', 'ui', 'memberpress'),
  "Gharb al Istiwa'iyah" => _x("Gharb al Istiwa'iyah", 'ui', 'memberpress'),
  'Gharb Darfur' => _x('Gharb Darfur', 'ui', 'memberpress'),
  'Gharb Kurdufan' => _x('Gharb Kurdufan', 'ui', 'memberpress'),
  'Janub Darfur' => _x('Janub Darfur', 'ui', 'memberpress'),
  'Janub Kurdufan' => _x('Janub Kurdufan', 'ui', 'memberpress'),
  'Junqali' => _x('Junqali', 'ui', 'memberpress'),
  'Kassala' => _x('Kassala', 'ui', 'memberpress'),
  'Nahr an Nil' => _x('Nahr an Nil', 'ui', 'memberpress'),
  'Shamal Bahr al Ghazal' => _x('Shamal Bahr al Ghazal', 'ui', 'memberpress'),
  'Shamal Darfur' => _x('Shamal Darfur', 'ui', 'memberpress'),
  'Shamal Kurdufan' => _x('Shamal Kurdufan', 'ui', 'memberpress'),
  "Sharq al Istiwa'iyah" => _x("Sharq al Istiwa'iyah", 'ui', 'memberpress'),
  'Sinnar' => _x('Sinnar', 'ui', 'memberpress'),
  'Warab' => _x('Warab', 'ui', 'memberpress')
);

?>