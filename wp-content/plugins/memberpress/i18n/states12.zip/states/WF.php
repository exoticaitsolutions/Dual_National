<?php
/**
 * Wallis and Futuna states
 */
$states['Wallis and Futuna'] = array(
  'No State of this country' => _x('No State of this country', 'ui', 'memberpress')
);

?>