<?php
/**
 * Mozambique states
 */
$states['Mozambique'] = array(
  'Cabo Delgado' => _x('Cabo Delgado', 'ui', 'memberpress'),
  'Gaza' => _x('Gaza', 'ui', 'memberpress'),
  'Inhambane' => _x('Inhambane', 'ui', 'memberpress'),
  'Manica' => _x('Manica', 'ui', 'memberpress'),
  'Maputo' => _x('Maputo', 'ui', 'memberpress'),
  'Cidade de Maputo' => _x('Cidade de Maputo', 'ui', 'memberpress'),
  'Nampula' => _x('Nampula', 'ui', 'memberpress'),
  'Niassa' => _x('Niassa', 'ui', 'memberpress'),
  'Sofala' => _x('Sofala', 'ui', 'memberpress'),
  'Tete' => _x('Tete', 'ui', 'memberpress'),
  'Zambezia' => _x('Zambezia', 'ui', 'memberpress')
);

?>