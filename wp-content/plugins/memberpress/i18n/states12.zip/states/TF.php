<?php
/**
 * French Southern Territories states
 */
$states['French Southern Territories'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
 
  
);

