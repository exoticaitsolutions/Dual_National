<?php
/**
 * Nauru states
 */
$states['Nauru'] = array(
  'Aiwo' => _x('Aiwo', 'ui', 'memberpress'),
  'Anabar' => _x('Anabar', 'ui', 'memberpress'),
  'Anetan' => _x('Anetan', 'ui', 'memberpress'),
  'Anibare' => _x('Anibare', 'ui', 'memberpress')
);

?>