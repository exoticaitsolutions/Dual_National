<?php
/**
 * Bahamas states
 */
$states['Bahamas'] = array(
  'Acklins and Crooked Islands'         => _x('Acklins and Crooked Islands', 'ui', 'memberpress'),
  'Bimini'         => _x('Bimini', 'ui', 'memberpress'),
  'Cat Island'         => _x('Cat Island', 'ui', 'memberpress'),
  'Exuma'         => _x('Exuma', 'ui', 'memberpress'),
  'Freeport'         => _x('Freeport', 'ui', 'memberpress'),
  'Fresh Cree'         => _x('Fresh Cree', 'ui', 'memberpress'),
  "Governor's Harbour"       => _x("Governor's Harbour" , 'ui', 'memberpress'),
  'Green Turtle Cay'         => _x('Green Turtle Cay', 'ui', 'memberpress'),
  'Harbour Island'         => _x('Harbour Island', 'ui', 'memberpress'),
  'High Rock'         => _x('High Rock', 'ui', 'memberpress'),
  'Inagua'         => _x('Inagua', 'ui', 'memberpress'),
  'Kemps Bay'         => _x('Kemps Bay', 'ui', 'memberpress'),
  'Long Island'         => _x('Long Island', 'ui', 'memberpress'),
  'Marsh Harbour'         => _x('Marsh Harbour', 'ui', 'memberpress'),
  'Mayaguana'         => _x('Mayaguana', 'ui', 'memberpress'),
  'New Providence'         => _x('New Providence', 'ui', 'memberpress'),
  'Nichollstown and Berry Islands'         => _x('Nichollstown and Berry Islands', 'ui', 'memberpress'),
  'Ragged Island'         => _x('Ragged Island', 'ui', 'memberpress'),
  'Rock Sound'         => _x('Rock Sound', 'ui', 'memberpress'),
  'Sandy Point'         => _x('Sandy Point', 'ui', 'memberpress'),
  'San Salvador'         => _x('San Salvador', 'ui', 'memberpress'),
  'Rum Cay'         => _x('Rum Cay', 'ui', 'memberpress')
);


?>
