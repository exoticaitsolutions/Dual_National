<?php
/**
 * New Caledonia states
 */
$states['New Caledonia'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress')
);

?>