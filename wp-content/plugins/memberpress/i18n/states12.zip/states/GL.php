<?php
/**
 * Greenland states
 */
$states['Greenland'] = array(
  'Avannaa (Nordgronland)' => _x('Avannaa (Nordgronland)', 'ui', 'memberpress'),
  'Tunu (Ostgronland)' => _x('Tunu (Ostgronland)', 'ui', 'memberpress'),
  'Kitaa (Vestgronland)' => _x('Kitaa (Vestgronland)', 'ui', 'memberpress'),
   
);
