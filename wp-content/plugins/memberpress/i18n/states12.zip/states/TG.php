<?php
/**
 * Togo states
 */
$states['Togo'] = array(
  'Kara'  => _x('Kara', 'ui', 'memberpress'),
  'Plateaux'  => _x('Plateaux', 'ui', 'memberpress'),
  'Savanes'  => _x('Savanes', 'ui', 'memberpress'),
  'Centrale' => _x('Centrale', 'ui', 'memberpress'),
  'Maritime'  => _x('Maritime', 'ui', 'memberpress')
);

