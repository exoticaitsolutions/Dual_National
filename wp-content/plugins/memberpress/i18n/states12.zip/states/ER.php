<?php
/**
 * Eritrea states
 */
$states['Eritrea'] = array(
  'Annobon'       => _x('Annobon', 'ui', 'memberpress'), 'Ahuachapan'       => _x('Ahuachapan', 'ui', 'memberpress'),
   'Bioko Norte'       => _x('Bioko Norte', 'ui', 'memberpress'),
   'Bioko Sur'       => _x('Bioko Sur', 'ui', 'memberpress'),
   'Centro Sur'       => _x('Centro Sur', 'ui', 'memberpress'),
   'Kie-Ntem'       => _x('Kie-Ntem', 'ui', 'memberpress'),
   'Litoral'       => _x('Litoral', 'ui', 'memberpress'),
   'Wele-Nzas'       => _x('Wele-Nzas', 'ui', 'memberpress')
);

