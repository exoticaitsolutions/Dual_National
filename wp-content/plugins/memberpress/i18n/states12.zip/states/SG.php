<?php
/**
 * Singapore states
 */
$states['Singapore'] = array(
  'Central Region' => _x('Central Region', 'ui', 'memberpress'),
  'Bishan' => _x('Bishan', 'ui', 'memberpress'),
  'Bukit Merah' => _x('Bukit Merah', 'ui', 'memberpress'),
  'Bukit Timah' => _x('Bukit Timah', 'ui', 'memberpress'),
  'Central Area' => _x('Central Area', 'ui', 'memberpress'),
  'Geylang' => _x('Geylang', 'ui', 'memberpress'),
  'Kallang' => _x('Kallang', 'ui', 'memberpress'),
  'Marine Parade' => _x('Marine Parade', 'ui', 'memberpress'),
  'Novena' => _x('Novena', 'ui', 'memberpress'),
  'Queenstown' => _x('Queenstown', 'ui', 'memberpress'),
  'Toa Payoh' => _x('Toa Payoh', 'ui', 'memberpress'),
  'East Region' => _x('East Region', 'ui', 'memberpress'),
  'North Region' => _x('North Region', 'ui', 'memberpress'),
  'North-East Region' => _x('North-East Region', 'ui', 'memberpress'),
  'West Region' => _x('West Region', 'ui', 'memberpress')
);

?>