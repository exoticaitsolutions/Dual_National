<?php
/**
 * Puerto Rico states
 */
$states['Puerto Rico'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress')
);

?>