<?php
/**
 * Falkland Islands states
 */
$states['Guatemala'] = array(
  'Alta Verapaz' => _x('Alta Verapaz', 'ui', 'memberpress'),
  'Baja Verapaz' => _x('Baja Verapaz', 'ui', 'memberpress'),
  'Chimaltenango' => _x('Chimaltenango', 'ui', 'memberpress'),
  'El Progreso' => _x('El Progreso', 'ui', 'memberpress'),
  'Escuintla' => _x('Escuintla', 'ui', 'memberpress'),
  'Huehuetenango' => _x('Huehuetenango', 'ui', 'memberpress'),
  'Izabal' => _x('Izabal', 'ui', 'memberpress'),
  'Jalapa' => _x('Jalapa', 'ui', 'memberpress'),
  'Jutiapa' => _x('Jutiapa', 'ui', 'memberpress'),
  'Peten' => _x('Peten', 'ui', 'memberpress'),
  'Quetzaltenango' => _x('Quetzaltenango', 'ui', 'memberpress'),
  'Quiche' => _x('Quiche', 'ui', 'memberpress'),
  'Retalhuleu' => _x('Retalhuleu', 'ui', 'memberpress'),
  'Sacatepequez' => _x('Sacatepequez', 'ui', 'memberpress'),
  'San Marcos' => _x('San Marcos', 'ui', 'memberpress'),
  'Solola' => _x('Solola', 'ui', 'memberpress'),
  'Suchitepequez' => _x('Suchitepequez', 'ui', 'memberpress'),
  'Totonicapan' => _x('Totonicapan', 'ui', 'memberpress'),
  'Zacapa' => _x('Zacapa', 'ui', 'memberpress')
  
);

     