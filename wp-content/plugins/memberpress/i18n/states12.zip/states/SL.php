<?php
/**
 * Sierra Leone states
 */
$states['Sierra Leone'] = array(
  'Sierra Leone' => _x('Sierra Leone', 'ui', 'memberpress'),
  // No states of this Country

);

?>