<?php
/**
 * Chile  States
 */
 $states['Chile'] = array(
    'Aysen'       => _x('Aysen', 'ui', 'memberpress'),
    'Antofagasta'       => _x('Antofagasta', 'ui', 'memberpress'),
    'Araucania'       => _x('Araucania', 'ui', 'memberpress'),
    'Atacama'       => _x('Atacama', 'ui', 'memberpress'),
    'Bio-Bio'       => _x('Bio-Bio', 'ui', 'memberpress'),
    'Coquimbo'       => _x('Coquimbo', 'ui', 'memberpress'),
    "O'Higgins"         => _x(  "O'Higgins"   , 'ui', 'memberpress'),
    'Los Lago'       => _x('Los Lago', 'ui', 'memberpress'),
    'Magallanes y la Antartica Chilena'       => _x('Magallanes y la Antartica Chilena', 'ui', 'memberpress'),
    'Maule'       => _x('Maule', 'ui', 'memberpress'),
    'Santiago Region Metropolitana'       => _x('Santiago Region Metropolitana', 'ui', 'memberpress'),
    'Tarapaca'       => _x('Tarapaca', 'ui', 'memberpress'),
    'Valparaiso'       => _x('Valparaiso', 'ui', 'memberpress')
  );
 ?>