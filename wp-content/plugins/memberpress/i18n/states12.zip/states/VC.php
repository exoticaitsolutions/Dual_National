<?php
/**
 * Saint Vincent and the Grenadines states
 */
$states['Saint Vincent and the Grenadines'] = array(
  'Charlotte' => _x('Charlotte', 'ui', 'memberpress'),
  'Grenadines' => _x('Grenadines', 'ui', 'memberpress'),
  'Saint Andrew' => _x('Saint Andrew', 'ui', 'memberpress'),
  'Saint David' => _x('Saint David', 'ui', 'memberpress'),
  'Saint George' => _x('Saint George', 'ui', 'memberpress'),
  'Saint Patrick' => _x('Saint Patrick', 'ui', 'memberpress')
);

?>