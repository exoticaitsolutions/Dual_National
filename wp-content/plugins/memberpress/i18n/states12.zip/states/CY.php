<?php
/**
 * Cyprus  States
 */
 $states['Cyprus'] = array(
    'Famagusta'       => _x('Famagusta', 'ui', 'memberpress'),
    'Kyrenia'       => _x('Kyrenia', 'ui', 'memberpress'),
    'Larnaca'       => _x('Larnaca', 'ui', 'memberpress'),
    'Limassol'       => _x('Limassol', 'ui', 'memberpress'),
    'Paphos'       => _x('Batdambang', 'ui', 'memberpress')
  );
 ?>