<?php
/**
 * Guinea-Bissau states
 */
$states['Guinea-Bissau'] = array(
  'Bafata' => _x('Bafata', 'ui', 'memberpress'),
  'Biombo' => _x('Biombo', 'ui', 'memberpress'),
  'Bissau' => _x('Bissau', 'ui', 'memberpress'),
  'Bolama' => _x('Bolama', 'ui', 'memberpress'),
  'Cacheu' => _x('Cacheu', 'ui', 'memberpress'),
  'Gabu' => _x('Gabu', 'ui', 'memberpress'),
  'Oio' => _x('Oio', 'ui', 'memberpress'),
  'Quinara' => _x('Quinara', 'ui', 'memberpress'),
  'Tombali' => _x('Tombali', 'ui', 'memberpress'),
  
);

