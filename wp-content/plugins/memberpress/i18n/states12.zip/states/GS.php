<?php
/**
 * South Georgia/Sandwich Islands states
 */
$states['South Georgia/Sandwich Islands'] = array(
  'South Georgia/Sandwich Islands' => _x('South Georgia/Sandwich Islands', 'ui', 'memberpress'),
  // No states of this Country

);

?>