<?php
/**
 * Sri Lanka states
 */
$states['Sri Lanka'] = array(
  'Central Province' => _x('Central Province', 'ui', 'memberpress'),
  'Eastern Province' => _x('Eastern Province', 'ui', 'memberpress'),
  'Northern Province' => _x('Northern Province', 'ui', 'memberpress'),
  'North Central Province' => _x('North Central Province', 'ui', 'memberpress'),
  'North Western Province' => _x('North Western Province', 'ui', 'memberpress'),
  'Sabaragamuwa Province' => _x('Sabaragamuwa Province', 'ui', 'memberpress'),
  'Southern Province' => _x('Southern Province', 'ui', 'memberpress'),
  'Uva Province' => _x('Uva Province', 'ui', 'memberpress'),
  'Western Province' => _x('Western Province', 'ui', 'memberpress')
);

?>