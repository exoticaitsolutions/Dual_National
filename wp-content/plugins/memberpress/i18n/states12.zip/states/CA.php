<?php
/**
 * Canadian states
 */
$states['Canada'] = array(
  'Alberta' => _x('Alberta', 'ui', 'memberpress'),
  'British Columbia' => _x('British Columbia', 'ui', 'memberpress'),
  'Manitoba' => _x('Manitoba', 'ui', 'memberpress'),
  'New Brunswick' => _x('New Brunswick', 'ui', 'memberpress'),
  'NewfoundlandNL' => _x('Newfoundland', 'ui', 'memberpress'),
  'Northwest Territories' => _x('Northwest Territories', 'ui', 'memberpress'),
  'Nova Scoti' => _x('Nova Scotia', 'ui', 'memberpress'),
  'Nunavut' => _x('Nunavut', 'ui', 'memberpress'),
  'Ontario' => _x('Ontario', 'ui', 'memberpress'),
  'Prince Edward Island' => _x('Prince Edward Island', 'ui', 'memberpress'),
  'Quebec' => _x('Quebec', 'ui', 'memberpress'),
  'Saskatchewan' => _x('Saskatchewan', 'ui', 'memberpress'),
  'Yukon Territory' => _x('Yukon Territory', 'ui', 'memberpress')
);

