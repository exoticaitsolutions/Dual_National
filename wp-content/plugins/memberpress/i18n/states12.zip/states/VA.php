<?php
/**
 * Vatican  states
 */
$states['Vatican'] = array(
  'No State of this country' => _x('No State of this country', 'ui', 'memberpress')
);