<?php
/**
 * Saint Helena states
 */
$states['Saint Helena'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
);

?>