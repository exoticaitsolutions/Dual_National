<?php
/**
 * Costa Rica  States
 */
 $states['Costa Rica'] = array(
    'Alajuela'       => _x('Alajuela', 'ui', 'memberpress'),
    'Cartago'       => _x('Cartago', 'ui', 'memberpress'),
    'Guanacaste'       => _x('Guanacaste', 'ui', 'memberpress'),
    'Heredia'       => _x('Heredia', 'ui', 'memberpress'),
    'Limon'       => _x('Limon', 'ui', 'memberpress'),
    'Puntarenas'       => _x('Puntarenas', 'ui', 'memberpress'),
    'San Jose'       => _x('San Jose', 'ui', 'memberpress')
  );
 ?>