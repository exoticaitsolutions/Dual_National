<?php
/**
 * Gabon states
 */
$states['Ghana'] = array(
  'Ashanti' => _x('Ashanti', 'ui', 'memberpress'),
  'Brong-Ahafo' => _x('Brong-Ahafo', 'ui', 'memberpress'),
  'Central' => _x('Central', 'ui', 'memberpress'),
  'Greater Accra' => _x('Greater Accra', 'ui', 'memberpress'),
  'Northern' => _x('Northern', 'ui', 'memberpress'),
  'Upper East' => _x('Upper East', 'ui', 'memberpress'),
  'Upper West' => _x('Upper West', 'ui', 'memberpress'),
  'Volta' => _x('Volta', 'ui', 'memberpress'),
  'Western' => _x('Western', 'ui', 'memberpress')  
);
