<?php
/**
 * Norway states
 */
$states['Norway'] = array(
  'Akershus' => _x('Akershus', 'ui', 'memberpress'),
  'Aust-Agder' => _x('Aust-Agder', 'ui', 'memberpress'),
  'Buskerud' => _x('Buskerud', 'ui', 'memberpress'),
  'Finnmark' => _x('Finnmark', 'ui', 'memberpress'),
  'Hedmark' => _x('Hedmark', 'ui', 'memberpress'),
  'Hordaland' => _x('Hordaland', 'ui', 'memberpress'),
  'More og Romsdal' => _x('More og Romsdal', 'ui', 'memberpress'),
  'Nordland' => _x('Nordland', 'ui', 'memberpress'),
  'Nord-Trondelag' => _x('Nord-Trondelag', 'ui', 'memberpress'),
  'Oppland' => _x('Oppland', 'ui', 'memberpress'),
  'Oslo' => _x('Oslo', 'ui', 'memberpress'),
  'Ostfold' => _x('Ostfold', 'ui', 'memberpress'),
  'Rogaland' => _x('Rogaland', 'ui', 'memberpress'),
  'Sogn og Fjordane' => _x('Sogn og Fjordane', 'ui', 'memberpress'),
  'Sor-Trondelag' => _x('Sor-Trondelag', 'ui', 'memberpress'),
  'Telemark' => _x('Telemark', 'ui', 'memberpress'),
  'Troms' => _x('Troms', 'ui', 'memberpress'),
  'Vest-Agder' => _x('Vest-Agder', 'ui', 'memberpress'),
  'Vestfold' => _x('Vestfold', 'ui', 'memberpress')
);

?>