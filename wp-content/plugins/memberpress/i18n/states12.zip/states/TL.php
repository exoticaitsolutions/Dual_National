<?php
/**
 * Timor-Leste states
 */
$states['Timor-Leste'] = array(
  'Timor-Leste' => _x('Timor-Leste', 'ui', 'memberpress'),
  // No states of this Country

);

?>