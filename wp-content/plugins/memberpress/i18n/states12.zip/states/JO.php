<?php
/**
 * Jordan states
 */
$states['Jordan'] = array(
    'Ajlun'                   => _x('Ajlun', 'ui', 'memberpress'),
    'Al Aqabah'               => _x('Al Aqabah', 'ui', 'memberpress'),
    'Al Balqa'                => _x('Al Balqa', 'ui', 'memberpress'),
    'Al Karak'                => _x('Al Karak', 'ui', 'memberpress'),
    'Al Mafraq'               => _x('Al Mafraq', 'ui', 'memberpress'),
    'Amman'                   => _x('Amman', 'ui', 'memberpress'),
    'At Tafilah'              => _x('At Tafilah', 'ui', 'memberpress'),
    'Az Zarqa'                => _x('Az Zarqa', 'ui', 'memberpress'),
    'Irbid'                   => _x('Irbid', 'ui', 'memberpress'),
    'Jarash'                  => _x('Jarash', 'ui', 'memberpress'),
    'Ma an'                   => _x('Ma an', 'ui', 'memberpress'),
    'Madaba'                  => _x('Madaba', 'ui', 'memberpress')

 
);

?>