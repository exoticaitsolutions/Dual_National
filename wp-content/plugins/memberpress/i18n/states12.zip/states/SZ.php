<?php
/**
 * Swaziland states
 */
$states['Swaziland'] = array(
  'Hhohho' => _x('Hhohho', 'ui', 'memberpress'),
  'Lubombo' => _x('Lubombo', 'ui', 'memberpress'),
  'Manzini' => _x('Manzini', 'ui', 'memberpress'),
  'Shiselweni' => _x('Shiselweni', 'ui', 'memberpress'),
);
