<?php
/**
 * Australian states
 */
$states['Australia'] = array(
  'Australian Capital Territory' => _x('Australian Capital Territory', 'ui', 'memberpress'),
  'New South Wales' => _x('New South Wales', 'ui', 'memberpress'),
  'Northern Territory'  => _x('Northern Territory', 'ui', 'memberpress'),
  'Queensland' => _x('Queensland', 'ui', 'memberpress'),
  'South Australia'  => _x('South Australia', 'ui', 'memberpress'),
  'Tasmania' => _x('Tasmania', 'ui', 'memberpress'),
  'Victoria' => _x('Victoria', 'ui', 'memberpress'),
  'Western Australia'  => _x('Western Australia', 'ui', 'memberpress')
);

