<?php
/**
 * Saint Martin (French part) states
 */
$states['Saint Martin (French part)'] = array(
  'Saint Martin (French part)' => _x('Saint Martin (French part)', 'ui', 'memberpress'),
);

?>