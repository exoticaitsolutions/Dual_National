<?php
/**
 * Libya states
 */
$states['Libya'] = array(
    'Ajdabiya'                          => _x('Ajdabiya', 'ui', 'memberpress'),
    'Al Aziziyah'                       => _x('Al Aziziyah', 'ui', 'memberpress'),
    'Al Fatih'                          => _x('Al Fatih', 'ui', 'memberpress'),
    'Al Jabal al Akhdar'                => _x('Al Jabal al Akhdar', 'ui', 'memberpress'),
    'Al Jufrah'                         => _x('Al Jufrah', 'ui', 'memberpress'),
    'Al Khums'                          => _x('Al Khums', 'ui', 'memberpress'),
    'Al Kufrah'                         => _x('Al Kufrah', 'ui', 'memberpress'),
    'An Nuqat al Khams'                 => _x('An Nuqat al Khams', 'ui', 'memberpress'),
    'Ash Shati'                         => _x('Ash Shati', 'ui', 'memberpress'),
    'Awbari'                            => _x('Awbari', 'ui', 'memberpress'),
    'Az Zawiyah'                        => _x('Az Zawiyah', 'ui', 'memberpress'),
    'Banghazi'                          => _x('Banghazi', 'ui', 'memberpress'),
    'Darnah'                            => _x('Darnah', 'ui', 'memberpress'),
    'Ghadamis'                          => _x('Ghadamis', 'ui', 'memberpress'),
    'Gharyan'                           => _x('Gharyan', 'ui', 'memberpress'),
    'Misratah'                          => _x('Misratah', 'ui', 'memberpress'),
    'Murzuq'                            => _x('Murzuq', 'ui', 'memberpress'),
    'Sabha'                             => _x('Sabha', 'ui', 'memberpress'),
    'Sawfajjin'                         => _x('Sawfajjin', 'ui', 'memberpress'),
    'Surt'                              => _x('Surt', 'ui', 'memberpress'),
    'Tarabulus'                         => _x('Tarabulus', 'ui', 'memberpress'),
    'Tarhunah'                          => _x('Tarhunah', 'ui', 'memberpress'),
    'Tubruq'                            => _x('Tubruq', 'ui', 'memberpress'),
    'Yafran'                            => _x('Yafran', 'ui', 'memberpress'),
    'Zlitan'                            => _x('Zlitan', 'ui', 'memberpress')
    
);

?>