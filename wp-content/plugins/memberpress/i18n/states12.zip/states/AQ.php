<?php
/**
 * Antarctica states
 */
$states['Antarctica'] = array(
    'Antarctica'       => _x('Antarctica', 'ui', 'memberpress')
);

?>