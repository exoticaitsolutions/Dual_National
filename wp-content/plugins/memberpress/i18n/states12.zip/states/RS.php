<?php
/**
 * Serbia states
 */
$states['Serbia'] = array(
  'Valjevo' => _x('Valjevo', 'ui', 'memberpress'),
  'Šabac' => _x('Šabac', 'ui', 'memberpress'),
  'Čačak' => _x('Čačak', 'ui', 'memberpress'),
  'Jagodina' => _x('Jagodina', 'ui', 'memberpress'),
  'Kruševac' => _x('Kruševac', 'ui', 'memberpress'),
  'Kraljevo' => _x('Kraljevo', 'ui', 'memberpress'),
  'Kragujevac' => _x('Kragujevac', 'ui', 'memberpress'),
  'Užice' => _x('Užice', 'ui', 'memberpress'),
  'Bor' => _x('Bor', 'ui', 'memberpress'),
  'Požarevac' => _x('Požarevac', 'ui', 'memberpress'),
  'Leskovac' => _x('Leskovac', 'ui', 'memberpress'),
  'Niš' => _x('Niš', 'ui', 'memberpress'),
  'Vranje' => _x('Vranje', 'ui', 'memberpress'),
  'Pirot' => _x('Pirot', 'ui', 'memberpress'),
  'Smederevo' => _x('Smederevo', 'ui', 'memberpress'),
  'Prokuplje' => _x('Prokuplje', 'ui', 'memberpress'),
  'Zaječar' => _x('Zaječar', 'ui', 'memberpress'),
  'Zrenjanin' => _x('Zrenjanin', 'ui', 'memberpress'),
  'Subotica' => _x('Subotica', 'ui', 'memberpress'),
  'Kikinda' => _x('Kikinda', 'ui', 'memberpress'),
  'Novi Sad' => _x('Novi Sad', 'ui', 'memberpress'),
  'Pančevo' => _x('Pančevo', 'ui', 'memberpress'),
  'Sremska' => _x('Sremska', 'ui', 'memberpress'),
  'Mitrovica' => _x('Mitrovica', 'ui', 'memberpress'),
  'Sombor' => _x('Sombor', 'ui', 'memberpress')
);

?>