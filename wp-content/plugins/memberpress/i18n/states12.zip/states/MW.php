<?php
/**
 * Malawi states
 */
$states['Malawi'] = array(
  'Balaka' => _x('Balaka', 'ui', 'memberpress'),
  'Blantyre' => _x('Blantyre', 'ui', 'memberpress'),
  'Chikwawa' => _x('Chikwawa', 'ui', 'memberpress'),
  'Chiradzulu' => _x('Chiradzulu', 'ui', 'memberpress'),
  'Chitipa' => _x('Chitipa', 'ui', 'memberpress'),
  'Dedza' => _x('Dedza', 'ui', 'memberpress'),
  'Dowa' => _x('Dowa', 'ui', 'memberpress'),
  'Kasungu' => _x('Kasungu', 'ui', 'memberpress'),
  'Likoma' => _x('Likoma', 'ui', 'memberpress'),
  'Lilongwe' => _x('Lilongwe', 'ui', 'memberpress'),
  'Machinga' => _x('Machinga', 'ui', 'memberpress'),
  'Mangochi' => _x('Mangochi', 'ui', 'memberpress'),
  'Mchinji' => _x('Mchinji', 'ui', 'memberpress'),
  'Mulanje' => _x('Mulanje', 'ui', 'memberpress'),
  'Mwanza' => _x('Mwanza', 'ui', 'memberpress'),
  'Mzimba' => _x('Mzimba', 'ui', 'memberpress'),
  'Ntcheu' => _x('Ntcheu', 'ui', 'memberpress'),
  'Nkhata Bay' => _x('Nkhata Bay', 'ui', 'memberpress'),
  'Nkhotakota' => _x('Nkhotakota', 'ui', 'memberpress'),
  'Nsanje' => _x('Nsanje', 'ui', 'memberpress'),
  'Phalombe' => _x('Phalombe', 'ui', 'memberpress'),
  'Rumphi' => _x('Rumphi', 'ui', 'memberpress'),
  'Salima' => _x('Salima', 'ui', 'memberpress'),
  'Thyolo' => _x('Thyolo', 'ui', 'memberpress'),
  'Zomba' => _x('Zomba', 'ui', 'memberpress')
);

     