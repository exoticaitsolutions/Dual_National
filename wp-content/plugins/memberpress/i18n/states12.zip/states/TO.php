<?php
/**
 * Tonga states
 */
$states['Tonga'] = array(
  'Tongatapu' => _x('Tongatapu', 'ui', 'memberpress'),
  'Vavaʻu' => _x('Vavaʻu', 'ui', 'memberpress'),
  'Haʻapai' => _x('Haʻapai', 'ui', 'memberpress'),
  'ʻEua' => _x('ʻEua', 'ui', 'memberpress'),
  'Ongo Niua' => _x('Ongo Niua', 'ui', 'memberpress'),
  'Tonga' => _x('Tonga', 'ui', 'memberpress'),
);
