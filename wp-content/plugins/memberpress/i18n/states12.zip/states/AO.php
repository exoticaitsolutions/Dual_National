<?php
/**
 * Angola states
 */
$states['Angola'] = array(
    'Bengo'       => _x('Bengo', 'ui', 'memberpress'),
    'Benguela'       => _x('Benguela', 'ui', 'memberpress'),
    'Bié'       => _x('Bié', 'ui', 'memberpress'),
    'Cabinda'       => _x('Cabinda', 'ui', 'memberpress'),
    'Cuando Cubango'       => _x('Cuando Cubango', 'ui', 'memberpress'),
    'Cuanza Norte'       => _x('Cuanza Norte', 'ui', 'memberpress'),
    'Cuanza Sul'       => _x('Cuanza Sul', 'ui', 'memberpress'),
    'Cunene'       => _x('Cunene', 'ui', 'memberpress'),
    'Huambo'       => _x('Huambo', 'ui', 'memberpress'),
    'Huíla'       => _x('Huíla', 'ui', 'memberpress'),
    'Luanda'       => _x('Luanda', 'ui', 'memberpress'),
    'Lunda Norte'       => _x('Lunda Norte', 'ui', 'memberpress'),
    'Lunda Sul'       => _x('Lunda Sul', 'ui', 'memberpress'),
    'Malanje'       => _x('Malanje', 'ui', 'memberpress'),
    'Moxico'       => _x('Moxico', 'ui', 'memberpress'),
    'Namibe'       => _x('Namibe', 'ui', 'memberpress'),
    'Bengo'       => _x('Bengo', 'ui', 'memberpress'),
    'Uíge'       => _x('Uíge', 'ui', 'memberpress'),
    'Zaire'       => _x('Zaire', 'ui', 'memberpress')
);
?>