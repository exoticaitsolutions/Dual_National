  <?php
/**
 * Venezuela states
 */

$states['Venezuela'] = array(
  'Amazonas'  => _x('Amazonas', 'ui', 'memberpress'),
  'Anzoategui'  => _x('Anzoategui', 'ui', 'memberpress'),
  'Apure'  => _x('Apure', 'ui', 'memberpress'),
  'Aragua' => _x('Aragua', 'ui', 'memberpress'),
  'Barinas'  => _x('Barinas', 'ui', 'memberpress'),
  'Bolivar'  => _x('Bolivar', 'ui', 'memberpress'),
  'Carabobo'  => _x('Carabobo', 'ui', 'memberpress'),
  'Cojedes'  => _x('Cojedes', 'ui', 'memberpress'),
  'Delta Amacuro'  => _x('Delta Amacuro', 'ui', 'memberpress'),
  'Dependencias Federales'  => _x('Dependencias Federales', 'ui', 'memberpress'),
  'Distrito Federal'  => _x('Distrito Federal', 'ui', 'memberpress'),
  'Falcon'  => _x('Falcon', 'ui', 'memberpress'),
  'Guarico'  => _x('Guarico', 'ui', 'memberpress'),
  'Lara'  => _x('Lara', 'ui', 'memberpress'),
  'Merida'  => _x('Merida', 'ui', 'memberpress'),
  'Miranda'  => _x('Miranda', 'ui', 'memberpress'),
  'Monagas'  => _x('Monagas', 'ui', 'memberpress'),
  'Nueva Esparta'  => _x('Nueva Esparta', 'ui', 'memberpress'),
  'Portuguesa'  => _x('Portuguesa', 'ui', 'memberpress'),
  'Sucre'  => _x('Sucre', 'ui', 'memberpress'),
  'Tachira'  => _x('Tachira', 'ui', 'memberpress'),
  'Trujillo'  => _x('Trujillo', 'ui', 'memberpress'),
  'Vargas'  => _x('Vargas', 'ui', 'memberpress'),
  'Yaracuy'  => _x('Yaracuy', 'ui', 'memberpress'),
  'Zulia'  => _x('Zulia', 'ui', 'memberpress')
);

