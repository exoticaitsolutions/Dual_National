<?php
/**
 * Mali states
 */
$states['Mali'] = array(
  'Bamako (Capital)' => _x('Bamako (Capital)', 'ui', 'memberpress'),
  'Gao' => _x('Gao', 'ui', 'memberpress'),
   'Kayes' => _x('Kayes', 'ui', 'memberpress'),
    'Kidal' => _x('Kidal', 'ui', 'memberpress'),
     'Koulikoro' => _x('Koulikoro', 'ui', 'memberpress'),
      'Mopti' => _x('Mopti', 'ui', 'memberpress'),
       'Segou' => _x('Segou', 'ui', 'memberpress'),
        'Sikasso' => _x('Sikasso', 'ui', 'memberpress'),
         
  
);
      
