<?php
/**
 * Israel states
 */
$states['Israel'] = array(
    'Central'              => _x('Central', 'ui', 'memberpress'),
    'Haifa'                => _x('Haifa', 'ui', 'memberpress'),
    'Jerusalem'            => _x('Jerusalem', 'ui', 'memberpress'),
    'Northern'             => _x('Northern', 'ui', 'memberpress'),
    'Southern'             => _x('Southern', 'ui', 'memberpress'),
    'Tel Aviv'             => _x('Tel Aviv', 'ui', 'memberpress')
);

?>