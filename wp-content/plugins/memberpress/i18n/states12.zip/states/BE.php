<?php
/**
 * Belgium states
 */
$states['Belgium'] = array(
  'Antwerpen'         => _x('Antwerpen', 'ui', 'memberpress'),
  'Brabant Wallon'         => _x('Brabant Wallon', 'ui', 'memberpress'),
  'Brussels'         => _x('Brussels', 'ui', 'memberpress'),
  'Flanders'         => _x('Flanders', 'ui', 'memberpress'),
  'Hainaut'         => _x('Hainaut', 'ui', 'memberpress'),
  'Liege'         => _x('Liege', 'ui', 'memberpress'),
  'Limburg'         => _x('Limburg', 'ui', 'memberpress'),
  'Luxembourg'         => _x('Luxembourg', 'ui', 'memberpress'),
  'Namur'         => _x('Namur', 'ui', 'memberpress'),
  'Oost-Vlaanderen'         => _x('Oost-Vlaanderen', 'ui', 'memberpress'),
  'Vlaams-Brabant'         => _x('Vlaams-Brabant', 'ui', 'memberpress'),
  'Wallonia'         => _x('Wallonia', 'ui', 'memberpress'),
  'West-Vlaanderen'         => _x('West-Vlaanderen', 'ui', 'memberpress')
);


?>