<?php
/**
 * Anguilla states
 */
$states['Anguilla'] = array(
    'Anguilla'       => _x('Anguilla', 'ui', 'memberpress'),
);

?>

