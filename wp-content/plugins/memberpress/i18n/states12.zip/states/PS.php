<?php
/**
 * Madagascar states
 */
$states['Palestinian Territory'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
  // No states of this Country

);

?>