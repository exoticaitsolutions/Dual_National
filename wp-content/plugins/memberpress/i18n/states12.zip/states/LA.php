<?php
/**
 * Laos states
 */
$states['Laos'] = array(
    'Attapu'                      => _x('Attapu', 'ui', 'memberpress'),
    'Bokeo'                       => _x('Bokeo', 'ui', 'memberpress'),
    'Bolikhamxai'                 => _x('Bolikhamxai', 'ui', 'memberpress'),
    'Champasak'                   => _x('Champasak', 'ui', 'memberpress'),
    'Houaphan'                    => _x('Houaphan', 'ui', 'memberpress'),
    'Khammouan'                   => _x('Khammouan', 'ui', 'memberpress'),
    'Louangnamtha'                => _x('Louangnamtha', 'ui', 'memberpress'),
    'Louangphrabang'              => _x('Louangphrabang', 'ui', 'memberpress'),
    'Oudomxai'                    => _x('Oudomxai', 'ui', 'memberpress'),
    'Phongsali'                   => _x('Phongsali', 'ui', 'memberpress'),
    'Salavan'                     => _x('Salavan', 'ui', 'memberpress'),
    'Savannakhet'                 => _x('Savannakhet', 'ui', 'memberpress'),
    'Viangchan'                   => _x('Viangchan', 'ui', 'memberpress'),
    'Viangchan'                   => _x('Viangchan', 'ui', 'memberpress'),
    'Xaignabouli'                 => _x('Xaignabouli', 'ui', 'memberpress'),
    'Xaisomboun'                  => _x('Xaisomboun', 'ui', 'memberpress'),
    'Xekong'                      => _x('Xekong', 'ui', 'memberpress'),
    'Xiangkhoang'                 => _x('Xiangkhoang', 'ui', 'memberpress')
);

?>