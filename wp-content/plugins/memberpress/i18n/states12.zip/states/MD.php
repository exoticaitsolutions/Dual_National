<?php
/**
 * Moldova states
 */
$states['Moldova'] = array(
  'Anenii Noi' => _x('Anenii Noi', 'ui', 'memberpress'),
  'Basarabeasca' => _x('Basarabeasca', 'ui', 'memberpress'),
  'Briceni' => _x('Briceni', 'ui', 'memberpress'),
  'Cahul' => _x('Cahul', 'ui', 'memberpress'),
  'Cantemir' => _x('Cantemir', 'ui', 'memberpress'),
  'Calarasi' => _x('Calarasi', 'ui', 'memberpress'),
  'Causeni' => _x('Causeni', 'ui', 'memberpress'),
  'Cimislia' => _x('Cimislia', 'ui', 'memberpress'),
  'Criuleni' => _x('Criuleni', 'ui', 'memberpress'),
  'Donduseni' => _x('Donduseni', 'ui', 'memberpress'),
  'Drochia' => _x('Drochia', 'ui', 'memberpress'),
  'Dubasari' => _x('Dubasari', 'ui', 'memberpress'),
  'Edinet' => _x('Edinet', 'ui', 'memberpress'),
  'Falesti' => _x('Falesti', 'ui', 'memberpress'),
  'Floresti' => _x('Floresti', 'ui', 'memberpress'),
  'Floresti' => _x('Floresti', 'ui', 'memberpress'),
  'Glodeni' => _x('Glodeni', 'ui', 'memberpress'),
  'Hincesti' => _x('Hincesti', 'ui', 'memberpress'),
  'Ialoveni' => _x('Ialoveni', 'ui', 'memberpress'),
  'Leova' => _x('Leova', 'ui', 'memberpress'),
  'Nisporeni' => _x('Nisporeni', 'ui', 'memberpress'),
  'Ocnita' => _x('Ocnita', 'ui', 'memberpress'),
  'Orhei' => _x('Orhei', 'ui', 'memberpress'),
  'Rezina' => _x('Rezina', 'ui', 'memberpress'),
  'Riscani' => _x('Riscani', 'ui', 'memberpress'),
  'Singerei' => _x('Singerei', 'ui', 'memberpress'),
  'Soldanesti' => _x('Soldanesti', 'ui', 'memberpress'),
  'Taraclia' => _x('Taraclia', 'ui', 'memberpress'),
  'Telenesti' => _x('Telenesti', 'ui', 'memberpress'),
  'Ungheni' => _x('Ungheni', 'ui', 'memberpress'),
  'Balti' => _x('Balti', 'ui', 'memberpress'),
  'Bender' => _x('Antananarivo', 'ui', 'memberpress'),
  'Chisinau' => _x('Chisinau', 'ui', 'memberpress'),
  'Gagauzia' => _x('Gagauzia', 'ui', 'memberpress'),
  'Stinga Nistrului' => _x('Stinga Nistrului', 'ui', 'memberpress')
);

?>