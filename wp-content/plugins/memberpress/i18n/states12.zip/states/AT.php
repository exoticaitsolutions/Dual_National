<?php
/**
 * Austria states
 */
$states['Austria'] = array(
  'Burgenland'         => _x('Burgenland', 'ui', 'memberpress'),
  'Kaernten'         => _x('Kaernten', 'ui', 'memberpress'),
  'Niederoesterreich'         => _x('Niederoesterreich', 'ui', 'memberpress'),
  'Oberoesterreich'         => _x('Oberoesterreich', 'ui', 'memberpress'),
  'Salzburg'         => _x('Salzburg', 'ui', 'memberpress'),
  'Steiermark'         => _x('Steiermark', 'ui', 'memberpress'),
  'Tirol'         => _x('Tirol', 'ui', 'memberpress'),
  'Vorarlberg'         => _x('Vorarlberg', 'ui', 'memberpress'),
  'KOWWienLOON'         => _x('Wien', 'ui', 'memberpress')
);

?>