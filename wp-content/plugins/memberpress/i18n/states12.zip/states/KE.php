<?php
/**
 * Kenya states
 */
$states['Kenya'] = array(
    'Central'                       => _x('Central', 'ui', 'memberpress'),
    'Coast'                         => _x('Coast', 'ui', 'memberpress'),
    'Eastern'                       => _x('Eastern', 'ui', 'memberpress'),
    'Nairobi Area'                  => _x('Nairobi Area', 'ui', 'memberpress'),
    'North Eastern'                 => _x('North Eastern', 'ui', 'memberpress'),
    'Nyanza'                        => _x('Nyanza', 'ui', 'memberpress'),
    'Rift Valley'                   => _x('Rift Valley', 'ui', 'memberpress'),
    'Western'                       => _x('Western', 'ui', 'memberpress')
);

?>