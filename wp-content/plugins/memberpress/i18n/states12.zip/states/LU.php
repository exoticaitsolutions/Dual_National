<?php
/**
 * Luxembourg states
 */
$states['Luxembourg'] = array(
    'Diekirch'                       => _x('Diekirch', 'ui', 'memberpress'),
    'Grevenmacher'                   => _x('Grevenmacher', 'ui', 'memberpress'),
    'Luxembourg'                     => _x('Luxembourg', 'ui', 'memberpress')
);

?>