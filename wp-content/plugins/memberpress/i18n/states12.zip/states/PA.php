<?php
/**
 * Panama states
 */
$states['Panama'] = array(
  'Bocas del Toro' => _x('Bocas del Toro', 'ui', 'memberpress'),
  'Chiriqui' => _x('Chiriqui', 'ui', 'memberpress'),
  'Cocle' => _x('Cocle', 'ui', 'memberpress'),
  'Colon' => _x('Colon', 'ui', 'memberpress'),
  'Darien' => _x('Darien', 'ui', 'memberpress'),
  'Herrera' => _x('Herrera', 'ui', 'memberpress'),
  'Los Santos' => _x('Los Santos', 'ui', 'memberpress'),
  'Panama' => _x('Panama', 'ui', 'memberpress'),
  'San Blas' => _x('San Blas', 'ui', 'memberpress'),
  'Veraguas' => _x('Veraguas', 'ui', 'memberpress')
);

?>