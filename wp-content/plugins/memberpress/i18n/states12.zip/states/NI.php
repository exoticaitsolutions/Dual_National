<?php
/**
 * Nicaragua states
 */
$states['Nicaragua'] = array(
  'Atlantico Norte' => _x('Atlantico Norte', 'ui', 'memberpress'),
  'Atlantico Sur' => _x('Atlantico Sur', 'ui', 'memberpress'),
  'Boaco' => _x('Boaco', 'ui', 'memberpress'),
  'Carazo' => _x('Carazo', 'ui', 'memberpress'),
  'Chinandega' => _x('Chinandega', 'ui', 'memberpress'),
  'Chontales' => _x('Chontales', 'ui', 'memberpress'),
  'Esteli' => _x('Esteli', 'ui', 'memberpress'),
  'Granada' => _x('Granada', 'ui', 'memberpress'),
  'Jinotega' => _x('Jinotega', 'ui', 'memberpress'),
  'Leon' => _x('Leon', 'ui', 'memberpress'),
  'Madriz' => _x('Madriz', 'ui', 'memberpress'),
  'Managua' => _x('Managua', 'ui', 'memberpress'),
  'Masaya' => _x('Masaya', 'ui', 'memberpress'),
  'Matagalpa' => _x('Matagalpa', 'ui', 'memberpress'),
  'Nueva Segovia' => _x('Nueva Segovia', 'ui', 'memberpress'),
  'Rio San Juan' => _x('Rio San Juan', 'ui', 'memberpress'),
  'Rivas' => _x('Rivas', 'ui', 'memberpress')
);

?>