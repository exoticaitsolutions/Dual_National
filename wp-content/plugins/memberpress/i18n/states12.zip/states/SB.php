<?php
/**
 * Solomon Islands states
 */
$states['Solomon Islands'] = array(
  'Central' => _x('Central', 'ui', 'memberpress'),
  'Choiseul' => _x('Choiseul', 'ui', 'memberpress'),
  'Guadalcanal' => _x('Guadalcanal', 'ui', 'memberpress'),
  'Honiara' => _x('Honiara', 'ui', 'memberpress'),
  'Isabel' => _x('Isabel', 'ui', 'memberpress'),
  'Makira' => _x('Makira', 'ui', 'memberpress'),
  'Malaita' => _x('Malaita', 'ui', 'memberpress'),
  'Rennell and Bellona' => _x('Rennell and Bellona', 'ui', 'memberpress'),
  'Temotu' => _x('Temotu', 'ui', 'memberpress'),
  'Western' => _x('Western', 'ui', 'memberpress')

);

?>