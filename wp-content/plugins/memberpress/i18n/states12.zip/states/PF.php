<?php
/**
 * French Polynesia states
 */
$states['French Polynesia'] = array(
  'Marquesas Islands' => _x('Marquesas Islands', 'ui', 'memberpress'),
  'Leeward Islands' => _x('Leeward Islands', 'ui', 'memberpress'),
  'Windward Islands' => _x('Windward Islands', 'ui', 'memberpress'),
  'Tuamotu-Gambier' => _x('Tuamotu-Gambier', 'ui', 'memberpress'),
  'Austral Islands' => _x('Austral Islands', 'ui', 'memberpress')
  
);

