<?php
/**
 * Zimbabwe states
 */
$states['Zimbabwe'] = array(
  'Bulawayo'       => _x('Bulawayo', 'ui', 'memberpress'),
  'Harare'       => _x('Harare', 'ui', 'memberpress'),
  'Manicaland'       => _x('Manicaland', 'ui', 'memberpress'),
  'Mashonaland Central'       => _x('Mashonaland Central', 'ui', 'memberpress'),
  'Mashonaland East'       => _x('Mashonaland East', 'ui', 'memberpress'),
  'Mashonaland West'       => _x('Mashonaland West', 'ui', 'memberpress'),
  'Masvingo'       => _x('Masvingo', 'ui', 'memberpress'),
  'Matabeleland North'       => _x('Matabeleland North', 'ui', 'memberpress'),
  'Matabeleland South'       => _x('Matabeleland South', 'ui', 'memberpress'),
  'Midlands'       => _x('Midlands', 'ui', 'memberpress')  

);

