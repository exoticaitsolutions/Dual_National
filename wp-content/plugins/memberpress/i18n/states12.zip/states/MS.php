<?php
/**
 * Montserrat states
 */
$states['Montserrat'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress')
);

?>