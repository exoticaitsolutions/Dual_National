<?php
/**
 * Denmark  States
 */
 $states['Denmark'] = array(
    'Arhus'       => _x('Arhus', 'ui', 'memberpress'),
    'Bornholm'       => _x('Bornholm', 'ui', 'memberpress'),
    'Frederiksberg'       => _x('Frederiksberg', 'ui', 'memberpress'),
    'Frederiksborg'       => _x('Frederiksborg', 'ui', 'memberpress'),
    'Fyn'       => _x('Fyn', 'ui', 'memberpress'),
    'Kobenhavn'       => _x('Kobenhavn', 'ui', 'memberpress'),
    'Kobenhavns'       => _x('Kobenhavns', 'ui', 'memberpress'),
    'Nordjylland'       => _x('Nordjylland', 'ui', 'memberpress'),
    'Ribe'       => _x('Ribe', 'ui', 'memberpress'),
    'Ringkobing'       => _x('Ringkobing', 'ui', 'memberpress'),
    'Roskilde'       => _x('Roskilde', 'ui', 'memberpress'),
    'Sonderjylland'       => _x('Sonderjylland', 'ui', 'memberpress'),
    'Storstrom'       => _x('Storstrom', 'ui', 'memberpress'),
    'Vestsjalland'       => _x('Vestsjalland', 'ui', 'memberpress'),
    'Vestsjalland'       => _x('Vestsjalland', 'ui', 'memberpress'),
    'Viborg'       => _x('Viborg', 'ui', 'memberpress')
  );
 ?>