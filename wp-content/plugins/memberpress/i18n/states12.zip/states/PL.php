<?php
/**
 * Poland states
 */
$states['Poland'] = array(
  'Greater Poland (Wielkopolskie)' => _x('Greater Poland (Wielkopolskie)', 'ui', 'memberpress'),
  'Kuyavian-Pomeranian (Kujawsko-Pomorskie)' => _x('Kuyavian-Pomeranian (Kujawsko-Pomorskie)', 'ui', 'memberpress'),
  'Lesser Poland (Malopolskie)' => _x('Lesser Poland (Malopolskie)', 'ui', 'memberpress'),
  'Lodz (Lodzkie)' => _x('Lodz (Lodzkie)', 'ui', 'memberpress'),
  'Lower Silesian (Dolnoslaskie)' => _x('Lower Silesian (Dolnoslaskie)', 'ui', 'memberpress'),
  'Lublin (Lubelskie)' => _x('Lublin (Lubelskie)', 'ui', 'memberpress'),
  'Lubusz (Lubuskie)' => _x('Lubusz (Lubuskie)', 'ui', 'memberpress'),
  'Masovian (Mazowieckie)' => _x('Masovian (Mazowieckie)', 'ui', 'memberpress'),
  'Opole (Opolskie)' => _x('Opole (Opolskie)', 'ui', 'memberpress'),
  'Podlasie (Podlaskie)' => _x('Podlasie (Podlaskie)', 'ui', 'memberpress'),
  'Pomeranian (Pomorskie)' => _x('Pomeranian (Pomorskie)', 'ui', 'memberpress'),
  'Silesian (Slaskie)' => _x('Silesian (Slaskie)', 'ui', 'memberpress'),
  'Subcarpathian (Podkarpackie)' => _x('Subcarpathian (Podkarpackie)', 'ui', 'memberpress'),
  'Swietokrzyskie (Swietokrzyskie)' => _x('Swietokrzyskie (Swietokrzyskie)', 'ui', 'memberpress'),
  'Warmian-Masurian (Warminsko-Mazurskie)' => _x('Warmian-Masurian (Warminsko-Mazurskie)', 'ui', 'memberpress'),
  'West Pomeranian (Zachodniopomorskie)' => _x('West Pomeranian (Zachodniopomorskie)', 'ui', 'memberpress')

);

?>