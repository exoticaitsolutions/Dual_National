<?php
/**
 * Myanmar states
 */
$states['Myanmar'] = array(
  'Ayeyarwady' => _x('Ayeyarwady', 'ui', 'memberpress'),
  'Bago' => _x('Bago', 'ui', 'memberpress'),
  'Magway' => _x('Magway', 'ui', 'memberpress'),
  'Mandalay' => _x('Mandalay', 'ui', 'memberpress'),
  'Sagaing' => _x('Sagaing', 'ui', 'memberpress'),
  'Tanintharyi' => _x('Tanintharyi', 'ui', 'memberpress'),
  'Yangon' => _x('Yangon', 'ui', 'memberpress'),
  'Chin State' => _x('Chin State', 'ui', 'memberpress'),
  'Kachin State' => _x('Kachin State', 'ui', 'memberpress'),
  'Kayin State' => _x('Kayin State', 'ui', 'memberpress'),
  'Kayah State' => _x('Kayah State', 'ui', 'memberpress'),
  'Mon State' => _x('Mon State', 'ui', 'memberpress'),
  'Rakhine State' => _x('Rakhine State', 'ui', 'memberpress'),
  'Shan State' => _x('Shan State', 'ui', 'memberpress')
);

?>