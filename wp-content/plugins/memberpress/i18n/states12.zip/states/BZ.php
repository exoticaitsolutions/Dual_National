<?php
/**
 * Belize states
 */
$states['Belize'] = array(
  'Belize'         => _x('Belize', 'ui', 'memberpress'),
  'Cayo'         => _x('Cayo', 'ui', 'memberpress'),
  'Corozal'         => _x('Corozal', 'ui', 'memberpress'),
  'Orange Walk'         => _x('Orange Walk', 'ui', 'memberpress'),
  'Stann Creek'         => _x('Stann Creek', 'ui', 'memberpress'),
  'Toledo'         => _x('Toledo', 'ui', 'memberpress')
);


?>
