<?php
/**
 * Turkmenistan states
 */
$states['Turkmenistan'] = array(
  'Ahal Welayaty (Ashgabat)'  => _x('Ahal Welayaty (Ashgabat)', 'ui', 'memberpress'),
  'Balkan Welayaty (Balkanabat)'  => _x('Balkan Welayaty (Balkanabat)', 'ui', 'memberpress'),
  'Dashoguz Welayaty'  => _x('Dashoguz Welayaty', 'ui', 'memberpress'),
  'Lebap Welayaty (Turkmenabat)' => _x('Lebap Welayaty (Turkmenabat)', 'ui', 'memberpress'),
  'Mary Welayaty'  => _x('Mary Welayaty', 'ui', 'memberpress')
);

