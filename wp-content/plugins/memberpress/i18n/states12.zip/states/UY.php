<?php
/**
 * Uruguay states
 */
$states['Uruguay'] = array(
  'Artigas'  => _x('Artigas', 'ui', 'memberpress'),
  'Canelones'  => _x('Canelones', 'ui', 'memberpress'),
  'Cerro Largo'  => _x('Cerro Largo', 'ui', 'memberpress'),
  'Colonia' => _x('Colonia', 'ui', 'memberpress'),
  'Durazno'  => _x('Durazno', 'ui', 'memberpress'),
  'Flores'  => _x('Flores', 'ui', 'memberpress'),
  'Florida'  => _x('Florida', 'ui', 'memberpress'),
  'Lavalleja'  => _x('Lavalleja', 'ui', 'memberpress'),
  'Maldonado'  => _x('Maldonado', 'ui', 'memberpress'),
  'Montevideo'  => _x('Montevideo', 'ui', 'memberpress'),
  'Paysandu'  => _x('Paysandu', 'ui', 'memberpress'),
  'Rio Negro'  => _x('Rio Negro', 'ui', 'memberpress'),
  'Rivera'  => _x('Rivera', 'ui', 'memberpress'),
  'Rocha'  => _x('Rocha', 'ui', 'memberpress'),
  'Salto'  => _x('Salto', 'ui', 'memberpress'),
  'San Jose'  => _x('San Jose', 'ui', 'memberpress'),
  'Soriano'  => _x('Soriano', 'ui', 'memberpress'),
  'Tacuarembo'  => _x('Tacuarembo', 'ui', 'memberpress'),
  'Treinta y Tres'  => _x('Treinta y Tres', 'ui', 'memberpress')
);

