<?php
/**
 * Montenegro states
 */
$states['Montenegro'] = array(
  'Andrijevica' => _x('Andrijevica', 'ui', 'memberpress'),
  'Bar' => _x('Bar', 'ui', 'memberpress'),
  'Berane' => _x('Berane', 'ui', 'memberpress'),
  'Bijelo' => _x('Bijelo', 'ui', 'memberpress'),
  'Polje' => _x('Polje', 'ui', 'memberpress'),
  'Budva' => _x('Budva', 'ui', 'memberpress'),
  'Cetinje' => _x('Cetinje', 'ui', 'memberpress'),
  'Danilovgrad' => _x('Danilovgrad', 'ui', 'memberpress'),
  'Gusinje' => _x('Gusinje', 'ui', 'memberpress'),
  'Herceg Novi' => _x('Herceg Novi', 'ui', 'memberpress'),
  'Kolasin' => _x('Kolasin', 'ui', 'memberpress'),
  'Kotor' => _x('Kotor', 'ui', 'memberpress'),
  'Kotor' => _x('Kotor', 'ui', 'memberpress'),
  'Mojkovac' => _x('Mojkovac', 'ui', 'memberpress'),
  'Niksić' => _x('Niksić', 'ui', 'memberpress'),
  'Petnjica' => _x('Petnjica', 'ui', 'memberpress'),
  'Plav' => _x('Plav', 'ui', 'memberpress'),
  'Pljevlja' => _x('Pljevlja', 'ui', 'memberpress'),
  'Pluzine' => _x('Pluzine', 'ui', 'memberpress'),
  'Podgorica' => _x('Podgorica', 'ui', 'memberpress'),
  'Rozaje' => _x('Rozaje', 'ui', 'memberpress'),
  'Savnik' => _x('Savnik', 'ui', 'memberpress'),
  'Tivat' => _x('Tivat', 'ui', 'memberpress'),
  'Tuzi' => _x('Tuzi', 'ui', 'memberpress'),
  'Ulcinj' => _x('Ulcinj', 'ui', 'memberpress'),
  'Zabljak' => _x('Zabljak', 'ui', 'memberpress')
);

?>