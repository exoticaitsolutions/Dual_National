<?php
/**
 * Jersey states
 */
$states['Jersey'] = array(
'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')    
);

?>