<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  'Arhangay' => _x('Arhangay', 'ui', 'memberpress'),
  'Bayanhongor' => _x('Bayanhongor', 'ui', 'memberpress'),
  'Bayan-Olgiy' => _x('Bayan-Olgiy', 'ui', 'memberpress'),
  'Bulgan' => _x('Bulgan', 'ui', 'memberpress'),
  'Darhan Uul' => _x('Darhan Uul', 'ui', 'memberpress'),
  'Dundgovi' => _x('Dundgovi', 'ui', 'memberpress'),
  'Dzavhan' => _x('Dzavhan', 'ui', 'memberpress'),
  'Govi-Altay' => _x('Govi-Altay', 'ui', 'memberpress'),
  'Govi-Sumber' => _x('Govi-Sumber', 'ui', 'memberpress'),
  'Hentiy' => _x('Hentiy', 'ui', 'memberpress'),
  'Hovd' => _x('Hovd', 'ui', 'memberpress'),
  'Hovsgol' => _x('Hovsgol', 'ui', 'memberpress'),
  'Omnogovi' => _x('Omnogovi', 'ui', 'memberpress'),
  'Orhon' => _x('Orhon', 'ui', 'memberpress'),
  'Ovorhangay' => _x('Ovorhangay', 'ui', 'memberpress'),
  'Selenge' => _x('Selenge', 'ui', 'memberpress'),
  'Suhbaatar' => _x('Suhbaatar', 'ui', 'memberpress'),
  'Tov' => _x('Tov', 'ui', 'memberpress'),
  'Ulaanbaatar' => _x('Ulaanbaatar', 'ui', 'memberpress'),
  'Uvs' => _x('Uvs', 'ui', 'memberpress')
);

?>