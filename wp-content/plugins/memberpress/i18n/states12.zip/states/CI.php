<?php
/**
 * Ivory Coast states
 */
$states['Ivory Coast'] = array(
    'Abidjan'                  => _x('Abidjan', 'ui', 'memberpress'),
    'Bas-Sassandra'            => _x('Bas-Sassandra', 'ui', 'memberpress'),
    'Comoé'                    => _x('Comoé', 'ui', 'memberpress'),
    'Denguélé'                 => _x('Denguélé', 'ui', 'memberpress'),
    'Gôh-Djiboua'              => _x('Gôh-Djiboua', 'ui', 'memberpress'),
    'Lacs'                     => _x('Lacs', 'ui', 'memberpress'),
    'Lagunes'                  => _x('Lagunes', 'ui', 'memberpress'),
    'Montagnes'                => _x('Montagnes', 'ui', 'memberpress'),
    'Sassandra-Marahoué'       => _x('Sassandra-Marahoué', 'ui', 'memberpress'),
    'Savanes'                  => _x('Savanes', 'ui', 'memberpress'),
    'Vallée du Bandama'        => _x('Vallée du Bandama', 'ui', 'memberpress'),
    'Woroba'                   => _x('Woroba', 'ui', 'memberpress'),
    'Yamoussoukro'             => _x('Yamoussoukro', 'ui', 'memberpress')  
);

?>