<?php
/**
 * Hungary states
 */
$states['Hungary'] = array(
  'Bacs-Kiskun' => _x('Bacs-Kiskun', 'ui', 'memberpress'),
  'Bekes' => _x('Bekes', 'ui', 'memberpress'),
  'Baranya' => _x('Baranya', 'ui', 'memberpress'),
  'Borsod-Abauj-Zemplen' => _x('Borsod-Abauj-Zemplen', 'ui', 'memberpress'),
  'Budapest' => _x('Budapest', 'ui', 'memberpress'),
  'Csongrad' => _x('Csongrad', 'ui', 'memberpress'),
  'Fejer' => _x('Fejer', 'ui', 'memberpress'),
  'Gyor-Moson-Sopron' => _x('Gyor-Moson-Sopron', 'ui', 'memberpress'),
  'Hajdu-Bihar' => _x('Hajdu-Bihar', 'ui', 'memberpress'),
  'Heves' => _x('Heves', 'ui', 'memberpress'),
  'Jasz-Nagykun-Szolnok' => _x('Jasz-Nagykun-Szolnok', 'ui', 'memberpress'),
  'Komarom-Esztergom' => _x('Komarom-Esztergom', 'ui', 'memberpress'),
  'Nograd' => _x('Nograd', 'ui', 'memberpress'),
  'Pest' => _x('Pest', 'ui', 'memberpress'),
  'Somogy' => _x('Somogy', 'ui', 'memberpress'),
  'Szabolcs-Szatmar-Bereg' => _x('Szabolcs-Szatmar-Bereg', 'ui', 'memberpress'),
  'Tolna' => _x('Tolna', 'ui', 'memberpress'),
  'Vas' => _x('Vas', 'ui', 'memberpress'),
  'Veszprem' => _x('Veszprem', 'ui', 'memberpress'),
  'Zala' => _x('Zala', 'ui', 'memberpress')
);

