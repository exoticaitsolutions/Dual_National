<?php
/**
 * S&atilde;o Tom&eacute; and Pr&iacute;ncipe states
 */
$states['S&atilde;o Tom&eacute; and Pr&iacute;ncipe'] = array(
  'São Tomé' => _x('São Tomé', 'ui', 'memberpress'),
  'Príncipe' => _x('Príncipe', 'ui', 'memberpress')

);

?>