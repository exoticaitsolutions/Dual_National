<?php
/**
 * Madagascar states
 */
$states['Madagascar'] = array(
  //       "states": ["Adrar", "Assaba", "Brakna", "Dakhlet Nouadhibou", "Gorgol", "Guidimaka", "Hodh Ech Chargui", "Hodh El Gharbi", "Inchiri", "Nouakchott", "Tagant", "Tiris Zemmour", "Trarza"]

  'Adrar' => _x('Adrar', 'ui', 'memberpress'),
  'Assaba' => _x('Assaba', 'ui', 'memberpress'),
  'Brakna' => _x('Brakna', 'ui', 'memberpress'),
  'Dakhlet Nouadhibou' => _x('Dakhlet Nouadhibou', 'ui', 'memberpress'),
  'Gorgol' => _x('Gorgol', 'ui', 'memberpress'),
  'Guidimaka' => _x('Guidimaka', 'ui', 'memberpress'),
  'Hodh Ech Chargui' => _x('Hodh Ech Chargui', 'ui', 'memberpress'),
  'Hodh El Gharbi' => _x('Hodh El Gharbi', 'ui', 'memberpress'),
  'Inchiri' => _x('Inchiri', 'ui', 'memberpress'),
  'Nouakchott' => _x('Nouakchott', 'ui', 'memberpress'),
  'Tagant' => _x('Tagant', 'ui', 'memberpress'),
  'Tiris Zemmour' => _x('Tiris Zemmour', 'ui', 'memberpress'),
  'Trarza' => _x('Trarza', 'ui', 'memberpress')
);

?>