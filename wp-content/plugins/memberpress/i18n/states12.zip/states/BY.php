<?php
/**
 * Belarus states
 */
$states['Belarus'] = array(
  'Brest'         => _x('Brest', 'ui', 'memberpress'),
  'Homyel'         => _x('Homyel    ', 'ui', 'memberpress'),
  'Horad Minsk'         => _x('Horad Minsk', 'ui', 'memberpress'),
  'Hrodna'         => _x('Hrodna', 'ui', 'memberpress'),
  'Minsk'         => _x('Minsk', 'ui', 'memberpress'),
  'Vitsyebsk'         => _x('Vitsyebsk', 'ui', 'memberpress')
);


?>
