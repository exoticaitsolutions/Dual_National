<?php
/**
 * Bolivia states
 */
$states['Bolivia'] = array(
  'Chuquisaca'         => _x('Chuquisaca', 'ui', 'memberpress'),
  'Cochabamba'         => _x('Cochabamba', 'ui', 'memberpress'),
  'Beni'         => _x('Beni', 'ui', 'memberpress'),
  'La Paz'         => _x('La Paz', 'ui', 'memberpress'),
  'Oruro'         => _x('Oruro', 'ui', 'memberpress'),
  'Pando'         => _x('Pando', 'ui', 'memberpress'),
  'Potosi'         => _x('Potosi', 'ui', 'memberpress'),
  'Santa Cruz'         => _x('Santa Cruz', 'ui', 'memberpress'),
  'Tarija'         => _x('Tarija', 'ui', 'memberpress')
);


?>
