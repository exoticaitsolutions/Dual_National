<?php
/**
 * Central African Republic  States
 */


 $states['Central African Republic'] = array(
    
    'Bamingui-Bangoran'       => _x('Bamingui-Bangoran', 'ui', 'memberpress'),
    'Bangui'       => _x('Bangui', 'ui', 'memberpress'),
    'Basse-Kotto'       => _x('Basse-Kotto', 'ui', 'memberpress'),
    'Haute-Kotto'       => _x('Haute-Kotto', 'ui', 'memberpress'),
    'Haut-Mbomou'       => _x('Haut-Mbomou', 'ui', 'memberpress'),
    'Kemo'       => _x('Kemo', 'ui', 'memberpress'),
    'Lobaye'       => _x('Lobaye', 'ui', 'memberpress'),
    'Mambere-Kadei'       => _x('Mambere-Kadei', 'ui', 'memberpress'),
    'Mbomou'       => _x('Mbomou', 'ui', 'memberpress'),
    'Nana-Grebizi'       => _x('Nana-Grebizi', 'ui', 'memberpress'),
    'Nana-Mambere'       => _x('Nana-Mambere', 'ui', 'memberpress'),
    'Ombella-Mpoko'       => _x('Ombella-Mpoko', 'ui', 'memberpress'),
    'Ouaka'       => _x('Ouaka', 'ui', 'memberpress'),
    'Ouham'       => _x('Batdambang', 'ui', 'memberpress'),
    'Ouham-Pende'       => _x('Ouham-Pende', 'ui', 'memberpress'),
    'Sangha-Mbaere'       => _x('Sangha-Mbaere', 'ui', 'memberpress'),
    'Vakaga'       => _x('Vakaga', 'ui', 'memberpress')
  );
 ?>