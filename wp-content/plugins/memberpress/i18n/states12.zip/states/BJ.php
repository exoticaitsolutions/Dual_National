<?php
/**
 * Benin states
 */
$states['Benin'] = array(
  'Alibori'         => _x('Alibori', 'ui', 'memberpress'),
  'Atakora'         => _x('Atakora', 'ui', 'memberpress'),
  'Atlantique'         => _x('Atlantique', 'ui', 'memberpress'),
  'Borgou'         => _x('Borgou', 'ui', 'memberpress'),
  'Collines'         => _x('Collines', 'ui', 'memberpress'),
  'Donga'         => _x('Donga', 'ui', 'memberpress'),
  'Kouffo'         => _x('Kouffo', 'ui', 'memberpress'),
  'Littoral'         => _x('Littoral', 'ui', 'memberpress'),
  'Mono'         => _x('Mono', 'ui', 'memberpress'),
  'Oueme'         => _x('Oueme', 'ui', 'memberpress'),
  'Plateau'         => _x('Plateau', 'ui', 'memberpress'),
  'Zou'         => _x('Zou', 'ui', 'memberpress')
);


?>
