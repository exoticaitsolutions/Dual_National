<?php
/**
 * Guernsey states
 */
$states['Guernsey'] = array(
  'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')
  
);

