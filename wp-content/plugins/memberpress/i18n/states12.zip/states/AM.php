<?php
/**
 * Armenia states
 */
$states['Armenia'] = array(
    'Aragatsotn'         => _x('Aragatsotn', 'ui', 'memberpress'),
    'Ararat'         => _x('Ararat', 'ui', 'memberpress'),
    'Armavir'         => _x('Armavir', 'ui', 'memberpress'),
    "Geghark'unik"       => _x( "Geghark'unik" , 'ui', 'memberpress'),
    'Kotayk'         => _x('Kotayk', 'ui', 'memberpress'),
    'Lorri'         => _x('Lorri', 'ui', 'memberpress'),
    'Shirak'         => _x('Shirak', 'ui', 'memberpress'),
    'Syunik'         => _x('Syunik', 'ui', 'memberpress'),
    'Tavush'         => _x('Tavush', 'ui', 'memberpress'),
    'Vayots'         => _x('Vayots', 'ui', 'memberpress'),
    'Dzor'         => _x('Dzor', 'ui', 'memberpress'),
    'Yerevan'         => _x('Yerevan', 'ui', 'memberpress')

);

?>