<?php
/**
 * Reunion states
 */
$states['Reunion'] = array(
  'No states of this Country' => _x('No states of this Country', 'ui', 'memberpress'),
);

?>