<?php
/**
 * Albania states
 */
$states['Albania'] = array(
  'Berat'       => _x('Berat', 'ui', 'memberpress'),
  'Diber'       => _x('Diber', 'ui', 'memberpress'),
  'Durres'       => _x('Durres', 'ui', 'memberpress'),
  'Elbasan'       => _x('Elbasan', 'ui', 'memberpress'),
  'Fier'       => _x('Fier', 'ui', 'memberpress'),
  'Gjirokaster'       => _x('Gjirokaster', 'ui', 'memberpress'),
  'Korçe'       => _x('Korçe', 'ui', 'memberpress'),
  'Kukes'       => _x('Kukes', 'ui', 'memberpress'),
  'Lezhe'       => _x('Lezhe', 'ui', 'memberpress'),
  'Shkoder'       => _x('Shkoder', 'ui', 'memberpress'),
  'Tirane'       => _x('Tirane', 'ui', 'memberpress'),
  'Vlore'       => _x('Vlore', 'ui', 'memberpress')
);

