<?php
/**
 * Isle of Man states
 */
$states['Isle of Man'] = array(
'No States in this Country' => _x('No States in this Country', 'ui', 'memberpress')    
);

?>