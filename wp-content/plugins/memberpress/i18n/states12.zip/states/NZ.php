<?php
/**
 * New Zealand States
 */
$states['New Zealand'] = array(
  'Northland' => _x('Northland', 'ui', 'memberpress'),
  'Auckland' => _x('Auckland', 'ui', 'memberpress'),
  'Waikato' => _x('Waikato', 'ui', 'memberpress'),
  'Bay of Plenty' => _x('Bay of Plenty', 'ui', 'memberpress'),
  'Taranaki' => _x('Taranaki', 'ui', 'memberpress'),
  "Hawke's Bay United" => _x("Hawke's Bay United", 'ui', 'memberpress'),
  'Manawatu-Wanganu' => _x('Manawatu-Wanganui', 'ui', 'memberpress'),
  'Wellington' => _x('Wellington', 'ui', 'memberpress'),
  'Nelson' => _x('Nelson', 'ui', 'memberpress'),
  'Marlborough' => _x('Marlborough', 'ui', 'memberpress'),
  'Tasman' => _x('Tasman', 'ui', 'memberpress'),
  'West Coast' => _x('West Coast', 'ui', 'memberpress'),
  'Canterbury' => _x('Canterbury', 'ui', 'memberpress'),
  'Otago' => _x('Otago', 'ui', 'memberpress'),
  'Southland' => _x('Southland', 'ui', 'memberpress')
);

