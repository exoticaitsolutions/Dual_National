<?php
/**
 * Syria states
 */
$states['Syria'] = array(
  'Al Hasakah' => _x('Al Hasakah', 'ui', 'memberpress'),
  'Al Ladhiqiyah' => _x('Al Ladhiqiyah', 'ui', 'memberpress'),
  'Al Qunaytirah' => _x('Al Qunaytirah', 'ui', 'memberpress'),
  'Ar Raqqah' => _x('Ar Raqqah', 'ui', 'memberpress'),
  'As Suwayda' => _x('As Suwayda', 'ui', 'memberpress'),
  'Dar a' => _x('Dar a', 'ui', 'memberpress'),
  'Dayr az Zawr' => _x('Dayr az Zawr', 'ui', 'memberpress'),
  'Dimashq' => _x('Dimashq', 'ui', 'memberpress'),
  'Halab' => _x('Halab', 'ui', 'memberpress'),
  'Hamah' => _x('Hamah', 'ui', 'memberpress'),
  'Hims' => _x('Hims', 'ui', 'memberpress'),
  'Idlib' => _x('Idlib', 'ui', 'memberpress'),
  'Rif Dimashq' => _x('Rif Dimashq', 'ui', 'memberpress'),
  'Tartus' => _x('Tartus', 'ui', 'memberpress'),

);
