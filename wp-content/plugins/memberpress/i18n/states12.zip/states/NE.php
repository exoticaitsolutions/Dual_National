<?php
/**
 * Nigeria states
 */
$states['Nigeria'] = array(
  'Agadez' => _x('Agadez', 'ui', 'memberpress'),
  'Diffa' => _x('Diffa', 'ui', 'memberpress'),
  'Dosso' => _x('Dosso', 'ui', 'memberpress'),
  'Maradi' => _x('Maradi', 'ui', 'memberpress'),
  'Niamey' => _x('Niamey', 'ui', 'memberpress'),
  'Tahoua' => _x('Tahoua', 'ui', 'memberpress'),
  'Tillaberi' => _x('Tillaberi', 'ui', 'memberpress'),
  'Zinder' => _x('Zinder', 'ui', 'memberpress')
);

?>