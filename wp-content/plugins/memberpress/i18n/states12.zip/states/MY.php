<?php
/**
 * Malaysian states
 */
$states['Malaysia'] = array(
  'Johor' => _x('Johor', 'ui', 'memberpress'),
  'Kedah' => _x('Kedah', 'ui', 'memberpress'),
  'Kelantan' => _x('Kelantan', 'ui', 'memberpress'),
  'Melaka' => _x('Melaka', 'ui', 'memberpress'),
  'Negeri Sembilan' => _x('Negeri Sembilan', 'ui', 'memberpress'),
  'Pahang' => _x('Pahang', 'ui', 'memberpress'),
  'Perak' => _x('Perak', 'ui', 'memberpress'),
  'Perlis' => _x('Perlis', 'ui', 'memberpress'),
  'Pulau Pinang' => _x('Pulau Pinang', 'ui', 'memberpress'),
  'Sabah' => _x('Sabah', 'ui', 'memberpress'),
  'Sarawak' => _x('Sarawak', 'ui', 'memberpress'),
  'Selangor' => _x('Selangor', 'ui', 'memberpress'),
  'Terengganu' => _x('Terengganu', 'ui', 'memberpress'),
  'KUW.P. Kuala LumpurL' => _x('W.P. Kuala Lumpur', 'ui', 'memberpress'),
  'W.P. Labuan' => _x('W.P. Labuan', 'ui', 'memberpress'),
  'W.P. Putrajaya' => _x('W.P. Putrajaya', 'ui', 'memberpress')
);

