<?php
/**
 * Botswana states
 */
$states['Botswana'] = array(
  'Ghanzi'         => _x('Ghanzi', 'ui', 'memberpress'),
  'Kgalagadi'         => _x('Kgalagadi', 'ui', 'memberpress'),
  'Kgatleng'         => _x('Kgatleng', 'ui', 'memberpress'),
  'Kweneng'         => _x('Kweneng', 'ui', 'memberpress'),
  'North East'         => _x('North East', 'ui', 'memberpress'),
  'North West'         => _x('North West', 'ui', 'memberpress'),
  'South East'         => _x('South East', 'ui', 'memberpress'),
  'Southern'         => _x('Southern', 'ui', 'memberpress')
);


?>
